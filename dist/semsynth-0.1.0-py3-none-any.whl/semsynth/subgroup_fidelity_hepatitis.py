"""Two-check subgroup fidelity report for hepatitis. Same shape as
subgroup_fidelity.py (CKD) -- reuses its _cluster_cutoffs/_flag_outliers_transfer
helpers directly rather than redefining them, since neither is dataset-specific.
"""

import pandas as pd

from dataset_registry import DATASET_REGISTRY
from hepatitis_albi_staging import add_albi_columns
from outlier_subgroups import cluster_outliers, find_outliers
from subgroup_clustering import check_persistence, fit_subgroups, print_outcome_result, test_cluster_outcome
from subgroup_fidelity import _cluster_cutoffs, _flag_outliers_transfer

config = DATASET_REGISTRY["hepatitis"]
categorical_cols = config["categorical_cols"]

real_df = pd.read_csv("hepatitis_synthetic_b.csv")
negative_label = next(v for v in real_df["class"].unique() if v != config["positive_label"])
real_survivors = real_df[real_df["class"] == negative_label].reset_index(drop=True)

main_model = fit_subgroups(real_survivors, categorical_cols, exclude_cols=["class"])
outlier_mask = find_outliers(main_model)
outlier_model = cluster_outliers(real_survivors, categorical_cols, outlier_mask, exclude_cols=["class"], k=2)
cutoffs = _cluster_cutoffs(main_model)

print(f"Main clustering: k={main_model.k}, sizes={main_model.sizes}")
print(f"Outlier subgroups: n={int(outlier_mask.sum())}, sizes={outlier_model.sizes}")

albi_main = add_albi_columns(real_survivors)["albi_grade"]
albi_outliers = add_albi_columns(real_survivors[outlier_mask])["albi_grade"]

for label, model, outcome in [
    ("Main clusters", main_model, albi_main),
    ("Outlier subgroups", outlier_model, albi_outliers),
]:
    print(f"\n{'=' * 70}\n{label}\n{'=' * 70}")

    print("\n-- (1) Clinically meaningful? test_cluster_outcome vs albi_grade --")
    print_outcome_result("albi_grade", test_cluster_outcome(model, outcome, outcome_type="categorical"))

    print("\n-- (2) Survives synthesis? check_persistence vs S1/S2 --")
    for variant in ["s1", "s2"]:
        synth_df = pd.read_csv(f"hepatitis_synthetic_{variant}.csv")
        synth_survivors = synth_df[synth_df["class"] == negative_label].reset_index(drop=True)
        new_df = (
            synth_survivors if model is main_model
            else synth_survivors[_flag_outliers_transfer(main_model, synth_survivors, cutoffs)]
        )

        if model is not main_model and len(new_df) < 4:
            print(f"{variant.upper()}: skipped, only {len(new_df)} synthetic outlier rows")
            continue

        persistence = check_persistence(model, new_df)
        print(f"{variant.upper()}: agreement={persistence['agreement']}, ari={persistence['ari']}")
        for cid, info in persistence["per_cluster"].items():
            print(f"  cluster {cid}: real_prop={info['real_prop']}, {variant.upper()}_prop={info['new_prop']}")
