"""Two-check subgroup fidelity report for CKD: for each subgroup definition
built this session (main KMeans clustering, outlier subgroups), report (1)
whether it's clinically meaningful -- test_cluster_outcome against
ckd_stage -- and (2) whether it survives synthesis -- check_persistence
against S1/S2 synthetic data. Both are existing functions from
subgroup_clustering.py, reused unmodified; this script only calls them and
prints results together per subgroup so both can be read at once.

Reuses fit_subgroups / check_persistence / test_cluster_outcome /
print_outcome_result (subgroup_clustering.py) and find_outliers /
cluster_outliers (outlier_subgroups.py) -- none modified.
"""

import numpy as np
import pandas as pd

from dataset_registry import DATASET_REGISTRY
from egfr_staging import add_egfr_columns
from outlier_subgroups import cluster_outliers, find_outliers
from subgroup_clustering import check_persistence, fit_subgroups, print_outcome_result, test_cluster_outcome


def _cluster_cutoffs(model, threshold_std=2.0):
    """Same per-cluster mean + threshold_std*std cutoff outlier_subgroups.find_outliers
    computes internally, exposed here so it can be reapplied to synthetic data."""
    Z = model.encoder.transform(model.df)
    centroids = model.kmeans.cluster_centers_
    distances = np.linalg.norm(Z - centroids[model.cluster_labels], axis=1)
    return {
        c: distances[model.cluster_labels == c].mean() + threshold_std * distances[model.cluster_labels == c].std()
        for c in np.unique(model.cluster_labels)
    }


def _flag_outliers_transfer(model, new_df, cutoffs):
    """Flag new_df's rows as outliers using cutoffs LEARNED FROM REAL DATA (transfer,
    not an independent refit) -- same encoder/kmeans model was fit with."""
    work = new_df.copy()
    for c in model.cat_cols:
        if c in work.columns:
            work[c] = work[c].astype("object")
    Z_new = model.encoder.transform(work[model.num_cols + model.cat_cols])
    labels = model.kmeans.predict(Z_new)
    distances = np.linalg.norm(Z_new - model.kmeans.cluster_centers_[labels], axis=1)
    return distances > np.array([cutoffs[label] for label in labels])


if __name__ == "__main__":
    config = DATASET_REGISTRY["ckd"]
    categorical_cols = config["categorical_cols"]

    real_df = pd.read_csv("ckd_synthetic_b.csv")
    real_ckd = real_df[real_df["class"] == "ckd"].reset_index(drop=True)

    main_model = fit_subgroups(real_ckd, categorical_cols, exclude_cols=["class"])
    outlier_mask = find_outliers(main_model)
    outlier_model = cluster_outliers(real_ckd, categorical_cols, outlier_mask, exclude_cols=["class"], k=2)
    cutoffs = _cluster_cutoffs(main_model)

    print(f"Main clustering: k={main_model.k}, sizes={main_model.sizes}")
    print(f"Outlier subgroups: n={int(outlier_mask.sum())}, sizes={outlier_model.sizes}")

    ckd_stage_main = add_egfr_columns(real_ckd)["ckd_stage"]
    ckd_stage_outliers = add_egfr_columns(real_ckd[outlier_mask])["ckd_stage"]

    for label, model, outcome in [
        ("Main clusters", main_model, ckd_stage_main),
        ("Outlier subgroups", outlier_model, ckd_stage_outliers),
    ]:
        print(f"\n{'=' * 70}\n{label}\n{'=' * 70}")

        print("\n-- (1) Clinically meaningful? test_cluster_outcome vs ckd_stage --")
        print_outcome_result("ckd_stage", test_cluster_outcome(model, outcome, outcome_type="categorical"))

        print("\n-- (2) Survives synthesis? check_persistence vs S1/S2 --")
        for variant in ["s1", "s2"]:
            synth_df = pd.read_csv(f"ckd_synthetic_{variant}.csv")
            synth_ckd = synth_df[synth_df["class"] == "ckd"].reset_index(drop=True)
            new_df = (
                synth_ckd if model is main_model
                else synth_ckd[_flag_outliers_transfer(main_model, synth_ckd, cutoffs)]
            )

            if model is not main_model and len(new_df) < 4:
                print(f"{variant.upper()}: skipped, only {len(new_df)} synthetic outlier rows")
                continue

            persistence = check_persistence(model, new_df)
            print(f"{variant.upper()}: agreement={persistence['agreement']}, ari={persistence['ari']}")
            for cid, info in persistence["per_cluster"].items():
                print(f"  cluster {cid}: real_prop={info['real_prop']}, {variant.upper()}_prop={info['new_prop']}")
