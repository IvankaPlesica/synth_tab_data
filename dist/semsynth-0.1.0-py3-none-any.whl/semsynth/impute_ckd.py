import numpy as np
import pandas as pd
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor

M = 5

CATEGORICAL_COLS = [
    "rbc", "pc", "pcc", "ba", "htn",
    "dm", "cad", "appet", "pe", "ane"
]

TARGET_COLS = ["classification"]

# clusters and their MAR auxiliaries
CLUSTERS = {
    "mp1": {
        "cols":    ["sc", "bu", "bgr", "sod", "pot"],
        "aux":     ["age", "hemo", "pcv", "wbcc", "rbcc"],
    },
    "mp2": {
        "cols":    ["wbcc", "rbcc", "pcv", "hemo"],
        "aux":     ["age", "sc", "bu", "bgr"],
    },
    "mp3": {
        "cols":    ["sg", "al", "su"],
        "aux":     ["sc", "bu", "bgr", "age"],
    },
}

ORDINAL_COLS = {
    "al": (0, 5),
    "su": (0, 5),
    "sg": (1.005, 1.025),  # specific gravity — discrete but not integer
}


def clean(df):
    df = df.copy()
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].str.strip()
    return df


def encode_categoricals(df):
    df = df.copy()
    mappings = {}
    for col in CATEGORICAL_COLS:
        if col in df.columns:
            codes, uniques = pd.factorize(df[col])
            codes = pd.Series(codes, index=df.index).replace(-1, np.nan)
            df[col] = codes
            mappings[col] = uniques
    return df, mappings


def decode_categoricals(df, mappings):
    df = df.copy()
    for col, uniques in mappings.items():
        if col in df.columns:
            idx = np.clip(np.round(df[col]).astype(int), 0, len(uniques) - 1)
            df[col] = uniques[idx]
    return df


def impute_cluster(df, cluster_name, cluster_def, seed):
    """
    For rows where ALL cluster columns are missing:
    train RandomForest on complete rows, predict missing rows
    using cluster columns + auxiliaries as features.
    """
    cols = [c for c in cluster_def["cols"] if c in df.columns]
    aux  = [c for c in cluster_def["aux"]  if c in df.columns]

    if not cols:
        return df

    fully_missing = df[cols].isna().all(axis=1)
    n_missing = fully_missing.sum()

    if n_missing == 0:
        print(f"  {cluster_name}: no fully missing rows, skipping cluster model")
        return df

    print(f"  {cluster_name}: {n_missing} fully missing rows, training cluster model")

    # training rows: complete on both cluster cols and auxiliaries
    feature_cols = [c for c in aux if c in df.columns]
    train_mask   = df[cols + feature_cols].notna().all(axis=1)
    train        = df[train_mask]

    if len(train) < 10:
        print(f"  {cluster_name}: too few complete rows ({len(train)}), skipping")
        return df

    result = df.copy()

    for col in cols:
        X_train = train[feature_cols].values
        y_train = train[col].values

        rf = RandomForestRegressor(
            n_estimators=200,
            random_state=seed,
            n_jobs=-1,
        )
        rf.fit(X_train, y_train)

        # predict for fully missing rows that have complete auxiliaries
        predict_mask = fully_missing & df[feature_cols].notna().all(axis=1)
        if predict_mask.sum() == 0:
            continue

        X_pred = df.loc[predict_mask, feature_cols].values
        preds  = rf.predict(X_pred)

        # apply ordinal constraints
        if col in ORDINAL_COLS:
            lo, hi = ORDINAL_COLS[col]
            if col in ["al", "su"]:
                preds = np.clip(np.round(preds).astype(int), lo, hi).astype(float)
            else:
                preds = np.clip(preds, lo, hi)

        result.loc[predict_mask, col] = preds

    return result


def impute_mice_fallback(df, num_cols, cat_cols, seed):
    """
    MICE for partial missingness and uncovered rows.
    BayesianRidge for numerics, ExtraTreesRegressor for categoricals.
    """
    # numeric
    num_imputer = IterativeImputer(
        estimator=BayesianRidge(),
        max_iter=20,
        sample_posterior=True,
        random_state=seed,
    )
    num_matrix  = df[num_cols].copy()
    num_imputed_arr = num_imputer.fit_transform(num_matrix)
    num_imputed = pd.DataFrame(num_imputed_arr, columns=num_cols, index=df.index)

    result = df.copy()
    for col in num_cols:
        mask = result[col].isna()
        result.loc[mask, col] = num_imputed.loc[mask, col]

    # clip numerics to observed range
    for col in num_cols:
        result[col] = result[col].clip(df[col].min(), df[col].max())

    # ordinal post-processing
    for col, (lo, hi) in ORDINAL_COLS.items():
        if col in result.columns and col in ["al", "su"]:
            result[col] = np.clip(np.round(result[col]).astype(int), lo, hi).astype(float)

    # categorical
    if cat_cols:
        cat_matrix = pd.concat([result[cat_cols], result[num_cols]], axis=1)
        cat_imputer = IterativeImputer(
            estimator=ExtraTreesRegressor(n_estimators=50, random_state=seed),
            max_iter=10,
            random_state=seed,
        )
        cat_imputed_arr = cat_imputer.fit_transform(cat_matrix)
        cat_imputed = pd.DataFrame(cat_imputed_arr, columns=cat_matrix.columns, index=df.index)

        for col in cat_cols:
            mask = result[col].isna()
            result.loc[mask, col] = cat_imputed.loc[mask, col]

    return result


def main(src="ckd_with_patterns.csv"):
    df = pd.read_csv(src)
    df = clean(df)
    print(f"Loaded: {df.shape}, missing={df.isnull().sum().sum()}")

    # separate passthrough columns
    passthrough_cols = TARGET_COLS + [
        c for c in df.columns
        if c not in CATEGORICAL_COLS and df[c].dtype == object
    ]
    passthrough = df[[c for c in passthrough_cols if c in df.columns]].copy()
    df = df.drop(columns=[c for c in passthrough_cols if c in df.columns])

    # encode categoricals
    df, cat_maps = encode_categoricals(df)

    num_cols = [c for c in df.columns if c not in CATEGORICAL_COLS]
    cat_cols = [c for c in df.columns if c in CATEGORICAL_COLS]

    for i in range(M):
        print(f"\nImputation {i + 1}/{M}")
        result = df.copy()

        # step 1 — cluster model for fully missing rows
        for cluster_name, cluster_def in CLUSTERS.items():
            result = impute_cluster(result, cluster_name, cluster_def, seed=42 + i)

        # step 2 — MICE fallback for everything remaining
        remaining = result.isnull().sum().sum()
        if remaining > 0:
            print(f"  MICE fallback: {remaining} values remaining")
            result = impute_mice_fallback(result, num_cols, cat_cols, seed=42 + i)

        # decode categoricals
        result = decode_categoricals(result, cat_maps)

        # reattach passthrough
        for col in passthrough.columns:
            result[col] = passthrough[col]

        print(f"  Missing after imputation: {result.isnull().sum().sum()}")
        result.to_csv(f"imputed_ckd_m{i}.csv", index=False)
        print(f"  Saved imputed_ckd_m{i}.csv")

    print(f"\nDone. Use imputed_ckd_m0..m{M - 1}.csv for downstream analysis.")


if __name__ == "__main__":
    main()



from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
import pandas as pd


def missingness_predictability(df, min_missing_rate=0.01):
    results = {}
    filled = df.fillna(df.median(numeric_only=True))

    cols_with_missing = [c for c in df.columns if df[c].isnull().mean() > min_missing_rate]

    for col in cols_with_missing:
        y = df[col].isnull().astype(int)
        X = filled.drop(columns=[col])
        clf = RandomForestClassifier(n_estimators=100)
        auc = cross_val_score(clf, X, y, cv=5, scoring="roc_auc").mean()
        results[col] = round(auc, 3)

    return results