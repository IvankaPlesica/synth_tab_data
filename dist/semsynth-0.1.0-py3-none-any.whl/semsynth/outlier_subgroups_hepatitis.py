"""Outlier-then-subgroup detection for hepatitis. Same shape as
outlier_subgroups.py (CKD) -- reuses find_outliers/cluster_outliers from
there directly rather than redefining them, since neither is dataset-
specific.
"""

import pandas as pd

from dataset_registry import DATASET_REGISTRY
from outlier_subgroups import cluster_outliers, find_outliers
from subgroup_clustering import fit_subgroups

if __name__ == "__main__":
    config = DATASET_REGISTRY["hepatitis"]
    categorical_cols = config["categorical_cols"]
    real_df = pd.read_csv("hepatitis_synthetic_b.csv")
    negative_label = next(v for v in real_df["class"].unique() if v != config["positive_label"])
    real_df = real_df[real_df["class"] == negative_label].reset_index(drop=True)  # restrict to survivors
    # only, so outliers reflect phenotype variation among survivors instead of the mortality/severity split

    model = fit_subgroups(real_df, categorical_cols, exclude_cols=["class"])
    print(f"Main pass: k={model.k}, sizes={model.sizes}")

    outliers = find_outliers(model)
    print(f"\nFlagged {outliers.sum()} outlier rows out of {len(model.df)}")
    print("Outliers by original cluster:")
    print(pd.Series(model.cluster_labels[outliers]).value_counts().sort_index())

    outlier_model = cluster_outliers(real_df, categorical_cols, outliers, exclude_cols=["class"], k=2)
    print(f"\nOutlier subgroup sizes: {outlier_model.sizes}")
    print("\nOutlier subgroup explanation (decision tree rules):")
    print(outlier_model.rules_text)
