from load_ckd import load_ckd
from egfr_staging import add_egfr_columns
from Missingness_Model import MissingnessModel
from block_analysis import (
    assign_patterns
)
import pandas as pd

df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
#print(df.columns)

exclude_cols = ["class", "ckd_stage", "egfr_star", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

rates = df_features.isnull().mean().sort_values(ascending=False)
print(rates)

model = MissingnessModel()
model.fit(df_features, min_support=0.1, min_any_confidence=0.7)

model.summary()

# --- how many patients actually fall into each pattern ---
labels = assign_patterns(df_features, model)
counts = labels.value_counts()
pcts = (labels.value_counts(normalize=True) * 100).round(1)
print("\nPattern counts (n patients):")
print(pd.concat([counts, pcts], axis=1, keys=["count", "pct"]))

# --- same, broken out by class ---
print("\nPattern counts by class (n patients):")
pattern_by_class_n = pd.crosstab(labels, df["class"])
print(pattern_by_class_n)

print("\nPattern rates by class (% within each class):")
pattern_by_class_pct = pd.crosstab(labels, df["class"], normalize="columns") * 100
print(pattern_by_class_pct.round(1))