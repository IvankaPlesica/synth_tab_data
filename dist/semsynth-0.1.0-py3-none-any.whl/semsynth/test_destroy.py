"""Small standalone example exercising pattern_missingness.py's helpers
one at a time, so you can see exactly what each one produces on a tiny,
hand-built dataset -- no real CKD data, no BN, just the missingness logic."""

import numpy as np
import pandas as pd

from pattern_missingness import (
    build_column_to_block,
    build_label_to_itemset,
    expand_label,
    get_residual_cols_and_rates,
    get_mp_other_masks,
    apply_deterministic_patterns,
    apply_mp_other_masks,
    apply_residual_noise,
    reinsert_pattern_missingness,
)

# --- tiny "real" dataset: 3 columns, one mined block {bp, drab} ---
X_train = pd.DataFrame({
    "bp":   [np.nan, np.nan, 120, 130, np.nan, 125, 128],
    "drab": [np.nan, np.nan, 1.2, 1.1, 1.3,    np.nan, 1.0],
    "w":    [5,      np.nan, np.nan, 8, 6,     4,      np.nan],
})
blocks = [{"itemset": ["bp", "drab"]}]

print("=== X_train ===")
print(X_train)

# --- 1. build_column_to_block / build_label_to_itemset ---
column_to_block = build_column_to_block(blocks)
label_to_itemset = build_label_to_itemset(blocks)
print("\n=== build_column_to_block ===")
print(column_to_block)
print("\n=== build_label_to_itemset ===")
print(label_to_itemset)

# --- 2. expand_label ---
print("\n=== expand_label ===")
print("bp+drab       ->", expand_label("bp+drab", label_to_itemset))
print("mp0           ->", expand_label("mp0", label_to_itemset))
print("mp_other      ->", expand_label("mp_other", label_to_itemset))

# --- real pattern labels, hand-assigned to match assign_patterns' logic ---
# row 0,1: bp+drab both missing -> "bp+drab"
# row 2,3: nothing missing -> "mp0"
# row 4,5,6: irregular (only one of bp/drab/w missing) -> "mp_other"
real_pattern_labels = pd.Series(
    ["bp+drab", "bp+drab", "mp0", "mp0", "mp_other", "mp_other", "mp_other"]
)
print("\n=== real_pattern_labels ===")
print(real_pattern_labels)

# --- 3. get_residual_cols_and_rates ---
residual_cols, residual_rates = get_residual_cols_and_rates(X_train, blocks, real_pattern_labels)
print("\n=== get_residual_cols_and_rates ===")
print("residual_cols:", residual_cols)
print("residual_rates:", residual_rates)

# --- 4. get_mp_other_masks ---
mp_other_masks = get_mp_other_masks(X_train, real_pattern_labels)
print("\n=== get_mp_other_masks ===")
print(mp_other_masks)

# --- pretend "synthetic" features (already complete, no NaNs -- as if freshly sampled) ---
synth_features = pd.DataFrame({
    "bp":   [110, 115, 122, 128, 119, 121, 130],
    "drab": [1.0, 1.1, 1.2, 1.3, 1.0, 1.1, 1.2],
    "w":    [5,   6,   7,   8,   5,   6,   7],
})
synth_pattern_labels = ["bp+drab", "mp0", "mp0", "bp+drab", "mp_other", "mp_other", "mp0"]

# --- 5. apply_deterministic_patterns ---
out, row_block_columns, is_mp_other = apply_deterministic_patterns(
    synth_features, synth_pattern_labels, label_to_itemset
)
print("\n=== apply_deterministic_patterns ===")
print(out)
print("row_block_columns:", row_block_columns)
print("is_mp_other:", is_mp_other)

# --- 6. apply_mp_other_masks ---
rng = np.random.default_rng(42)
out2 = apply_mp_other_masks(out.copy(), is_mp_other, mp_other_masks, rng)
print("\n=== apply_mp_other_masks ===")
print(out2)

# --- 7. apply_residual_noise ---
out3 = apply_residual_noise(
    out2.copy(), synth_pattern_labels, row_block_columns, is_mp_other,
    column_to_block, residual_cols, residual_rates, rng
)
print("\n=== apply_residual_noise ===")
print(out3)

# --- 8. reinsert_pattern_missingness (all three steps at once, from scratch) ---
final = reinsert_pattern_missingness(
    synth_features, synth_pattern_labels, column_to_block, label_to_itemset,
    residual_cols, residual_rates, mp_other_masks, seed=42
)
print("\n=== reinsert_pattern_missingness (full pipeline) ===")
print(final)
