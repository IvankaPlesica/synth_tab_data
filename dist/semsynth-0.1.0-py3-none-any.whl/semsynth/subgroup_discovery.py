"""
Minimal subgroup discovery:

1. Cluster the full/imputed data.
2. Detect outliers by distance to their assigned cluster centroid.
3. Explain clusters with a shallow decision tree trained on raw/sparse data.
4. Explain the outlier rule with a second shallow decision tree.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, export_text
import joblib

from categorical_encoder import CategoricalEncoder
from dataset_registry import DATASET_REGISTRY


# ============================================================
# Configuration
# ============================================================

K = 2
RANDOM_STATE = 42
OUTLIER_STD = 2.0
TREE_DEPTH = 3

config = DATASET_REGISTRY["ckd"]
cat_cols = config["categorical_cols"]


# ============================================================
# 1. Load data
# ============================================================

df = config["loader"]()

# Keep the original dataframe untouched.
X = df.drop(columns=["class"]).copy()

for col in cat_cols:
    X[col] = X[col].astype("object")

num_cols = [c for c in X.columns if c not in cat_cols]


# ============================================================
# 2. Prepare data for clustering
# ============================================================
# KMeans cannot handle missing values, so create a complete
# representation for clustering.
#
# This does NOT modify X. The raw/sparse X is retained for
# explanation later.

medians = X[num_cols].median()
modes = X[cat_cols].mode().iloc[0]

X_filled = X.copy()
X_filled[num_cols] = X_filled[num_cols].fillna(medians)
X_filled[cat_cols] = X_filled[cat_cols].fillna(modes)


# Encode categorical variables.
encoder = CategoricalEncoder().fit(X_filled)
X_encoded = encoder.transform(X_filled)


# Standardize features so variables are on comparable scales.
scaler = StandardScaler().fit(X_encoded)
X_scaled = scaler.transform(X_encoded)


# ============================================================
# 3. Clustering
# ============================================================

kmeans = KMeans(
    n_clusters=K,
    n_init=10,
    random_state=RANDOM_STATE,
)

cluster_labels = kmeans.fit_predict(X_scaled)

print("\n=== CLUSTERS ===")

cluster_sizes = (
    pd.Series(cluster_labels)
    .value_counts()
    .sort_index()
)

print("Cluster sizes:")
print(cluster_sizes.to_dict())

print(
    f"Silhouette score: "
    f"{silhouette_score(X_scaled, cluster_labels):.3f}"
)


# ============================================================
# 4. Cluster characterization
# ============================================================
# Use the ORIGINAL sparse data here.
# Missing values remain missing rather than being reported as
# imputed observations.

print("\n=== CLUSTER CHARACTERIZATION ===")

for cluster in sorted(np.unique(cluster_labels)):

    mask = cluster_labels == cluster

    print(f"\nCluster {cluster} (n={mask.sum()})")

    for col in num_cols:
        values = X.loc[mask, col].dropna()

        if len(values):
            print(
                f"  {col}: "
                f"mean={values.mean():.2f}, "
                f"sd={values.std():.2f}"
            )

    for col in cat_cols:
        values = X.loc[mask, col].dropna()

        if len(values):
            mode = values.mode().iloc[0]
            proportion = (values == mode).mean()

            print(
                f"  {col}: "
                f"{mode} ({proportion:.0%})"
            )


# ============================================================
# 5. Explain clusters
# ============================================================
# Important:
#   clustering = complete/imputed representation
#   explanation = original sparse representation
#
# The tree therefore tries to recover simple rules that explain
# the cluster assignments while retaining missingness information.

print("\n=== CLUSTER EXPLANATION ===")

X_sparse_encoded = encoder.transform(X)

cluster_tree = DecisionTreeClassifier(
    max_depth=TREE_DEPTH,
    random_state=RANDOM_STATE,
)

cluster_tree.fit(X_sparse_encoded, cluster_labels)

print(
    export_text(
        cluster_tree,
        feature_names=list(X_sparse_encoded.columns),
    )
)

print(
    f"Tree fidelity: "
    f"{cluster_tree.score(X_sparse_encoded, cluster_labels):.1%}"
)


# ============================================================
# 6. Detect cluster outliers
# ============================================================
# Distance is measured in the standardized clustering space.
#
# Each observation is compared with the centroid of the cluster
# it was assigned to.
#
# The threshold is calculated separately for each cluster because
# clusters may have different spreads.

print("\n=== OUTLIERS ===")

distances = np.linalg.norm(
    X_scaled - kmeans.cluster_centers_[cluster_labels],
    axis=1,
)

outlier_mask = np.zeros(len(X), dtype=bool)
cluster_cutoffs = {}

for cluster in sorted(np.unique(cluster_labels)):

    mask = cluster_labels == cluster
    cluster_distances = distances[mask]

    cutoff = (
        cluster_distances.mean()
        + OUTLIER_STD * cluster_distances.std()
    )

    cluster_cutoffs[cluster] = cutoff

    outlier_mask[mask] = (
        cluster_distances > cutoff
    )


print(
    f"Outliers: "
    f"{outlier_mask.sum()} / {len(X)}"
)

print("Outliers by cluster:")
print(
    pd.Series(cluster_labels[outlier_mask])
    .value_counts()
    .sort_index()
    .to_dict()
)


# ============================================================
# 7. Explain the outliers
# ============================================================
# Again, use the ORIGINAL sparse representation.
#
# The tree is not the actual outlier detector. The distance rule
# above is the detector. The tree is only a human-readable
# approximation/explanation of which characteristics distinguish
# the flagged observations.

print("\n=== OUTLIER EXPLANATION ===")

outlier_tree = DecisionTreeClassifier(
    max_depth=TREE_DEPTH,
    random_state=RANDOM_STATE,
)

outlier_tree.fit(
    X_sparse_encoded,
    outlier_mask.astype(int),
)

print(
    export_text(
        outlier_tree,
        feature_names=list(X_sparse_encoded.columns),
    )
)

print(
    f"Outlier-tree fidelity: "
    f"{outlier_tree.score(X_sparse_encoded, outlier_mask.astype(int)):.1%}"
)


# ============================================================
# 8. Add results to a dataframe
# ============================================================

results = df.copy()

results["cluster"] = cluster_labels
results["cluster_distance"] = distances
results["outlier"] = outlier_mask

print("\n=== FINAL SUMMARY ===")

print(
    results[
        ["cluster", "cluster_distance", "outlier"]
    ].head()
)


# ============================================================
# 9. Save subgroup definitions for reuse on synthetic data
# ============================================================

joblib.dump(
    {
        # Cluster definition
        "encoder": encoder,
        "scaler": scaler,
        "kmeans": kmeans,

        # Imputation parameters used before clustering
        "medians": medians,
        "modes": modes,

        # Outlier definition
        "cluster_cutoffs": cluster_cutoffs,

        # Human-readable approximation of the outlier rule
        "outlier_tree": outlier_tree,

        # Human-readable explanation of the clusters
        "cluster_tree": cluster_tree,

        # Configuration
        "cat_cols": cat_cols,
        "num_cols": num_cols,
        "K": K,
        "outlier_std": OUTLIER_STD,
    },
    "subgroup_model.joblib",
)

print("\nSaved subgroup model to subgroup_model.joblib")


'''
REAL DATA
   │
   ├── imputation parameters
   ├── encoder
   ├── scaler
   └── KMeans
          │
          ├── clusters
          │
          └── centroid distances
                 │
                 └── cutoffs
                        │
                        ▼
                  OUTLIER RULE
                        │
                        ▼
              subgroup_model.joblib
                        │
             ┌──────────┴──────────┐
             ▼                     ▼
        S1 / S2 data          explanations
        scoring               via trees
'''