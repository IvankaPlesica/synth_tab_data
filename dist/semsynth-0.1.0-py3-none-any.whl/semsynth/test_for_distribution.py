import pandas as pd
from itertools import combinations
from efficient_apriori import apriori

df = pd.read_csv("ckd_with_egfr.csv")
exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df = df.drop(columns=[c for c in exclude_cols if c in df.columns])

cols = [c for c in df.columns if df[c].isnull().any()]
M = df[cols].isnull()

mask = M.to_numpy()
col_names = M.columns.to_numpy()
transactions = [tuple(col_names[row]) for row in mask]

# mine ALL frequent itemsets (not filtered to maximal) at a low support
# so subsets of your reported blocks are guaranteed to be included
itemsets, _ = apriori(transactions, min_support=0.05)

n_rows = len(M)


def get_support_count(itemset):
    size = len(itemset)
    key = tuple(sorted(itemset))
    if size not in itemsets or key not in itemsets[size]:
        return None
    entry = itemsets[size][key]
    # efficient_apriori returns a plain int unless output_transaction_ids=True
    return entry.itemset_count if hasattr(entry, "itemset_count") else entry


def retention_of(itemset):
    count_S = get_support_count(itemset)
    if count_S is None:
        return None
    singleton_counts = [get_support_count((c,)) for c in itemset]
    if any(c is None for c in singleton_counts):
        return None
    weakest = min(singleton_counts)
    return count_S / weakest


# --- Check every subset (size >= 2) of each known maximal block ---
known_blocks = {
    "urinalysis (maximal, reported)": ["al", "pc", "rbc", "sg", "su"],
    "cbc (maximal, reported)": ["hemo", "pcv", "rbcc", "wbcc"],
}

for label, block in known_blocks.items():
    print(f"\n=== Subsets of {label}: {block} ===")
    full_retention = retention_of(tuple(block))
    print(f"  Full itemset retention: {full_retention}")

    results = []
    for size in range(2, len(block)):  # proper subsets only, size >= 2
        for subset in combinations(block, size):
            r = retention_of(subset)
            if r is not None:
                results.append((subset, r))

    results.sort(key=lambda x: -x[1])
    for subset, r in results:
        flag = "  <-- HIGHER than full itemset!" if r > full_retention else ""
        print(f"  {subset}: retention={r:.3f}{flag}")