"""Minimal subgroup discovery for hepatitis: cluster real data, explain the
clusters with a tree, then check whether the same subgroups show up in
synthetic data. Same shape as simple_subgroups.py (CKD) -- see that file
for the fuller walkthrough comments.

Limitations (deliberate, given how simple this script is meant to stay):

- K is fixed at 2, not auto-selected by the script. That value isn't
  arbitrary -- an empirical sweep across k=2/3 found k=2 clearly better on
  seed stability and silhouette (0.193 vs. lower at k=3, which also
  produced a degenerate near-singleton cluster). But that comparison was
  done by hand, outside the script, and isn't re-verified automatically --
  if the input data changes meaningfully, k should be re-checked, not
  assumed.
- No clinical-outcome validation. An earlier version tested clusters
  against ALBI-derived liver-severity grade, but grade is a direct function
  of clustering features (bilirubin, albumin, age), making that test partly
  circular -- and much more circular here than the CKD equivalent (removing
  those three features gutted most of the clustering signal, chi2 dropped
  ~57%). This version answers a narrower question instead -- "does this
  structure survive synthesis" -- not "is this structure clinically
  meaningful." The cluster characterization table (Step 1c) gives
  face-validity only: it describes what each cluster looks like, it doesn't
  statistically test whether that pattern is more than chance.
- "Independent refit" (Step 3b) means fully refitting imputation, encoding,
  and scaling on the synthetic data from scratch, not just refitting KMeans
  on data still passed through real data's fitted transformers (which is
  what subgroup_clustering.py's check_persistence does instead). The two
  scripts' ARI numbers are not directly comparable for this reason -- this
  script's is the stricter test.
- Imputation is plain median/mode fill, not the MICE/mechanism-aware
  imputation used elsewhere in this project (imputation.py) -- chosen for
  readability, at the cost of a cruder reference clustering.
- Restricted to survivors only (class != positive_label), to avoid trivially
  rediscovering the mortality/severity split, so findings describe subgroup
  structure among survivors only, not the full dataset. An earlier attempt
  at hepatitis-positive-only (deaths, n=32) was tried this session and found
  too small for stable clustering -- not revisited here.
- ARI measures whether the same aggregate cluster structure/proportions
  re-emerge, not whether individual synthetic patients correspond to
  specific real patients -- there's no such 1:1 pairing to check.
- Everything reported (cluster sizes, the tree, the characterization table)
  comes from one fixed random seed (42). Seed stability is checked
  separately (Step 1b) and is reasonably high (ARI=0.837), but the specific
  numbers/rules printed are one draw from that distribution, not an average.
- The characterization table (Step 1c) is descriptive only -- means/SDs and
  modes with no significance testing or multiple-comparison correction, and
  cluster 1 here is only n=46, so its percentages should be read cautiously.
- Persistence results are notably weaker and less consistent than CKD's
  (S1 ARI=0.269, S2 ARI=0.596 -- opposite ranking from CKD, and from what
  subgroup_clustering.py's stricter-on-preprocessing but looser-on-
  independence check found for the same data) -- hepatitis's smaller sample
  size (n=123 survivors vs. CKD's n=250 positive) likely makes this
  comparison more sensitive to exactly how it's run.
- The tree (Step 2) is fit on RAW data while the cluster labels it's
  explaining were produced from IMPUTED data -- so for rows with missing
  values, the tree is learning to predict a label that was partly decided
  by a filled-in value it can no longer see. This is the intended
  trade-off (missingness becomes an explanatory signal instead of being
  hidden by imputation), not a bug, but it does mean tree fidelity can
  never reach 100% by construction on rows where imputation mattered to
  the original cluster assignment. It also doesn't reliably surface
  missingness as a signal -- whether it shows up depends entirely on
  which features this shallow (depth-3) tree happens to split on; for
  this dataset at k=2 the tree happened to split only on complete
  features, so the rules are identical to the pre-change (imputed) version.
"""

from itertools import combinations

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, export_text

from categorical_encoder import CategoricalEncoder
from dataset_registry import DATASET_REGISTRY

K = 2  # fixed cluster count -- no silhouette search, nothing to tune

config = DATASET_REGISTRY["hepatitis"]
cat_cols = config["categorical_cols"]

real_df = pd.read_csv("hepatitis_synthetic_b.csv")
negative_label = next(v for v in real_df["class"].unique() if v != config["positive_label"])
real_df = real_df[real_df["class"] == negative_label].reset_index(drop=True)  # restrict to survivors only,
# so clusters reflect phenotype among people who lived instead of re-deriving the mortality/severity split
real = real_df.drop(columns=["class"])
real[cat_cols] = real[cat_cols].astype("object")  # mark these as categorical per dataset_registry.py's labeling
num_cols = [c for c in real.columns if c not in cat_cols]

medians = real[num_cols].median()  # fill values learned from REAL data only, reused below for synthetic too
modes = real[cat_cols].mode().iloc[0]


def prep(df):  # impute using real-data stats only -- keeps real and synthetic in the same reference frame
    out = df.copy()
    out[num_cols] = out[num_cols].fillna(medians)
    out[cat_cols] = out[cat_cols].fillna(modes)
    return out


# Step 1: cluster real patient data into subgroups.
imputed = prep(real)
encoder = CategoricalEncoder().fit(imputed)          # turn category columns into integer codes
encoded = encoder.transform(imputed)
scaler = StandardScaler().fit(encoded)               # put every feature on a comparable scale for KMeans
scaled = scaler.transform(encoded)
kmeans = KMeans(n_clusters=K, n_init=10, random_state=42).fit(scaled)
cluster_labels = kmeans.labels_
print(f"Cluster sizes: {pd.Series(cluster_labels).value_counts().sort_index().to_dict()}")
print(f"Silhouette score: {silhouette_score(scaled, cluster_labels):.3f}")  # cluster separation/cohesion,
# reported as a quality descriptor only -- K is fixed above, not chosen by this score

# Step 1b: check this isn't just an artifact of one random seed -- refit with 10 different
# seeds and see how often they agree (Adjusted Rand Index: 1.0 = identical, 0.0 = random chance).
seed_runs = [KMeans(n_clusters=K, n_init=10, random_state=s).fit_predict(scaled) for s in range(10)]
seed_aris = [adjusted_rand_score(a, b) for a, b in combinations(seed_runs, 2)]
print(f"Seed stability (10 seeds): mean ARI={sum(seed_aris) / len(seed_aris):.3f}")

# Step 1c: describe each cluster -- mean +/- SD for numeric columns, most-common value (and its
# share) for categorical columns. Computed on RAW (non-imputed) values so missing data isn't
# silently counted as an observed value.
summary = {}
for c in sorted(set(cluster_labels)):
    mask = cluster_labels == c
    col_stats = {}
    for col in num_cols:
        vals = real.loc[mask, col]
        col_stats[col] = f"{vals.mean():.2f} +/- {vals.std():.2f}"
    for col in cat_cols:
        vals = real.loc[mask, col].dropna()
        if len(vals):
            mode = vals.mode().iloc[0]
            col_stats[col] = f"{mode} ({(vals == mode).mean():.0%})"
    summary[f"cluster {c} (n={int(mask.sum())})"] = col_stats
print("\nCluster characterization:")
print(pd.DataFrame(summary).to_string())

# Step 2: explain the clusters with a small decision tree. Clustering above needed the IMPUTED data
# (KMeans can't handle NaN), but the tree doesn't -- fit it on the RAW (non-imputed) data instead, so
# sklearn's native NaN-routing can use missingness itself as a split signal, not just filled-in values.
sparse_encoded = encoder.transform(real)  # same encoder as above, but on real (unfilled) data -- NaNs stay NaN
tree = DecisionTreeClassifier(max_depth=3, random_state=42).fit(sparse_encoded, cluster_labels)
print("\nCluster explanation (decision tree rules):")
print(export_text(tree, feature_names=list(sparse_encoded.columns)))
print(f"Decision tree reproduces {tree.score(sparse_encoded, cluster_labels):.1%} of cluster assignments")

# Step 3: do the same subgroups show up in synthetic data? Route synthetic rows through the SAME
# imputer/encoder/scaler/KMeans fit on real data above (never refit on synthetic), then compare
# how big each cluster is in real vs. synthetic data.
# (a) Transfer: route synthetic rows through the SAME imputer/encoder/scaler/KMeans fit on real data
#     above (never refit), then compare cluster proportions to real.
# (b) Independent refit: cluster synthetic data completely from scratch (its own imputation values,
#     its own encoder, its own scaler, its own KMeans fit -- as if real data was never seen), then
#     compare to (a) via Adjusted Rand Index. ARI doesn't care which cluster is numbered 0 vs. 1, so
#     no label-matching step is needed. High ARI means the same subgroups re-emerge from synthetic
#     data on their own, not just because they were forced through real's cluster centroids.
real_prop = pd.Series(cluster_labels).value_counts(normalize=True).sort_index()
print(f"\nReal cluster proportions:      {real_prop.round(3).to_dict()}")
for variant in ["s1", "s2"]:
    synth_df = pd.read_csv(f"hepatitis_synthetic_{variant}.csv")
    synth_df = synth_df[synth_df["class"] == negative_label].reset_index(drop=True)
    synth = synth_df.drop(columns=["class"])
    synth[cat_cols] = synth[cat_cols].astype("object")

    transfer_scaled = scaler.transform(encoder.transform(prep(synth)))
    transfer_labels = kmeans.predict(transfer_scaled)
    transfer_prop = pd.Series(transfer_labels).value_counts(normalize=True).sort_index()

    synth_imputed = synth.copy()
    synth_imputed[num_cols] = synth[num_cols].fillna(synth[num_cols].median())
    synth_imputed[cat_cols] = synth[cat_cols].fillna(synth[cat_cols].mode().iloc[0])
    synth_encoded = CategoricalEncoder().fit_transform(synth_imputed)
    synth_scaled = StandardScaler().fit_transform(synth_encoded)
    independent_labels = KMeans(n_clusters=K, n_init=10, random_state=42).fit_predict(synth_scaled)
    ari = adjusted_rand_score(transfer_labels, independent_labels)

    print(f"{variant.upper()} cluster proportions (n={len(synth)}): {transfer_prop.round(3).to_dict()}"
          f"  |  independent-refit ARI={ari:.3f}")
