"""Outlier-then-subgroup detection: after the main clustering pass, find
rows that don't really fit their assigned cluster, then check whether
those leftover rows form a coherent subgroup of their own.

Builds on fit_subgroups / SubgroupModel (subgroup_clustering.py) -- not
modified here, just reused.
"""

import numpy as np

from subgroup_clustering import SubgroupModel, fit_subgroups


def find_outliers(model: SubgroupModel, threshold_std: float = 2.0) -> np.ndarray:
    """Flag rows that sit unusually far from their own assigned cluster's
    centroid, in the same encoded space fit_subgroups used for KMeans.

    A row is an outlier if its distance-to-own-centroid is more than
    threshold_std standard deviations above the MEAN distance-to-centroid
    for its own cluster -- each cluster's typical spread is its own
    reference, not a single global one.

    Returns:
        Boolean array, same length/order as model.df.
    """
    Z = model.encoder.transform(model.df)
    centroids = model.kmeans.cluster_centers_
    distances = np.linalg.norm(Z - centroids[model.cluster_labels], axis=1)

    outlier_mask = np.zeros(len(model.df), dtype=bool)
    for c in np.unique(model.cluster_labels):
        mask = model.cluster_labels == c
        d = distances[mask]
        cutoff = d.mean() + threshold_std * d.std()
        outlier_mask[mask] = d > cutoff
    return outlier_mask


def cluster_outliers(df, categorical_cols, outlier_mask, exclude_cols=None, k=2) -> SubgroupModel:
    """Cluster just the outlier rows on their own, to see if they form a
    coherent subgroup rather than being scattered noise."""
    return fit_subgroups(df[outlier_mask], categorical_cols, exclude_cols=exclude_cols, k=k)


if __name__ == "__main__":
    import pandas as pd

    from dataset_registry import DATASET_REGISTRY

    config = DATASET_REGISTRY["ckd"]
    categorical_cols = config["categorical_cols"]
    real_df = pd.read_csv("ckd_synthetic_b.csv")
    real_df = real_df[real_df["class"] == "ckd"].reset_index(drop=True)  # restrict to CKD-positive only, so
    # outliers reflect phenotype variation within the disease instead of just the ckd/notckd diagnosis boundary

    model = fit_subgroups(real_df, categorical_cols, exclude_cols=["class"])
    print(f"Main pass: k={model.k}, sizes={model.sizes}")

    outliers = find_outliers(model)
    print(f"\nFlagged {outliers.sum()} outlier rows out of {len(model.df)}")
    print("Outliers by original cluster:")
    print(pd.Series(model.cluster_labels[outliers]).value_counts().sort_index())

    outlier_model = cluster_outliers(real_df, categorical_cols, outliers, exclude_cols=["class"], k=2)
    print(f"\nOutlier subgroup sizes: {outlier_model.sizes}")
    print("\nOutlier subgroup explanation (decision tree rules):")
    print(outlier_model.rules_text)
