from efficient_apriori import apriori
from detect_relevant_blocks import detect_relevant_blocks


class MissingnessModel:

    @staticmethod
    def missing_matrix(df):
        cols = [c for c in df.columns if df[c].isnull().any()]
        return df[cols].isnull()

    def fit(self, df, min_support, min_any_confidence):
        self.min_support = min_support
        self.min_any_confidence = min_any_confidence

        M = self.missing_matrix(df)
        self.columns = list(M.columns)
        self.base_rates = M.mean().to_dict()
        self.n_rows = len(M)

        cols = M.columns.to_numpy()
        transactions = [tuple(cols[row]) for row in M.to_numpy()]
        itemsets, _ = apriori(transactions, min_support=min_support,
                              output_transaction_ids=True)

        all_blocks = detect_relevant_blocks(itemsets, min_any_confidence)

        # detect_relevant_blocks only drops itemsets that are a strict subset
        # of another -- two maximal itemsets can still partially overlap
        # (e.g. {al,pc,sg,su} and {al,rbc,sg,su}), which violates the
        # column-disjointness downstream code relies on (see
        # imputation.get_residual_cols_and_rates/build_pattern_definitions).
        # Resolve overlaps greedily in descending any_confidence order (the
        # order all_blocks is already sorted in): keep a block only if none
        # of its columns were already claimed by a stronger block.
        self.blocks = []
        claimed_cols = set()
        for b in all_blocks:
            if not b["is_relevant_block"]:
                continue
            if claimed_cols & set(b["itemset"]):
                continue
            self.blocks.append(b)
            claimed_cols.update(b["itemset"])

        self.block_conditionals = {}
        for b in self.blocks:
            key = tuple(b["itemset"])
            block_missing = M[b["itemset"]].all(axis=1)
            self.block_conditionals[key] = {
                col: block_missing[M[col]].mean() for col in b["itemset"]
            }

        return self

    def summary(self):
        print(f"{self.n_rows} rows, {len(self.columns)} columns")
        print(f"min_support={self.min_support}, "
              f"min_any_confidence={self.min_any_confidence}\n")

        print(f"Relevant blocks ({len(self.blocks)}):")
        for b in self.blocks:
            key = tuple(b["itemset"])
            print(f"  {b['itemset']}")
            print(f"    any-confidence: {b['any_confidence']:.3f}")
            print(f"    all-confidence: {b['all_confidence']:.3f}")
            print(f"    cross-support:  {b['cross_support']:.3f}")
            print(f"    conditionals: "
                  + ", ".join(f"{c}={p:.3f}" for c, p in self.block_conditionals[key].items()))

        block_cols = {c for b in self.blocks for c in b["itemset"]}
        independent = sorted(
            (c for c in self.columns if c not in block_cols),
            key=lambda c: -self.base_rates[c],
        )
        print(f"\nIndependent columns ({len(independent)}):")
        for col in independent:
            print(f"  {col}: {self.base_rates[col]:.3f}")