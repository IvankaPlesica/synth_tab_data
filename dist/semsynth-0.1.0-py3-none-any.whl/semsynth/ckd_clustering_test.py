import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from rule_mining import missing_matrix

df = pd.read_csv("ckd_patterns.csv")
M = missing_matrix(df.drop(columns=["missingness_pattern", "class"]))

# reorder columns to group clusters together
cluster_cols = ["sg", "al", "su", "wbcc", "rbcc", "pcv", "hemo",
                "sc", "bu", "bgr", "sod", "pot"]
other_cols   = [c for c in M.columns if c not in cluster_cols]
M            = M[cluster_cols + other_cols]

# sort rows by pattern then n_missing
df["n_missing"] = df.isnull().sum(axis=1)
pattern_order   = ["mp1", "mp2", "mp3", "mp_other", "mp0"]
pattern_order   = [p for p in pattern_order if p in df["missingness_pattern"].unique()]
df["pat_rank"]  = df["missingness_pattern"].map({p: i for i, p in enumerate(pattern_order)})
df_sorted       = df.sort_values(["pat_rank", "n_missing"], ascending=[True, False])
df              = df.drop(columns=["n_missing", "pat_rank"])
M_sorted        = M.loc[df_sorted.index]

# color map
patterns    = df_sorted["missingness_pattern"]
pat_colors  = {
    "mp0":      "#dddddd",
    "mp1":      "#1f77b4",
    "mp2":      "#d62728",
    "mp3":      "#e377c2",
    "mp_other": "#17becf",
}
row_colors = patterns.map(pat_colors)

fig, (ax_heat, ax_bar) = plt.subplots(
    1, 2, figsize=(16, 10),
    gridspec_kw={"width_ratios": [12, 1]}
)

ax_heat.imshow(
    M_sorted.astype(float).values,
    aspect="auto",
    cmap="Blues",
    interpolation="none"
)
ax_heat.set_xticks(range(len(M_sorted.columns)))
ax_heat.set_xticklabels(M_sorted.columns, rotation=45, ha="right", fontsize=9)
ax_heat.set_yticks([])
ax_heat.set_title("Missingness matrix sorted by pattern", fontsize=12)

# add horizontal lines between patterns
boundaries = []
prev = None
for i, p in enumerate(patterns):
    if p != prev:
        boundaries.append(i)
        prev = p
for b in boundaries[1:]:
    ax_heat.axhline(b - 0.5, color="black", linewidth=0.8)

for i, color in enumerate(row_colors):
    ax_bar.barh(i, 1, color=color, height=1)
ax_bar.set_xlim(0, 1)
ax_bar.set_ylim(0, len(df_sorted))
ax_bar.axis("off")

patches = [
    mpatches.Patch(
        color=pat_colors[p],
        label=f"{p} (n={patterns.value_counts()[p]})"
    )
    for p in pattern_order if p in patterns.values
]
ax_heat.legend(
    handles=patches,
    bbox_to_anchor=(1.15, 1),
    loc="upper left",
    fontsize=9
)

plt.close("all")
plt.tight_layout()
plt.savefig("missingness_heatmap_full.png", dpi=150, bbox_inches="tight")
plt.show()