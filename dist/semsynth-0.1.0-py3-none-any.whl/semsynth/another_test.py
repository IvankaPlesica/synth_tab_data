"""
Missingness predictability, excluding co-missingness leakage.

For each column with missing values, train a random forest to predict
whether that column is missing, using ONLY the other columns' observed
values as features -- no missingness indicator (_NA) columns, and no
median-fill (which would create its own artificial "this value is
suspiciously exactly the median" leakage). Missing predictor values are
filled with a random draw from that column's own observed distribution.
"""

import csv

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score

from dataset_registry import DATASET_REGISTRY

N_REPEATS = 20

def random_fill(df):
    """Fill each column's NaNs with random draws from that column's own
    observed values -- avoids median-fill's artificial clustering."""
    filled = df.copy()
    for col in filled.columns:
        observed = filled[col].dropna()
        if observed.empty:
            continue
        n_missing = filled[col].isna().sum()
        if n_missing:
            draws = observed.sample(n=n_missing, replace=True).values
            filled.loc[filled[col].isna(), col] = draws
    return filled


def missingness_predictability(df, n_folds, exclude_cols=None):
    MIN_CLASS_COUNT = 2 * n_folds
    exclude_cols = exclude_cols or []
    df_features = df.drop(columns=exclude_cols, errors="ignore")
    results = {}
in 
    for col in df_features.columns:
        target = df_features[col].isna().astype(int)
        n_missing = target.sum()
        n_present = len(target) - n_missing

        if n_missing < MIN_CLASS_COUNT or n_present < MIN_CLASS_COUNT:
            continue  # not enough examples in one class for reliable CV

        other_cols = [c for c in df_features.columns if c != col]
        X = df_features[other_cols]

        aucs = []
        importances = []

        for repeat in range(N_REPEATS):
            # Fill NaNs BEFORE one-hot encoding, not after: pd.get_dummies(...,
            # dummy_na=False) turns a missing categorical predictor into an
            # all-zero dummy vector rather than leaving it NaN, which random_fill
            # would then never see -- a co-missingness leak (predicting one
            # column's missingness from another column's missing-derived
            # all-zero fingerprint) hiding behind the exact leakage this script
            # is meant to exclude. Filling raw values first removes that
            # fingerprint before the dummy columns are ever created.
            X_filled_raw = random_fill(X)  # fresh random draw each repeat
            X_filled = pd.get_dummies(X_filled_raw, dummy_na=False)
            skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=repeat)

            clf = RandomForestClassifier(n_estimators=200, random_state=repeat)
            scores = cross_val_score(clf, X_filled, target, cv=skf, scoring="roc_auc")
            aucs.append(scores.mean())

            clf.fit(X_filled, target)
            importances.append(pd.Series(clf.feature_importances_, index=X_filled.columns))

        importances_df = pd.concat(importances, axis=1)
        top_predictors = importances_df.mean(axis=1).sort_values(ascending=False).head(3)

        results[col] = {
            "n_missing": int(n_missing),
            "auc_mean": round(float(np.mean(aucs)), 4),
            "auc_std": round(float(np.std(aucs)), 4),
            "top_predictors": list(top_predictors.index),
        }

    return results


if __name__ == "__main__":
    dataset_name = "ckd"
    config = DATASET_REGISTRY[dataset_name]
    df = config["loader"]()
    for c in config["categorical_cols"]:
        if c in df.columns:
            df[c] = df[c].astype("object")
    exclude_cols = ["class"]

    results = missingness_predictability(df, n_folds=config["n_splits"], exclude_cols=exclude_cols)

    ranked = sorted(results.items(), key=lambda kv: -kv[1]["auc_mean"])
    for col, res in ranked:
        print(f"{col:12s} AUC={res['auc_mean']:.4f} ± {res['auc_std']:.4f}  "
              f"(n_missing={res['n_missing']})  top: {res['top_predictors']}")

    csv_path = f"another_test_results_{dataset_name}.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["column", "n_missing", "auc_mean", "auc_std", "top_predictor_1", "top_predictor_2", "top_predictor_3"])
        for col, res in ranked:
            preds = (res["top_predictors"] + [None, None, None])[:3]
            writer.writerow([col, res["n_missing"], res["auc_mean"], res["auc_std"], *preds])
    print(f"\n(full results written to {csv_path})")