"""Standalone UMAP generator matching the pipeline preprocessing exactly.

Usage:
    python regen_umap_ckd.py <csv_path> [options]

Replicates pipeline.py DatasetState.preprocess() logic:
  - loads CSV (same format as pipeline cache)
  - applies curated SemMap metadata overrides if a mapping JSON is provided
  - merges infer_types with metadata disc/cont assignments
  - coerces types, drops NaN rows (complete cases)
  - runs umap_utils.build_umap + plot_umap

Examples:
    # CKD with curated mapping
    python regen_umap_ckd.py ../downloads-cache/uciml/336.csv.gz \
        --mapping ../mappings/uciml-336.metadata.json \
        --target class \
        --out ../output/Chronic\\ Kidney\\ Disease/umap_real.png

    # Any dataset, no mapping
    python regen_umap_ckd.py mydata.csv --target label --out umap.png
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from semsynth import umap_utils  # noqa: E402
from semsynth.semmap import Metadata  # noqa: E402
from semsynth.mappings import load_mapping_json  # noqa: E402
from semsynth.utils import (  # noqa: E402
    infer_types,
    coerce_discrete_to_category,
    coerce_continuous_to_float,
    rename_categorical_categories_to_str,
)


_CATEGORICAL_TYPES = {
    "dsv:CategoricalDataType",
    "dsv:NominalDataType",
    "dsv:OrdinalDataType",
}
_CONTINUOUS_TYPES = {
    "dsv:NumericalDataType",
    "dsv:QuantitativeDataType",
    "dsv:ContinuousDataType",
    "dsv:RatioDataType",
    "dsv:IntervalDataType",
}


def _normalise_type(value) -> str | None:
    if hasattr(value, "value"):
        return value.value
    if isinstance(value, str):
        return value.strip() or None
    return None


def build_umap_for_dataset(
    csv_path: Path,
    mapping_path: Path | None,
    out_path: Path,
    target_col: str | None,
    exclude_cols: list[str] | None = None,
    random_state: int = 42,
    max_sample: int = 1000,
    n_neighbors: int = 30,
    min_dist: float = 0.1,
) -> None:
    df = pd.read_csv(csv_path)
    if exclude_cols:
        df = df.drop(columns=[c for c in exclude_cols if c in df.columns])

    # --- apply SemMap metadata (same as pipeline's _resolve_mapping path) ---
    metadata_discrete: set[str] = set()
    metadata_continuous: set[str] = set()
    if mapping_path is not None:
        curated = load_mapping_json(mapping_path)
        df.semmap.from_jsonld(curated, convert_pint=True)
        semmap_metadata: Metadata | None = df.semmap.dataset_semmap
    else:
        semmap_metadata = df.semmap()

    if semmap_metadata is not None:
        for col in semmap_metadata.datasetSchema.columns:
            name = getattr(col, "name", None)
            if not name:
                continue
            hints = []
            if col.summaryStatistics:
                hints.append(_normalise_type(col.summaryStatistics.statisticalDataType))
            col_prop = getattr(col, "columnProperty", None)
            if col_prop and getattr(col_prop, "summaryStatistics", None):
                hints.append(_normalise_type(col_prop.summaryStatistics.statisticalDataType))
            dtype = next((h for h in hints if h), None)
            if dtype in _CATEGORICAL_TYPES:
                metadata_discrete.add(name)
            elif dtype in _CONTINUOUS_TYPES:
                metadata_continuous.add(name)
            elif col_prop and getattr(col_prop, "hasCodeBook", None):
                metadata_discrete.add(name)

    # --- merge infer_types with metadata overrides (pipeline logic) ---
    disc_cols, cont_cols = infer_types(df)
    disc_set = set(disc_cols) | metadata_discrete
    cont_set = set(cont_cols) | {n for n in metadata_continuous if n not in disc_set}
    for name in list(cont_set):
        if name in disc_set and name not in metadata_continuous:
            cont_set.discard(name)
    column_order = list(df.columns)
    disc_cols = [c for c in column_order if c in disc_set]
    cont_cols = [c for c in column_order if c in cont_set]

    print(f"disc_cols ({len(disc_cols)}): {disc_cols}")
    print(f"cont_cols ({len(cont_cols)}): {cont_cols}")

    # --- coerce types ---
    df = coerce_discrete_to_category(df, disc_cols)
    df = rename_categorical_categories_to_str(df, disc_cols)
    df = coerce_continuous_to_float(df, cont_cols)

    # --- drop NaN rows (fallback to ffill/bfill if all rows have NaN) ---
    df_no_na = df.dropna(axis=0, how="any").reset_index(drop=True)
    if df_no_na.empty:
        df_no_na = df.ffill().bfill().reset_index(drop=True)
    print(f"Complete rows: {len(df_no_na)} / {len(df)}")

    # --- color series from target column ---
    color_series = None
    if target_col and target_col in df_no_na.columns:
        color_series = df_no_na[target_col].copy()
        color_series.attrs["prov:hadRole"] = "target"

    rng = np.random.default_rng(random_state)
    art = umap_utils.build_umap(
        df_no_na,
        disc_cols,
        cont_cols,
        color_series=color_series,
        rng=rng,
        random_state=random_state,
        max_sample=max_sample,
        n_neighbors=n_neighbors,
        min_dist=min_dist,
    )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    dataset_name = csv_path.stem.split(".")[0]
    umap_utils.plot_umap(
        art.embedding,
        str(out_path),
        title=f"{dataset_name}: real (sample)",
        color_labels=art.color_labels,
    )
    print(f"Saved → {out_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("csv", type=Path, help="Path to dataset CSV (or .csv.gz)")
    parser.add_argument("--mapping", type=Path, default=None, help="SemMap metadata JSON path")
    parser.add_argument("--target", default=None, help="Target/class column for colouring")
    parser.add_argument("--out", type=Path, default=Path("umap_real.png"), help="Output PNG path")
    parser.add_argument("--exclude", default=None, help="Comma-separated column names to drop before processing")
    parser.add_argument("--random-state", type=int, default=42)
    parser.add_argument("--max-sample", type=int, default=1000)
    parser.add_argument("--n-neighbors", type=int, default=30)
    parser.add_argument("--min-dist", type=float, default=0.1)
    args = parser.parse_args()

    exclude = [c.strip() for c in args.exclude.split(",")] if args.exclude else None
    build_umap_for_dataset(
        csv_path=args.csv,
        mapping_path=args.mapping,
        out_path=args.out,
        target_col=args.target,
        exclude_cols=exclude,
        random_state=args.random_state,
        max_sample=args.max_sample,
        n_neighbors=args.n_neighbors,
        min_dist=args.min_dist,
    )


if __name__ == "__main__":
    main()
