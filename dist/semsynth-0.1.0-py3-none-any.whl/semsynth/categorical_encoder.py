import pandas as pd
import numpy as np


class CategoricalEncoder:
    """
    Converts numeric strings to numeric dtype
    Converts categorical strings to integer codes

    Learned only from training data (fit)
    Unknown categories are NaN at transform time
    """

    def __init__(self):
        self.columns_ = {}       # col -> {"type": "numeric_string"} or {"type": "categorical", "mapping": {...}}
        self.feature_names_ = None

    def fit(self, X):
        X = X.copy()
        self.feature_names_ = list(X.columns)
        self.columns_ = {}

        cat_cols = X.select_dtypes(include=["object", "category"]).columns
        for col in cat_cols:
            values = X[col].astype("string")
            non_null = values.dropna()
            numeric = pd.to_numeric(non_null, errors="coerce")

            if len(non_null) > 0 and numeric.notna().all():
                self.columns_[col] = {"type": "numeric_string"}
            else:
                categories = sorted(non_null.unique())  # deterministic order
                mapping = {category: code for code, category in enumerate(categories)}
                self.columns_[col] = {"type": "categorical", "mapping": mapping}

        return self

    def transform(self, X):
        if self.feature_names_ is None:
            raise RuntimeError("CategoricalEncoder must be fit before calling transform().")

        missing = set(self.feature_names_) - set(X.columns)
        extra = set(X.columns) - set(self.feature_names_)
        if missing or extra:
            raise ValueError(
                f"Column mismatch vs fitted data. Missing: {missing or 'none'}, "
                f"Unexpected: {extra or 'none'}"
            )

        X = X.copy()
        for col, info in self.columns_.items():
            if info["type"] == "numeric_string":
                X[col] = pd.to_numeric(X[col], errors="coerce")
            else:  # categorical
                values = X[col].astype("string")
                X[col] = values.map(info["mapping"])  # unseen categories to NaN

        return X

    def fit_transform(self, X):
        return self.fit(X).transform(X)
