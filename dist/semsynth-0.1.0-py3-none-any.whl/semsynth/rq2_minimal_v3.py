"""Standalone RQ2 skeleton for CKD: Branch R vs S1 (shadow columns, 1:1) vs S2 (shadow patterns, BLOCK-ONLY labels).

The only thing borrowed from the semsynth package is the actual PyBNesian model
call (learn_bn + a handful of dtype-coercion helpers). No pipeline.py, no TOML
config, no other backend is touched.

S2 approach here: pattern labels are based ONLY on which known clinical
blocks are fully missing (low cardinality, at most 2^n_blocks categories),
not every exact combination of missing columns (that was the full-enumeration
version, which hit 92 categories and underperformed). This isolates whether
cardinality itself, not the "exact label" idea, was the problem. Independent
(non-block) columns are reinserted separately via simple per-column rates,
same as the earlier hybrid version.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer

from load_ckd import load_ckd
from egfr_staging import add_egfr_columns

from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    infer_types,
    coerce_discrete_to_category,
    coerce_continuous_to_float,
    rename_categorical_categories_to_str,
)

# ============================================================
# 1. LOAD DATA
# ============================================================
df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
df["class"] = df["class"].str.strip()

exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

# ============================================================
# 2. SPLIT
# ============================================================
y_all = (df["class"] == "ckd").astype(int)
train_idx, test_idx = train_test_split(
    df.index, test_size=0.2, random_state=42, stratify=y_all
)

train_df = df.loc[train_idx].reset_index(drop=True)
test_df = df.loc[test_idx].reset_index(drop=True)

train_features = train_df[df_features.columns]
test_features = test_df[df_features.columns]
train_y = (train_df["class"] == "ckd").astype(int)
test_y = (test_df["class"] == "ckd").astype(int)

# ============================================================
# 3. SHARED SCORING FUNCTION
# ============================================================
def score_branch(X_train, y_train, X_test, y_test):
    cat_cols = X_train.select_dtypes(include=["object", "category"]).columns.tolist()
    X_train_enc = pd.get_dummies(X_train, columns=cat_cols, dummy_na=False)
    X_test_enc = pd.get_dummies(X_test, columns=cat_cols, dummy_na=False)
    X_test_enc = X_test_enc.reindex(columns=X_train_enc.columns, fill_value=0)

    imputer = IterativeImputer(max_iter=10, random_state=42)
    X_train_imp = imputer.fit_transform(X_train_enc)
    X_test_imp = imputer.transform(X_test_enc)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_imp)
    X_test_scaled = scaler.transform(X_test_imp)

    model = LogisticRegression(max_iter=5000, random_state=42)
    model.fit(X_train_scaled, y_train)
    proba = model.predict_proba(X_test_scaled)[:, 1]
    return round(roc_auc_score(y_test, proba), 4)

# ============================================================
# 4. BRANCH R -- baseline
# ============================================================
score_r = score_branch(train_features, train_y, test_features, test_y)
print(f"Score R (baseline): {score_r}")

# ============================================================
# 5a. BLOCK-ONLY PATTERN LABELS (low cardinality, exact match)
# ============================================================
# Known clinical blocks, taken directly from your RQ1 findings on the
# full 400-row real dataset (urinalysis panel, CBC panel).
KNOWN_BLOCKS = [
    ["al", "pc", "rbc", "sg", "su"],
    ["hemo", "pcv", "rbcc", "wbcc"],
]

def assign_block_only_patterns(df_features, known_blocks):
    """
    Labels each row only by WHICH of the known blocks is fully missing,
    ignoring all other columns. At most 2^len(known_blocks) categories.
    """
    def pattern_name(row):
        present_blocks = []
        for block in known_blocks:
            if row[block].all():
                present_blocks.append("+".join(block))
        return " & ".join(present_blocks) if present_blocks else "mp0"

    missing_mask = df_features.isnull()
    return missing_mask.apply(pattern_name, axis=1)

def derive_block_only_definitions(known_blocks, all_labels):
    """
    Maps each label back to the exact columns to blank -- straightforward
    since labels are constructed directly from known_blocks membership.
    """
    definitions = {}
    for label in all_labels:
        if label == "mp0":
            definitions[label] = []
        else:
            cols = []
            for part in label.split(" & "):
                cols.extend(part.split("+"))
            definitions[label] = cols
    return definitions

train_df["missingness_pattern"] = assign_block_only_patterns(train_features, KNOWN_BLOCKS)

block_member_cols = set()
for block in KNOWN_BLOCKS:
    block_member_cols.update(block)
independent_cols = [c for c in train_features.columns if c not in block_member_cols]
independent_rates = train_features[independent_cols].isnull().mean()

all_labels = train_df["missingness_pattern"].unique().tolist()
pattern_definitions = derive_block_only_definitions(KNOWN_BLOCKS, all_labels)

n_unique_patterns = train_df["missingness_pattern"].nunique()
print(f"\nNumber of distinct block-only patterns in training data: {n_unique_patterns}")
print(train_df["missingness_pattern"].value_counts())
print("\nPattern definitions:")
for label, cols in pattern_definitions.items():
    print(f"  {label}: {cols}")

# ============================================================
# 5b. SYNTHESIZE -- PyBNesian
# ============================================================
bn_input_cols = [
    c for c in train_df.columns
    if c not in ("egfr_star", "ckd_stage", "ckd_stage_cat")
]
train_bn_input = train_df[bn_input_cols]

train_bn_filled = train_bn_input.fillna(train_bn_input.median(numeric_only=True))
for col in train_bn_filled.select_dtypes(include="object").columns:
    mode_vals = train_bn_filled[col].mode()
    if not mode_vals.empty:
        train_bn_filled[col] = train_bn_filled[col].fillna(mode_vals.iloc[0])

working = train_bn_filled.copy()
disc_cols, cont_cols = infer_types(working)
working = coerce_discrete_to_category(working, disc_cols)
working = rename_categorical_categories_to_str(working, disc_cols)
working = coerce_continuous_to_float(working, cont_cols)

bn_art = learn_bn(working, bn_type="clg", random_state=42, arc_blacklist=[])
synth = bn_art.model.sample(len(working), seed=42)
synth_df = synth.to_pandas().reindex(columns=working.columns)
for c in disc_cols:
    if c in synth_df.columns:
        synth_df[c] = synth_df[c].astype("category")

synth_label = (synth_df["class"].astype(str) == "ckd").astype(int)
synth_pattern_labels = synth_df["missingness_pattern"].astype(str)
synth_features = synth_df.drop(columns=["class", "missingness_pattern"])

synth_df.to_csv("rq2_synthetic_raw.csv", index=False)

print(f"\nNumber of distinct patterns GENERATED by synthesizer: {synth_pattern_labels.nunique()}")
print(synth_pattern_labels.value_counts())

matched = synth_pattern_labels.isin(pattern_definitions.keys())
print(f"\nSynthetic rows whose pattern label matches a known pattern: {matched.sum()} / {len(matched)}")

# ============================================================
# 6. BRANCH S1 -- shadow COLUMNS, 1:1 transplant (no resampling)
# ============================================================
def reinsert_shadow_columns_1to1(synth_features, real_train_features):
    out = synth_features.copy().reset_index(drop=True)
    real_reset = real_train_features.reset_index(drop=True)

    n = min(len(out), len(real_reset))
    for col in real_reset.columns:
        if col not in out.columns:
            continue
        mask = real_reset[col].isnull().iloc[:n]
        out.loc[mask[mask].index, col] = np.nan

    return out

s1_features = reinsert_shadow_columns_1to1(synth_features, train_features)
score_s1 = score_branch(s1_features, synth_label, test_features, test_y)
print(f"\nScore S1 (shadow columns, 1:1): {score_s1}")

# ============================================================
# 7. BRANCH S2 -- BLOCK-ONLY pattern labels, deterministic block
#    reinsertion, plus simple independent per-column reinsertion
# ============================================================
def reinsert_block_only_patterns(
    synth_features, synth_pattern_labels, pattern_definitions,
    independent_cols, independent_rates, seed=42
):
    rng = np.random.default_rng(seed)
    out = synth_features.copy()

    # deterministic block-level reinsertion
    for i, label in enumerate(synth_pattern_labels):
        cols_to_blank = pattern_definitions.get(label, [])
        for col in cols_to_blank:
            if col in out.columns:
                out.iloc[i, out.columns.get_loc(col)] = np.nan

    # independent per-column reinsertion for non-block columns
    for col in independent_cols:
        if col not in out.columns:
            continue
        rate = independent_rates.get(col, 0)
        mask = rng.random(len(out)) < rate
        out.loc[mask, col] = np.nan

    return out

s2_features = reinsert_block_only_patterns(
    synth_features, synth_pattern_labels, pattern_definitions,
    independent_cols, independent_rates, seed=42
)
score_s2 = score_branch(s2_features, synth_label, test_features, test_y)
print(f"Score S2 (shadow patterns, block-only): {score_s2}")

# ============================================================
# SAVE OUTPUTS
# ============================================================
s1_with_label = s1_features.copy()
s1_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s1_with_label.to_csv("rq2_synthetic_s1.csv", index=False)

s2_with_label = s2_features.copy()
s2_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s2_with_label.to_csv("rq2_synthetic_s2.csv", index=False)

# ============================================================
# 8. RESULTS
# ============================================================
print("\n--- RQ2 skeleton results (block-only pattern labels) ---")
print(f"Score R : {score_r}")
print(f"Score S1: {score_s1}")
print(f"Score S2: {score_s2}")
