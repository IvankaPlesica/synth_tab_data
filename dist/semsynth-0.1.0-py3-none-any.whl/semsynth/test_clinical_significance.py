import pandas as pd
import numpy as np

df = pd.read_csv('/Users/goran/semsynth/downloads-cache/uciml/46.csv.gz')
print(f"Shape: {df.shape}")
print(f"\nColumns: {df.columns.tolist()}")
print(f"\nMissingness per column:")
print(df.isnull().mean().round(3).sort_values(ascending=False))
print(f"\nTotal missing: {df.isnull().sum().sum()}")
print(f"Complete rows: {df.notna().all(axis=1).sum()} / {len(df)}")
print(f"\nFirst 3 rows:")
print(df.head(3))