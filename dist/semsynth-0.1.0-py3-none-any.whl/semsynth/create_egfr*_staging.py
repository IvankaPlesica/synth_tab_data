import pandas as pd
import numpy as np

from egfr_staging import add_egfr_columns
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")