import numpy as np
import pandas as pd

from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
from sklearn.tree import DecisionTreeClassifier, export_text

np.random.seed(42)

# -------------------------
# 1. Synthetic data
# -------------------------
X, _ = make_blobs(
    n_samples=600,
    centers=3,
    n_features=4,
    cluster_std=2.8,
    random_state=42
)

df = pd.DataFrame(X, columns=["age", "ck", "albumin", "bp"])

# -------------------------
# 2. Inject missingness
# -------------------------
df.loc[df.sample(frac=0.25, random_state=1).index, "ck"] = np.nan
df.loc[df.sample(frac=0.18, random_state=2).index, "albumin"] = np.nan

# -------------------------
# 3. Missingness indicators
# -------------------------
df["ck_missing"] = df["ck"].isna().astype(int)
df["albumin_missing"] = df["albumin"].isna().astype(int)

# -------------------------
# 4. Simple imputation ONLY for clustering step
#    (not for surrogate model logic)
# -------------------------
cluster_data = df[["age", "ck", "albumin", "bp"]].copy()
cluster_data = cluster_data.fillna(cluster_data.median())

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["cluster"] = kmeans.fit_predict(cluster_data)

# -------------------------
# 5. IMPORTANT: keep NaNs in surrogate model
# -------------------------
features = ["age", "ck", "albumin", "bp", "ck_missing", "albumin_missing"]

X = df[features]
y = df["cluster"]

# -------------------------
# 6. Tree that can handle NaNs (CRITICAL CHANGE)
# -------------------------
tree = DecisionTreeClassifier(
    max_depth=3,
    min_samples_leaf=25,
    random_state=42
)

tree.fit(X, y)

# -------------------------
# 7. Extract rules
# -------------------------
rules = export_text(tree, feature_names=features)

print("\n=== SURROGATE DECISION RULES ===\n")
print(rules)

print("\n=== INTERPRETATION ===")
print("ck_missing = 1 → CK is missing")
print("albumin_missing = 1 → albumin is missing")
print("Rules may combine age + missingness cleanly.")