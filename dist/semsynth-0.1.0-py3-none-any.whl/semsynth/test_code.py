from collections import defaultdict


def prove_rule_redundancy(rules):
    """
    For each rule (A -> B), compute the union of its antecedent and
    consequent columns -- the "core" set of columns the rule is actually
    about, regardless of which side is antecedent vs consequent.

    If many distinct rules share the same core, that's direct, provable
    evidence those rules are combinatorial restatements of one underlying
    pattern, not independent discoveries.

    Parameters
    ----------
    rules : list of efficient_apriori Rule objects (have .lhs, .rhs)

    Returns
    -------
    dict mapping core (frozenset) -> list of rules sharing that core,
    sorted so the most "restated" cores come first.
    """
    by_core = defaultdict(list)
    for r in rules:
        core = frozenset(r.lhs) | frozenset(r.rhs)
        by_core[core].append(r)

    summary = sorted(by_core.items(), key=lambda kv: -len(kv[1]))

    print(f"Total rules: {len(rules)}")
    print(f"Distinct underlying cores: {len(summary)}")
    print(f"Compression ratio: {len(rules) / len(summary):.1f}x "
          f"(average rules per core)\n")

    for core, core_rules in summary:
        print(f"Core {sorted(core)} ({len(core)} columns): "
              f"{len(core_rules)} rules restate this same core")

    return by_core