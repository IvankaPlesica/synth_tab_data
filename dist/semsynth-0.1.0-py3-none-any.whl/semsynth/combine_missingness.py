"""Combine rules_combined.json and mar_mnar_results.json into missingness patterns.

Community detection (Louvain, weighted by lift) groups columns that strongly
co-miss together. Tune `resolution` (higher = finer clusters) or `min_lift`
(prune weak cross-cluster edges) to adjust granularity.

Usage:
    python combine_missingness.py                          # defaults
    python combine_missingness.py rules.json mar.json      # custom paths
    python combine_missingness.py rules.json mar.json 1.5  # resolution
    python combine_missingness.py rules.json mar.json 1.0 5.0  # + min_lift
"""

import json
import sys
from itertools import combinations

try:
    import networkx as nx
    from networkx.algorithms.community import louvain_communities
except ImportError:
    raise SystemExit("pip install networkx")


def build_patterns(
    rules_path: str,
    mar_mnar_path: str,
    resolution: float = 1.0,
    min_lift: float | None = None,
) -> list[dict]:
    """Return missingness patterns as a list of dicts.

    Args:
        rules_path: Path to rules_combined.json (list of association rules).
        mar_mnar_path: Path to mar_mnar_results.json (dict of column → auc/missing_rate).
        resolution: Louvain resolution — higher values produce more, smaller clusters.
        min_lift: If set, only edges with lift >= min_lift are added to the graph,
                  which prunes weak inter-cluster links and tends to split merged clusters.
    """
    with open(rules_path) as f:
        rules: list[dict] = json.load(f)
    with open(mar_mnar_path) as f:
        mar: dict = json.load(f)

    mar_cols = set(mar.keys())

    G = nx.Graph()
    for r in rules:
        if min_lift is not None and r["lift"] < min_lift:
            continue
        cols = r["if_missing"] + [r["then_missing"]]
        for a, b in combinations(cols, 2):
            if G.has_edge(a, b):
                G[a][b]["weight"] = max(G[a][b]["weight"], r["lift"])
            else:
                G.add_edge(a, b, weight=r["lift"])

    communities = sorted(
        louvain_communities(G, weight="weight", resolution=resolution, seed=42),
        key=len,
        reverse=True,
    )

    patterns = []
    for i, community in enumerate(communities, 1):
        cols = sorted(community)

        inner_rules = [
            r for r in rules
            if set(r["if_missing"] + [r["then_missing"]]) <= community
        ]
        lifts = [r["lift"] for r in inner_rules]
        aucs = [mar[c]["auc"] for c in cols if c in mar_cols]
        missing_rates = [mar[c]["missing_rate"] for c in cols if c in mar_cols]

        patterns.append({
            "id": f"mp{i}",
            "columns": cols,
            "lift_range": [round(min(lifts), 2), round(max(lifts), 2)] if lifts else None,
            "auc_range": [round(min(aucs), 3), round(max(aucs), 3)] if aucs else None,
            "missing_rate_range": [
                round(min(missing_rates), 4), round(max(missing_rates), 4)
            ] if missing_rates else None,
            "columns_without_auc": [c for c in cols if c not in mar_cols],
        })

    return patterns


def print_table(patterns: list[dict]) -> None:
    print(f"{'ID':<6} {'Columns':<40} {'Rules (lift)':<14} {'AUC range'}")
    print("-" * 78)
    for p in patterns:
        cols = ", ".join(p["columns"])
        lift = (
            f"{p['lift_range'][0]}–{p['lift_range'][1]}" if p["lift_range"] else "—"
        )
        auc = (
            f"{p['auc_range'][0]}–{p['auc_range'][1]}" if p["auc_range"] else "—"
        )
        print(f"{p['id']:<6} {cols:<40} {lift:<14} {auc}")
        if p["columns_without_auc"]:
            print(f"       (no AUC: {', '.join(p['columns_without_auc'])})")


if __name__ == "__main__":
    rules_path = sys.argv[1] if len(sys.argv) > 1 else "rules_combined.json"
    mar_path   = sys.argv[2] if len(sys.argv) > 2 else "mar_mnar_results.json"
    resolution = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
    min_lift   = float(sys.argv[4]) if len(sys.argv) > 4 else None

    patterns = build_patterns(rules_path, mar_path, resolution=resolution, min_lift=min_lift)

    out_path = "missingness_patterns.json"
    with open(out_path, "w") as f:
        json.dump(patterns, f, indent=2)
    print(f"Saved {out_path}  (resolution={resolution}, min_lift={min_lift})\n")

    print_table(patterns)
