"""Subgroup discovery restricted to CKD-positive patients (k=2).

Clustering the full CKD population (CKD vs. not-CKD together) mostly just
rediscovers the diagnostic boundary -- the features that separate the two
classes (creatinine, hypertension) are close to the actual diagnostic
criteria, so the "subgroups" aren't new information beyond the class label.

Restricting to CKD-positive rows only removes that trivial split and finds
a real severity/phenotype subtype instead: an anemic/complicated-CKD group
(low hemoglobin, high blood urea, low red blood cell count) vs. a
less-complicated CKD group. Confirmed stable (20/20 resamples independently
agree on k=2, seed ARI=0.984) -- unlike the not-CKD-only population, which
has no stable subgroup structure at all (silhouette=0.088, resample
ARI=0.258) and isn't worth clustering.

k is fixed at 2 here (not auto-picked) since that's the validated,
stable result -- rerun subgroup_clustering.fit_subgroups directly with
k=None if you want to re-check whether a different k emerges later.
"""

import pandas as pd

from dataset_registry import DATASET_REGISTRY
from egfr_staging import add_egfr_columns
from subgroup_clustering import check_persistence, check_real_stability, fit_subgroups, print_outcome_result, test_cluster_outcome

K = 2


def run():
    config = DATASET_REGISTRY["ckd"]
    real_df = pd.read_csv("ckd_synthetic_b.csv")
    real_ckd = real_df[real_df["class"] == "ckd"].reset_index(drop=True)
    print(f"CKD-positive rows: {len(real_ckd)} (of {len(real_df)} total)")

    model = fit_subgroups(real_ckd, config["categorical_cols"], exclude_cols=["class"], k=K)
    print(f"\nk={model.k} (silhouette={model.silhouette:.3f}), n={len(real_ckd)}")
    print("Cluster sizes:", model.sizes)
    print(f"\nExplain-tree train accuracy: {model.tree_train_accuracy:.3f}")
    print(model.rules_text)

    print("\n--- Real-data (CKD-only) cluster stability ---")
    stability = check_real_stability(real_ckd, config["categorical_cols"], exclude_cols=["class"], k=model.k)
    print(f"  Seed stability: mean ARI={stability['seed_ari_mean']:.3f} (std={stability['seed_ari_std']:.3f})")
    print(f"  Resample k agreement: {stability['k_agreement']}")
    if stability["resample_ari_mean"] is not None:
        print(f"  Resample mean ARI={stability['resample_ari_mean']:.3f} (std={stability['resample_ari_std']:.3f})")

    print("\n--- Cluster vs distal outcome (CKD-only, real data) ---")
    # class is constant ("ckd") in this restricted population by construction,
    # so it isn't tested here -- only the staged CKD stage, which still varies
    # (severity within the CKD-positive group) and was never used to cluster.
    staged = add_egfr_columns(real_ckd, sc_col="sc", age_col="age")
    outcome_result = test_cluster_outcome(model, staged["ckd_stage"], outcome_type="categorical")
    print_outcome_result("ckd_stage", outcome_result)

    for variant in ["s1", "s2"]:
        print(f"\n--- {variant.upper()} persistence (CKD-only) ---")
        synth_df = pd.read_csv(f"ckd_synthetic_{variant}.csv")
        synth_ckd = synth_df[synth_df["class"] == "ckd"].reset_index(drop=True)
        print(f"  n_synth_ckd={len(synth_ckd)}")
        result = check_persistence(model, synth_ckd)
        for cid, info in result["per_cluster"].items():
            dev = ", ".join(f"{c}(z={z:.2f})" for c, (z, _) in info["top_deviations"])
            print(f"  cluster {cid}: real_prop={info['real_prop']:.3f} "
                  f"synth_prop={info['new_prop']:.3f}  top deviations: {dev}")
        if result["independent_k"] is not None:
            print(f"  independent k={result['independent_k']} "
                  f"(silhouette={result['independent_silhouette']:.3f})")
        print(f"  Persistence agreement={result['agreement']}  ARI={result['ari']}")

        # Transfer-assign synthetic rows to the real cluster centroids (same
        # labels check_persistence used above), then test those synthetic
        # rows' OWN staged CKD stage against that assignment -- does the
        # real cluster-vs-outcome relationship still hold once synthetic
        # data is routed through the real clusters?
        staged_synth = add_egfr_columns(synth_ckd, sc_col="sc", age_col="age")
        synth_outcome_result = test_cluster_outcome(
            model, staged_synth["ckd_stage"], outcome_type="categorical",
            cluster_labels=result["transfer_labels"],
        )
        print_outcome_result(f"ckd_stage ({variant.upper()} transfer-assigned)", synth_outcome_result)

    return model


if __name__ == "__main__":
    run()
