"""Out-of-fold TPR gap: pool predictions across all 5 CV folds so the
outlier group (n~19, too small to trust within any single fold) has
enough rows for a meaningful TPR estimate.
"""

import numpy as np
import pandas as pd
from anonymeter.evaluators import SinglingOutEvaluator
from sklearn.model_selection import StratifiedKFold

from imputation import mice_and_regression, simple_impute
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
from Missingness_Model import MissingnessModel
from dataset_registry import DATASET_REGISTRY
from frozen_outlier_rule import apply_outlier_rule
from subgroup_privacy_oof import attacked_rows

config = DATASET_REGISTRY["ckd"]
categorical_cols = config["categorical_cols"]
df = config["loader"]()  # safe to load fresh -- the rule itself is frozen, so this no longer matters
X = df.drop(columns=["class"])
y = (df["class"] == config["positive_label"]).astype(int)
for c in categorical_cols:
    if c in X.columns:
        X[c] = X[c].astype("object")

skf = StratifiedKFold(n_splits=config["n_splits"], shuffle=True, random_state=42)

# collect out-of-fold predictions across ALL folds, for each branch
oof_proba = {
    "R": np.full(len(df), np.nan),
    "S1": np.full(len(df), np.nan),
    "S2": np.full(len(df), np.nan),
}  # S2 re-added: synthesis.py's bn_type="semiparametric"/max_indegree=2 avoids the
# PyBNesian CLG segfault (verified clean across all 5 folds in evaluate_ckd_missingness_
# strategies.py) -- the earlier (class, pattern)-sparsity merge workaround is no longer
# needed, this uses plain run_s2_branch unmodified

# singling-out privacy risk per fold, S1/S2 only -- R has no synthetic dataset, so
# SinglingOutEvaluator doesn't apply to it
so_risk = {"S1": [], "S2": []}
so_attacked_mask = {
    "S1": pd.Series(False, index=df.index),
    "S2": pd.Series(False, index=df.index),
}  # pooled out-of-fold, same logic as oof_proba/attacked_mask above: every row is
# exactly one fold's control row

for train_idx, test_idx in skf.split(X, y):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

    # branch R: train on real, predict on this fold's held-out real rows
    _, proba_r = mice_and_regression(X_train, y_train, X_test, y_test, return_proba=True)
    oof_proba["R"][test_idx] = proba_r

    # branch S1: train on shadow-column synthesis, still predict on the SAME real X_test
    X_train_filled = simple_impute(X_train)
    shadow_cols = build_shadow_columns(X_train)
    synth_features_with_shadows, synth_label_s1 = synthesize(
        X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols
    )
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)
    _, proba_s1 = mice_and_regression(s1_features, synth_label_s1, X_test, y_test, return_proba=True)
    oof_proba["S1"][test_idx] = proba_s1

    n_attacks_s1 = min(500, len(X_train))
    so_eval_s1 = SinglingOutEvaluator(ori=X_train, syn=s1_features, control=X_test, n_attacks=n_attacks_s1)
    so_eval_s1.evaluate(mode="multivariate")
    so_risk["S1"].append(so_eval_s1.risk().value)
    hits_s1 = attacked_rows(X_test, so_eval_s1.queries())
    if hits_s1:
        so_attacked_mask["S1"].loc[list(hits_s1)] = True

    # branch S2: train on mined missingness-block synthesis, still predict on the SAME real X_test
    mining_model = MissingnessModel().fit(
        X_train, min_support=config["min_support"], min_any_confidence=config["min_any_confidence"]
    )
    s2_features, synth_label_s2 = run_s2_branch(
        X_train, X_train_filled, y_train, categorical_cols, mining_model
    )
    _, proba_s2 = mice_and_regression(s2_features, synth_label_s2, X_test, y_test, return_proba=True)
    oof_proba["S2"][test_idx] = proba_s2

    n_attacks_s2 = min(500, len(X_train))
    so_eval_s2 = SinglingOutEvaluator(ori=X_train, syn=s2_features, control=X_test, n_attacks=n_attacks_s2)
    so_eval_s2.evaluate(mode="multivariate")
    so_risk["S2"].append(so_eval_s2.risk().value)
    hits_s2 = attacked_rows(X_test, so_eval_s2.queries())
    if hits_s2:
        so_attacked_mask["S2"].loc[list(hits_s2)] = True

for branch, proba in oof_proba.items():
    assert not np.isnan(proba).any(), f"every row should get exactly one OOF prediction ({branch})"

# flag outliers ONCE, on the full real dataset (rule loaded from disk, fit on real data)
outlier_mask = apply_outlier_rule(df)
#outlier_mask = (df["bp"] >= 80).to_numpy()
#outlier_mask = (df["alk_phosphate"] >= 85).to_numpy()
print(f"Total outliers across full dataset: {outlier_mask.sum()} / {len(df)}")

print("\nSingling-out privacy risk (S1 vs S2):")
for branch in ["S1", "S2"]:
    mean_risk = np.mean(so_risk[branch])
    print(f"{branch}: mean risk across folds = {mean_risk:.4f} (std={np.std(so_risk[branch]):.4f})")
    attacked_arr = so_attacked_mask[branch].to_numpy()
    out_rate = attacked_arr[outlier_mask].mean() if outlier_mask.sum() else float("nan")
    non_rate = attacked_arr[~outlier_mask].mean() if (~outlier_mask).sum() else float("nan")
    print(f"  outlier subgroup attack rate:     {out_rate:.3f} "
          f"({int(attacked_arr[outlier_mask].sum())}/{int(outlier_mask.sum())})")
    print(f"  non-outlier subgroup attack rate: {non_rate:.3f} "
          f"({int(attacked_arr[~outlier_mask].sum())}/{int((~outlier_mask).sum())})")
    print(f"  gap (outlier - non-outlier): {out_rate - non_rate:+.3f}")

y_true = y.to_numpy()


def group_tpr(y_true, y_pred, mask):
    actual_pos = (y_true == 1) & mask
    if actual_pos.sum() == 0:
        return None
    return (y_pred[actual_pos] == 1).mean()


gaps = {}
for branch, proba in oof_proba.items():
    y_pred = (proba >= 0.5).astype(int)
    tpr_out = group_tpr(y_true, y_pred, outlier_mask)
    tpr_non = group_tpr(y_true, y_pred, ~outlier_mask)
    gap = tpr_non - tpr_out
    gaps[branch] = gap
    print(f"{branch}: tpr_outlier={tpr_out:.3f} (n={outlier_mask.sum()}), "
          f"tpr_non_outlier={tpr_non:.3f} (n={(~outlier_mask).sum()}), "
          f"gap={gap:.3f}")
    if branch != "R":
        delta = gap - gaps["R"]
        direction = "widens" if delta > 0 else "narrows" if delta < 0 else "matches"
        print(f"  {branch} {direction} the real-data disparity ({branch} gap - R gap = {delta:+.3f})")