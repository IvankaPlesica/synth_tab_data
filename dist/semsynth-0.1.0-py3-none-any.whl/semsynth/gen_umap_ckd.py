"""Generate umap_real.png for Chronic Kidney Disease matching the pipeline exactly.

Replicates pipeline.py DatasetState.preprocess() logic:
- loads raw cached CSV (tabs and all, same as pipeline fetched from UCI)
- applies curated SemMap type overrides (al, su → discrete; sg, etc. → continuous)
- coerces types via pipeline utils (preserving tab-polluted categories)
- drops NaN rows (complete cases)
- runs umap_utils.build_umap + plot_umap with pipeline defaults
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from semsynth import umap_utils  # noqa: E402
from semsynth.semmap import Metadata  # noqa: E402
from semsynth.mappings import load_mapping_json  # noqa: E402
from semsynth.utils import (  # noqa: E402
    infer_types,
    coerce_discrete_to_category,
    coerce_continuous_to_float,
    rename_categorical_categories_to_str,
)

CACHE_CSV = ROOT / "downloads-cache" / "uciml" / "336.csv.gz"
MAPPING = ROOT / "mappings" / "uciml-336.metadata.json"
OUT = ROOT / "output" / "Chronic Kidney Disease" / "umap_real.png"
TARGET = "class"
RANDOM_STATE = 42
MAX_SAMPLE = 1000
N_NEIGHBORS = 30
MIN_DIST = 0.1

# --- load raw data (same as pipeline, tabs preserved) ---
df = pd.read_csv(CACHE_CSV)

# --- derive metadata disc/cont from curated SemMap (same as pipeline preprocess) ---
categorical_types = {"dsv:CategoricalDataType", "dsv:NominalDataType", "dsv:OrdinalDataType"}
continuous_types = {
    "dsv:NumericalDataType", "dsv:QuantitativeDataType", "dsv:ContinuousDataType",
    "dsv:RatioDataType", "dsv:IntervalDataType",
}
meta = Metadata.from_jsonld(load_mapping_json(MAPPING))
metadata_discrete: set = set()
metadata_continuous: set = set()
for col in meta.datasetSchema.columns:
    name = getattr(col, "name", None)
    if not name:
        continue
    hints = []
    if col.summaryStatistics:
        hints.append(str(getattr(col.summaryStatistics, "statisticalDataType", "") or ""))
    cp = getattr(col, "columnProperty", None)
    if cp and getattr(cp, "summaryStatistics", None):
        hints.append(str(getattr(cp.summaryStatistics, "statisticalDataType", "") or ""))
    dtype = next((h for h in hints if h), None)
    if dtype in categorical_types:
        metadata_discrete.add(name)
    elif dtype in continuous_types:
        metadata_continuous.add(name)
    elif cp and getattr(cp, "hasCodeBook", None):
        metadata_discrete.add(name)

# --- merge infer_types with metadata overrides (pipeline logic) ---
disc_cols, cont_cols = infer_types(df)
disc_set = set(disc_cols) | metadata_discrete
cont_set = set(cont_cols) | {n for n in metadata_continuous if n not in disc_set}
for name in list(cont_set):
    if name in disc_set and name not in metadata_continuous:
        cont_set.discard(name)
column_order = list(df.columns)
disc_cols = [c for c in column_order if c in disc_set]
cont_cols = [c for c in column_order if c in cont_set]

# --- coerce types (pipeline order) ---
df = coerce_discrete_to_category(df, disc_cols)
df = rename_categorical_categories_to_str(df, disc_cols)
df = coerce_continuous_to_float(df, cont_cols)

# --- drop NaN rows ---
df_no_na = df.dropna(axis=0, how="any").reset_index(drop=True)
color_series = df_no_na[TARGET].copy()
color_series.attrs["prov:hadRole"] = "target"

print(f"disc_cols: {disc_cols}")
print(f"cont_cols: {cont_cols}")
print(f"Complete rows: {len(df_no_na)}")

rng = np.random.default_rng(RANDOM_STATE)
art = umap_utils.build_umap(
    df_no_na,
    disc_cols,
    cont_cols,
    color_series=color_series,
    rng=rng,
    random_state=RANDOM_STATE,
    max_sample=MAX_SAMPLE,
    n_neighbors=N_NEIGHBORS,
    min_dist=MIN_DIST,
)

OUT.parent.mkdir(parents=True, exist_ok=True)
umap_utils.plot_umap(
    art.embedding,
    str(OUT),
    title="Chronic Kidney Disease: real (sample)",
    color_labels=art.color_labels,
)
print(f"Saved → {OUT}")
