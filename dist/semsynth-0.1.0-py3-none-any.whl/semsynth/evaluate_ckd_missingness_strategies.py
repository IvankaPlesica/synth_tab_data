# evaluate_ckd_missingness_strategies.py
from imputation import simple_impute, mice_and_regression
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
import numpy as np
import warnings
from sklearn.model_selection import StratifiedKFold
from Missingness_Model import MissingnessModel
from statsmodels.genmod.generalized_linear_model import PerfectSeparationWarning
from dataset_registry import DATASET_REGISTRY


warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=PerfectSeparationWarning)

#dataset_name = "hepatitis"
dataset_name = "ckd"
config = DATASET_REGISTRY[dataset_name]
df = config["loader"]()
n_splits = config["n_splits"]
positive_label = config["positive_label"]
categorical_cols = config["categorical_cols"]
min_support = config["min_support"]
min_any_confidence = config["min_any_confidence"]

# Data preparation
X = df.drop(columns=["class"])
y = df["class"]

for c in categorical_cols:
    if c in X.columns:
        X[c] = X[c].astype("object")

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
print(f"\nNumber of folds: {skf.get_n_splits()}")


# ============================================================
# R / S1 / S2 over folds
# ============================================================

scores_r, scores_s1, scores_s2 = [], [], []

for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
    print(f"\nFold {fold_num+1} in progress.")
    X_train = X.iloc[train_index].copy()
    X_test = X.iloc[test_index].copy()

    y_train = (y.iloc[train_index] == positive_label).astype(int)
    y_test = (y.iloc[test_index] == positive_label).astype(int)

    # Branch R: baseline
    score_r = mice_and_regression(X_train, y_train, X_test, y_test)
    scores_r.append(score_r)
    print(f"Fold {fold_num}: Score R = {score_r}")

    # Shared: simple-impute train, reused by both S1 and S2
    X_train_filled = simple_impute(X_train)

    # Branch S1: build per-column _NA shadow indicators, synthesize with them jointly
    shadow_cols = build_shadow_columns(X_train)
    synth_features_with_shadows, synth_label_s1 = synthesize(X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols)

    # Branch S1: reinsert missingness using the synthesizer's _NA columns
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)
    score_s1 = mice_and_regression(s1_features, synth_label_s1, X_test, y_test)
    scores_s1.append(score_s1)
    print(f"Fold {fold_num}: Score S1 = {score_s1}")

    # Branch S2: shadow patterns with missingness_pattern fed in as a joint variable; see run_s2_brancn
    mining_model = MissingnessModel().fit(X_train, min_support=min_support, min_any_confidence=min_any_confidence)

    print(f"Fold {fold_num}: {len(mining_model.blocks)} missingness blocks "
          f"(min_support={min_support}, min_any_confidence={min_any_confidence}): "
          + ", ".join("+".join(b["itemset"]) for b in mining_model.blocks))

    s2_features, synth_label_s2 = run_s2_branch(X_train, X_train_filled, y_train, categorical_cols, mining_model)
    score_s2 = mice_and_regression(s2_features, synth_label_s2, X_test, y_test)
    scores_s2.append(score_s2)
    print(f"Fold {fold_num}: Score S2 = {score_s2}")

print(f"\nMean Score R:  {np.mean(scores_r):.4f} (std: {np.std(scores_r):.4f})")
print(f"Mean Score S1: {np.mean(scores_s1):.4f} (std: {np.std(scores_s1):.4f})")
print(f"Mean Score S2: {np.mean(scores_s2):.4f} (std: {np.std(scores_s2):.4f})")