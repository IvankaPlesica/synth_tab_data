"""Subgroup discovery restricted to hepatitis SURVIVORS (class != positive_label).

Clustering the full hepatitis population (both outcomes together) mostly
rediscovers mortality/severity: the k=2 split found there tracks albumin +
bilirubin, which are close to the ALBI staging markers this repo already
computes (hepatitis_albi_staging.py) -- 47% mortality in one cluster vs. 5%
in the other. Not new information beyond what ALBI staging already gives you.

Restricting to survivors only (class=2, n=123) removes that trivial outcome
split and asks the more interesting question: is there real phenotype
structure among patients who lived, independent of the mortality axis?

This mirrors ckd_subgroup_discovery.py's move (cluster CKD-positive only,
which found a real anemic-vs-not subtype) rather than the hepatitis-positive
attempt (n=32, too small -- no stable structure, see git history / the
caveat that used to be in this file). Survivors give a workable n=123,
comparable to CKD's not-CKD n=150.
"""

import pandas as pd

from dataset_registry import DATASET_REGISTRY
from hepatitis_albi_staging import add_albi_columns
from subgroup_clustering import check_persistence, check_real_stability, fit_subgroups, print_outcome_result, test_cluster_outcome


def run():
    config = DATASET_REGISTRY["hepatitis"]
    positive_label = config["positive_label"]
    real_df = pd.read_csv("hepatitis_synthetic_b.csv")
    negative_label = next(v for v in real_df["class"].unique() if v != positive_label)

    real_surv = real_df[real_df["class"] == negative_label].reset_index(drop=True)
    print(f"Hepatitis survivors (class={negative_label}) rows: {len(real_surv)} (of {len(real_df)} total)")

    model = fit_subgroups(real_surv, config["categorical_cols"], exclude_cols=["class"])
    print(f"\nChosen k={model.k} (silhouette={model.silhouette:.3f}), n={len(real_surv)}")
    print("Cluster sizes:", model.sizes)
    print(f"\nExplain-tree train accuracy: {model.tree_train_accuracy:.3f}")
    print(model.rules_text)

    print("\n--- Real-data (survivors-only) cluster stability ---")
    stability = check_real_stability(real_surv, config["categorical_cols"], exclude_cols=["class"], k=model.k)
    print(f"  Seed stability: mean ARI={stability['seed_ari_mean']:.3f} (std={stability['seed_ari_std']:.3f})")
    print(f"  Resample k agreement: {stability['k_agreement']}")
    if stability["resample_ari_mean"] is not None:
        print(f"  Resample mean ARI={stability['resample_ari_mean']:.3f} (std={stability['resample_ari_std']:.3f})")
    else:
        print("  Resample ARI: not enough overlapping rows to compute")

    print("\n--- Cluster vs distal outcome (survivors-only, real data) ---")
    # class is constant (all survivors) in this restricted population by
    # construction, so it isn't tested here -- only the staged ALBI grade,
    # which still varies (liver-function severity among survivors) and was
    # never used to cluster.
    staged = add_albi_columns(real_surv, bilirubin_col="bilirubin", albumin_col="albumin", age_col="age")
    outcome_result = test_cluster_outcome(model, staged["albi_grade"], outcome_type="categorical")
    print_outcome_result("albi_grade", outcome_result)

    for variant in ["s1", "s2"]:
        print(f"\n--- {variant.upper()} persistence (survivors-only) ---")
        synth_df = pd.read_csv(f"hepatitis_synthetic_{variant}.csv")
        synth_surv = synth_df[synth_df["class"] == negative_label].reset_index(drop=True)
        print(f"  n_synth_survivors={len(synth_surv)}")
        result = check_persistence(model, synth_surv)
        for cid, info in result["per_cluster"].items():
            dev = ", ".join(f"{c}(z={z:.2f})" for c, (z, _) in info["top_deviations"])
            print(f"  cluster {cid}: real_prop={info['real_prop']:.3f} "
                  f"synth_prop={info['new_prop']:.3f}  top deviations: {dev}")
        if result["independent_k"] is not None:
            print(f"  independent k={result['independent_k']} "
                  f"(silhouette={result['independent_silhouette']:.3f})")
        print(f"  Persistence agreement={result['agreement']}  ARI={result['ari']}")

        # Transfer-assign synthetic rows to the real cluster centroids (same
        # labels check_persistence used above), then test those synthetic
        # rows' OWN staged ALBI grade against that assignment -- does the
        # real cluster-vs-outcome relationship still hold once synthetic
        # data is routed through the real clusters?
        staged_synth = add_albi_columns(synth_surv, bilirubin_col="bilirubin", albumin_col="albumin", age_col="age")
        synth_outcome_result = test_cluster_outcome(
            model, staged_synth["albi_grade"], outcome_type="categorical",
            cluster_labels=result["transfer_labels"],
        )
        print_outcome_result(f"albi_grade ({variant.upper()} transfer-assigned)", synth_outcome_result)

    return model


if __name__ == "__main__":
    run()
