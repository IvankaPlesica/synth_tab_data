"""Real vs synthetic data comparison: marginal distributions + correlation structure."""

import pandas as pd
import numpy as np
from scipy.stats import ks_2samp, chi2_contingency

REAL_PATH = "ckd_with_egfr.csv"
SYNTH_PATH = "rq2_synthetic_s2.csv"  # or _with_egfr.csv version

real_df = pd.read_csv(REAL_PATH)
synth_df = pd.read_csv(SYNTH_PATH)

common_cols = [c for c in real_df.columns if c in synth_df.columns]

# ============================================================
# 1. MARGINAL FIDELITY — per-column distribution comparison
# ============================================================
def marginal_fidelity(real_df, synth_df, cols):
    results = {}
    for col in cols:
        real_vals = real_df[col].dropna()
        synth_vals = synth_df[col].dropna()
        if len(real_vals) == 0 or len(synth_vals) == 0:
            continue

        if real_df[col].dtype.kind in "if":  # numeric
            stat, p = ks_2samp(real_vals, synth_vals)
            results[col] = {
                "test": "KS", "stat": round(stat, 4), "p": round(p, 4),
                "real_mean": round(real_vals.mean(), 3),
                "synth_mean": round(synth_vals.mean(), 3),
                "real_std": round(real_vals.std(), 3),
                "synth_std": round(synth_vals.std(), 3),
            }
        else:  # categorical
            real_counts = real_vals.value_counts()
            synth_counts = synth_vals.value_counts().reindex(real_counts.index, fill_value=0)
            try:
                contingency = pd.DataFrame({"real": real_counts, "synth": synth_counts})
                stat, p, _, _ = chi2_contingency(contingency.T)
                results[col] = {"test": "chi2", "stat": round(stat, 4), "p": round(p, 4)}
            except ValueError:
                results[col] = {"test": "chi2", "error": "insufficient data"}
    return pd.DataFrame(results).T

marginal_results = marginal_fidelity(real_df, synth_df, common_cols)
print("=== MARGINAL FIDELITY (per-column) ===")
print(marginal_results.sort_values("p", ascending=True) if "p" in marginal_results.columns else marginal_results)

# ============================================================
# 2. JOINT FIDELITY — correlation structure comparison
# ============================================================
def joint_fidelity(real_df, synth_df, numeric_cols):
    real_corr = real_df[numeric_cols].corr()
    synth_corr = synth_df[numeric_cols].corr()
    diff = (real_corr - synth_corr).abs()

    flat_diff = diff.where(np.triu(np.ones(diff.shape), k=1).astype(bool)).stack()
    top_diffs = flat_diff.sort_values(ascending=False).head(10)

    return {
        "mean_abs_corr_diff": round(diff.values[~np.isnan(diff.values)].mean(), 4),
        "max_abs_corr_diff": round(diff.values[~np.isnan(diff.values)].max(), 4),
        "top_10_largest_diffs": top_diffs,
    }

numeric_cols = [c for c in common_cols if real_df[c].dtype.kind in "if"]
joint_results = joint_fidelity(real_df, synth_df, numeric_cols)
print("\n=== JOINT FIDELITY (correlation structure) ===")
print(f"Mean absolute correlation difference: {joint_results['mean_abs_corr_diff']}")
print(f"Max absolute correlation difference: {joint_results['max_abs_corr_diff']}")
print("\nTop 10 largest correlation discrepancies (real vs synthetic):")
print(joint_results['top_10_largest_diffs'])

# ============================================================
# 3. MISSINGNESS RATE COMPARISON (marginal, per-column)
# ============================================================
print("\n=== MISSINGNESS RATE COMPARISON ===")
miss_compare = pd.DataFrame({
    "real_miss_rate": real_df[common_cols].isnull().mean(),
    "synth_miss_rate": synth_df[common_cols].isnull().mean(),
})
miss_compare["abs_diff"] = (miss_compare["real_miss_rate"] - miss_compare["synth_miss_rate"]).abs()
print(miss_compare.sort_values("abs_diff", ascending=False))
