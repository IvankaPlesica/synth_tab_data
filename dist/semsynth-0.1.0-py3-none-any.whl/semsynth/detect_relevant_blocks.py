'''def detect_relevant_blocks(itemsets, min_any_confidence, min_all_confidence=0.0):
    all_sets = [
        (frozenset(items), level[items].itemset_count)
        for level in itemsets.values() for items in level
    ]
    maximal = [
        (s, count) for s, count in all_sets
        if not any(s < other for other, _ in all_sets)
        and len(s) >= 2
    ]

    results = []
    for itemset, count in maximal:
        singleton_counts = [
            itemsets[1][(col,)].itemset_count
            for col in itemset
            if (col,) in itemsets.get(1, {})
        ]
        if len(singleton_counts) < len(itemset):
            continue

        weakest = min(singleton_counts)
        strongest = max(singleton_counts)
        any_confidence = count / weakest
        all_confidence = count / strongest

        results.append({
            "itemset": sorted(itemset),
            "count": count,
            "any_confidence": round(any_confidence, 3),
            "all_confidence": round(all_confidence, 3),
            "cross_support": round(all_confidence / any_confidence, 3),
            "is_relevant_block": any_confidence >= min_any_confidence,
        })

    return sorted(results, key=lambda r: -r["any_confidence"])'''

def detect_relevant_blocks(itemsets, min_any_confidence):
    # Evaluate confidence on EVERY frequent itemset (not just maximal ones).
    # A large itemset failing confidence should NOT hide a smaller, strong
    # sub-itemset (e.g. {sod, pot} at conf~1.0 getting swallowed by the rarer,
    # weaker {rbc, sod, pot} just because the larger one happens to be
    # "maximal" by raw support) -- confidence must be checked before any
    # itemset is discarded, not after.
    all_sets = [
        (frozenset(items), level[items].itemset_count)
        for level in itemsets.values() for items in level
    ]

    results = []
    for itemset, count in all_sets:
        if len(itemset) < 2:
            continue

        singleton_counts = [
            itemsets[1][(col,)].itemset_count
            for col in itemset
            if (col,) in itemsets.get(1, {})
        ]
        if len(singleton_counts) < len(itemset):
            continue

        weakest = min(singleton_counts)
        strongest = max(singleton_counts)
        any_confidence = count / weakest
        all_confidence = count / strongest

        results.append({
            "itemset": sorted(itemset),
            "itemset_frozenset": itemset,
            "count": count,
            "any_confidence": round(any_confidence, 3),
            "all_confidence": round(all_confidence, 3),
            "cross_support": round(all_confidence / any_confidence, 3),
            "is_relevant_block": any_confidence >= min_any_confidence,
        })

    results.sort(key=lambda r: -r["any_confidence"])

    # Now dedupe: only drop an itemset if it's a strict subset of a
    # DIFFERENT RELEVANT itemset -- not of any frequent itemset regardless
    # of whether that larger one actually qualified.
    relevant = [r for r in results if r["is_relevant_block"]]
    relevant_sets = [r["itemset_frozenset"] for r in relevant]

    final = []
    for r in relevant:
        is_subset_of_another = any(
            r["itemset_frozenset"] < other
            for other in relevant_sets
            if other != r["itemset_frozenset"]
        )
        if not is_subset_of_another:
            final.append(r)

    for r in final:
        del r["itemset_frozenset"]  # drop the internal helper key

    return final