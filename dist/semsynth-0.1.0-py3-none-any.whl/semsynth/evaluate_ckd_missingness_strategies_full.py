# evaluate_ckd_missingness_strategies_full.py
"""Same R/S1/S2 fold loop as evaluate_ckd_missingness_strategies.py, with
oof_pooling.py's subgroup TPR-gap and anonymeter privacy checks merged in --
one fold loop instead of two nearly-identical ones. s1_features/s2_features/
synth_label_s1/synth_label_s2/X_test/y_test are the SAME objects the AUC
scoring already uses; nothing is resynthesized or recomputed for the added
checks.

Toggle each addition independently below.
"""
from imputation import simple_impute, mice_and_regression
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
from block_analysis import assign_patterns
import csv
import json
import os
import numpy as np
import pandas as pd
import warnings
from sklearn.model_selection import StratifiedKFold
from Missingness_Model import MissingnessModel
from statsmodels.genmod.generalized_linear_model import PerfectSeparationWarning
from dataset_registry import DATASET_REGISTRY

#METRICS_CSV = "metrics_history.csv"
#METRICS_FIELDS = ["dataset", "condition", "fold", "seed",
#                   "auc", "f1", "sensitivity", "specificity", "precision", "brier"]

SUBGROUP_METADATA_JSON = "subgroup_metadata.json"
#PIPELINE_METADATA_JSON = "pipeline_metadata.json"

'''
def append_metrics_csv(records, path=METRICS_CSV):
    """Append rows to path, writing the header only if the file doesn't exist
    yet -- so CKD and hepatitis runs accumulate in the same file across runs."""
    write_header = not os.path.exists(path)
    with open(path, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=METRICS_FIELDS)
        if write_header:
            writer.writeheader()
        writer.writerows(records)

'''
def update_subgroup_metadata(dataset_name, subgroup_name, record, path=SUBGROUP_METADATA_JSON):
    """Update (not append) the entry for dataset_name/subgroup_name -- unlike
    metrics_history.csv this isn't per-fold data, it's a per-run description
    of the subgroup itself, so re-running overwrites the previous entry for
    that dataset/subgroup instead of accumulating duplicates."""
    all_metadata = {}
    if os.path.exists(path):
        with open(path) as f:
            all_metadata = json.load(f)
    all_metadata.setdefault(dataset_name, {})[subgroup_name] = record
    with open(path, "w") as f:
        json.dump(all_metadata, f, indent=2)


def write_pipeline_metadata(dataset_name, record, path=PIPELINE_METADATA_JSON):
    """Save this run's pipeline-level results (aggregated performance +
    missingness-structure preservation) under dataset_name, alongside any
    other dataset already in the file."""
    all_metadata = {}
    if os.path.exists(path):
        with open(path) as f:
            all_metadata = json.load(f)
    all_metadata[dataset_name] = record
    with open(path, "w") as f:
        json.dump(all_metadata, f, indent=2)


def characterize_subgroup(df, mask, categorical_cols):
    """Mean +/- SD (numeric) / mode with share (categorical) for rows in mask,
    computed on raw values -- same convention as simple_subgroups.py's cluster
    and outlier characterizations."""
    num_cols = [c for c in df.columns if c not in categorical_cols and c != "class"]
    chars = {}
    for col in num_cols:
        vals = df.loc[mask, col].dropna()
        if len(vals):
            chars[col] = f"{vals.mean():.2f} +/- {vals.std():.2f}"
    for col in categorical_cols:
        if col not in df.columns:
            continue
        vals = df.loc[mask, col].dropna()
        if len(vals):
            mode = vals.mode().iloc[0]
            chars[col] = f"{mode} ({(vals == mode).mean():.0%})"
    return chars

RUN_SUBGROUP_CHECKS = True   # TPR-gap: outlier subgroup vs rest
RUN_PRIVACY_CHECKS = True    # anonymeter singling-out risk (S1/S2)
RUN_PIPELINE_METADATA = True  # aggregated R/S1/S2 performance + missingness-structure preservation (RQ2)

if RUN_SUBGROUP_CHECKS:
    from frozen_outlier_rule import apply_outlier_rule, explain_outlier_rule
if RUN_PRIVACY_CHECKS:
    from anonymeter.evaluators import SinglingOutEvaluator
    from subgroup_privacy_oof import attacked_rows

# Hand-defined subgroups to report alongside the clustering-derived outlier
# subgroup, per dataset. Make sure outlier_rule.joblib was regenerated for
# THIS dataset_name before running (cp outlier_rule_<name>.joblib
# outlier_rule.joblib), since frozen_outlier_rule.py loads it once at import time.
EXTRA_SUBGROUPS = {
    "ckd": [
        ("age>=65", lambda df: (df["age"] >= 65).to_numpy()),
        ("htn==yes", lambda df: (df["htn"] == "yes").to_numpy()),
        ("dm==yes", lambda df: (df["dm"] == "yes").to_numpy()),
        ("mp0", lambda df: (df.drop(columns=["class"], errors="ignore").isnull().sum(axis=1) == 0).to_numpy()),
    ],
    "hepatitis": [
        ("age>=50", lambda df: (df["age"] >= 50).to_numpy()),
        ("mp0", lambda df: (df.drop(columns=["class"], errors="ignore").isnull().sum(axis=1) == 0).to_numpy()),
    ],
}


warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=PerfectSeparationWarning)

dataset_name = "hepatitis"
#dataset_name = "ckd"
config = DATASET_REGISTRY[dataset_name]
df = config["loader"]()
n_splits = config["n_splits"]
positive_label = config["positive_label"]
categorical_cols = config["categorical_cols"]
min_support = config["min_support"]
min_any_confidence = config["min_any_confidence"]

# Data preparation
X = df.drop(columns=["class"])
y = df["class"]

for c in categorical_cols:
    if c in X.columns:
        X[c] = X[c].astype("object")

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
print(f"\nNumber of folds: {skf.get_n_splits()}")


# ============================================================
# R / S1 / S2 over folds
# ============================================================

scores_r, scores_s1, scores_s2 = [], [], []

if RUN_SUBGROUP_CHECKS:
    # out-of-fold pooled predictions, one slot per real row, filled exactly
    # once across all folds (same pattern as oof_pooling.py)
    oof_proba = {
        "R": np.full(len(df), np.nan),
        "S1": np.full(len(df), np.nan),
        "S2": np.full(len(df), np.nan),
    }

    # Same (name -> mask_fn) pairs used for the real-data subgroups below, but
    # applied per-fold to the synthetic training features themselves -- checks
    # whether each subgroup still shows up in synthetic data at all, not just
    # whether its predictions are accurate. apply_outlier_rule doubles as the
    # mask_fn here since it already takes an arbitrary df and returns a mask.
    subgroup_defs = [("outlier", apply_outlier_rule)] + list(EXTRA_SUBGROUPS.get(dataset_name, []))
    synth_subgroup_counts = {name: {"S1": 0, "S2": 0} for name, _ in subgroup_defs}
    synth_total_counts = {"S1": 0, "S2": 0}

if RUN_PRIVACY_CHECKS:
    so_risk = {"S1": [], "S2": []}
    so_attacked_mask = {
        "S1": pd.Series(False, index=df.index),
        "S2": pd.Series(False, index=df.index),
    }  # pooled out-of-fold row-level attack results, same pattern as oof_proba above

if RUN_PIPELINE_METADATA:
    # every fold's metrics dict, per condition -- aggregated into mean/std after
    # the loop. every fold's synthetic features, per condition -- concatenated
    # after the loop to check missingness-structure preservation against real X.
    pipeline_fold_metrics = {"R": [], "S1": [], "S2": []}
    s1_features_all, s2_features_all = [], []

for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
    print(f"\nFold {fold_num+1} in progress.")
    X_train = X.iloc[train_index].copy()
    X_test = X.iloc[test_index].copy()

    y_train = (y.iloc[train_index] == positive_label).astype(int)
    y_test = (y.iloc[test_index] == positive_label).astype(int)

    # Branch R: baseline
    fold_metrics_records = []
    if RUN_SUBGROUP_CHECKS:
        score_r, proba_r, metrics_r = mice_and_regression(
            X_train, y_train, X_test, y_test, return_proba=True, return_metrics=True
        )
        oof_proba["R"][test_index] = proba_r
    else:
        score_r, metrics_r = mice_and_regression(X_train, y_train, X_test, y_test, return_metrics=True)
    scores_r.append(score_r)
    fold_metrics_records.append({"dataset": dataset_name, "condition": "R", "fold": fold_num, "seed": 42, **metrics_r})
    if RUN_PIPELINE_METADATA:
        pipeline_fold_metrics["R"].append(metrics_r)
    print(f"Fold {fold_num}: Score R = {score_r}")

    # Shared: simple-impute train, reused by both S1 and S2
    X_train_filled = simple_impute(X_train)

    # Branch S1: build per-column _NA shadow indicators, synthesize with them jointly
    shadow_cols = build_shadow_columns(X_train)
    synth_features_with_shadows, synth_label_s1 = synthesize(X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols)

    # Branch S1: reinsert missingness using the synthesizer's _NA columns
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)
    if RUN_SUBGROUP_CHECKS:
        for subgroup_name, mask_fn in subgroup_defs:
            synth_subgroup_counts[subgroup_name]["S1"] += int(mask_fn(s1_features).sum())
        synth_total_counts["S1"] += len(s1_features)
        score_s1, proba_s1, metrics_s1 = mice_and_regression(
            s1_features, synth_label_s1, X_test, y_test, return_proba=True, return_metrics=True
        )
        oof_proba["S1"][test_index] = proba_s1
    else:
        score_s1, metrics_s1 = mice_and_regression(s1_features, synth_label_s1, X_test, y_test, return_metrics=True)
    scores_s1.append(score_s1)
    fold_metrics_records.append({"dataset": dataset_name, "condition": "S1", "fold": fold_num, "seed": 42, **metrics_s1})
    if RUN_PIPELINE_METADATA:
        pipeline_fold_metrics["S1"].append(metrics_s1)
        s1_features_all.append(s1_features)
    print(f"Fold {fold_num}: Score S1 = {score_s1}")

    # ---- privacy check: S1 (reuses s1_features/X_train/X_test above, no resynthesis) ----
    if RUN_PRIVACY_CHECKS:
        n_attacks_s1 = min(500, len(X_train))
        so_eval_s1 = SinglingOutEvaluator(ori=X_train, syn=s1_features, control=X_test, n_attacks=n_attacks_s1)
        so_eval_s1.evaluate(mode="multivariate")
        so_risk["S1"].append(so_eval_s1.risk().value)
        hits_s1 = attacked_rows(X_test, so_eval_s1.queries())
        if hits_s1:
            so_attacked_mask["S1"].loc[list(hits_s1)] = True

    # Branch S2: shadow patterns with missingness_pattern fed in as a joint variable; see run_s2_brancn
    mining_model = MissingnessModel().fit(X_train, min_support=min_support, min_any_confidence=min_any_confidence)

    print(f"Fold {fold_num}: {len(mining_model.blocks)} missingness blocks "
          f"(min_support={min_support}, min_any_confidence={min_any_confidence}): "
          + ", ".join("+".join(b["itemset"]) for b in mining_model.blocks))

    s2_features, synth_label_s2 = run_s2_branch(X_train, X_train_filled, y_train, categorical_cols, mining_model)
    if RUN_SUBGROUP_CHECKS:
        for subgroup_name, mask_fn in subgroup_defs:
            synth_subgroup_counts[subgroup_name]["S2"] += int(mask_fn(s2_features).sum())
        synth_total_counts["S2"] += len(s2_features)
        score_s2, proba_s2, metrics_s2 = mice_and_regression(
            s2_features, synth_label_s2, X_test, y_test, return_proba=True, return_metrics=True
        )
        oof_proba["S2"][test_index] = proba_s2
    else:
        score_s2, metrics_s2 = mice_and_regression(s2_features, synth_label_s2, X_test, y_test, return_metrics=True)
    scores_s2.append(score_s2)
    fold_metrics_records.append({"dataset": dataset_name, "condition": "S2", "fold": fold_num, "seed": 42, **metrics_s2})
    if RUN_PIPELINE_METADATA:
        pipeline_fold_metrics["S2"].append(metrics_s2)
        s2_features_all.append(s2_features)
    print(f"Fold {fold_num}: Score S2 = {score_s2}")
    append_metrics_csv(fold_metrics_records)

    # ---- privacy check: S2 (reuses s2_features/X_train/X_test above, no resynthesis) ----
    if RUN_PRIVACY_CHECKS:
        n_attacks_s2 = min(500, len(X_train))
        so_eval_s2 = SinglingOutEvaluator(ori=X_train, syn=s2_features, control=X_test, n_attacks=n_attacks_s2)
        so_eval_s2.evaluate(mode="multivariate")
        so_risk["S2"].append(so_eval_s2.risk().value)
        hits_s2 = attacked_rows(X_test, so_eval_s2.queries())
        if hits_s2:
            so_attacked_mask["S2"].loc[list(hits_s2)] = True

print(f"\nMean Score R:  {np.mean(scores_r):.4f} (std: {np.std(scores_r):.4f})")
print(f"Mean Score S1: {np.mean(scores_s1):.4f} (std: {np.std(scores_s1):.4f})")
print(f"Mean Score S2: {np.mean(scores_s2):.4f} (std: {np.std(scores_s2):.4f})")


# ============================================================
# Pipeline metadata (RQ2 Results): aggregated R/S1/S2 performance across all
# folds of this run, plus whether the real missingness-pattern structure
# (Section rq1) survives synthesis in S1/S2. Written to PIPELINE_METADATA_JSON
# once per dataset run.
# ============================================================
if RUN_PIPELINE_METADATA:
    def aggregate_fold_metrics(records):
        agg = {}
        for key in ["auc", "f1", "sensitivity", "specificity", "precision", "brier"]:
            vals = [r[key] for r in records]
            agg[f"{key}_mean"] = float(np.mean(vals))
            agg[f"{key}_std"] = float(np.std(vals))
        return agg

    performance = {
        branch: aggregate_fold_metrics(records)
        for branch, records in pipeline_fold_metrics.items()
    }

    def compute_dmis(real_labels, synth_labels):
        """L1 divergence between real and synthetic pattern-label rate
        distributions (Wang, Asif & Vaidya 2023, Eq. 1)."""
        real_rates = real_labels.value_counts(normalize=True)
        synth_rates = synth_labels.value_counts(normalize=True)
        all_labels = set(real_rates.index) | set(synth_rates.index)
        return sum(abs(real_rates.get(m, 0.0) - synth_rates.get(m, 0.0)) for m in all_labels)

    # Fit once on the full real feature set -- this is a post-hoc preservation
    # check (like the eGFR/ALBI validation), not part of the generative
    # pipeline itself, so it's not subject to the per-fold training-only
    # restriction Section rq2 describes for the S2 branch's own mining model.
    structure_model = MissingnessModel().fit(X, min_support=min_support, min_any_confidence=min_any_confidence)
    real_labels = assign_patterns(X, structure_model)
    s1_pooled = pd.concat(s1_features_all, ignore_index=True)
    s2_pooled = pd.concat(s2_features_all, ignore_index=True)
    s1_labels = assign_patterns(s1_pooled, structure_model)
    s2_labels = assign_patterns(s2_pooled, structure_model)

    real_pattern_rates = real_labels.value_counts(normalize=True).round(4).to_dict()
    s1_pattern_rates = s1_labels.value_counts(normalize=True).round(4).to_dict()
    s2_pattern_rates = s2_labels.value_counts(normalize=True).round(4).to_dict()

    missingness_structure = {
        "blocks": ["+".join(b["itemset"]) for b in structure_model.blocks],
        "real_pattern_label_rates": real_pattern_rates,
        "S1": {
            "dmis": float(compute_dmis(real_labels, s1_labels)),
            "pattern_label_rates": s1_pattern_rates,
            "n_pooled": len(s1_pooled),
        },
        "S2": {
            "dmis": float(compute_dmis(real_labels, s2_labels)),
            "pattern_label_rates": s2_pattern_rates,
            "n_pooled": len(s2_pooled),
        },
    }

    pipeline_record = {
        "n_splits": n_splits,
        "min_support": min_support,
        "min_any_confidence": min_any_confidence,
        "performance": performance,
        "missingness_structure": missingness_structure,
    }
    write_pipeline_metadata(dataset_name, pipeline_record)
    print(f"\n=== Pipeline metadata (performance + missingness-structure) written to {PIPELINE_METADATA_JSON} ===")
    print(f"Dmis (lower = closer to real): S1={missingness_structure['S1']['dmis']:.4f}, "
          f"S2={missingness_structure['S2']['dmis']:.4f}")


# ============================================================
# Subgroup TPR-gap + privacy check, looped over the outlier subgroup and
# every hand-defined subgroup for this dataset -- RUN_SUBGROUP_CHECKS /
# RUN_PRIVACY_CHECKS. The per-fold pipeline above ran once regardless of
# how many subgroups are reported here; each subgroup is just a different
# boolean mask applied to the same pooled oof_proba / so_attacked_mask.
# ============================================================
if RUN_SUBGROUP_CHECKS:
    for branch, proba in oof_proba.items():
        assert not np.isnan(proba).any(), f"every row should get exactly one OOF prediction ({branch})"
    y_true = (y == positive_label).astype(int).to_numpy()

    def group_tpr(y_true, y_pred, mask):
        actual_pos = (y_true == 1) & mask
        if actual_pos.sum() == 0:
            return None
        return (y_pred[actual_pos] == 1).mean()

    def group_tnr(y_true, y_pred, mask):
        actual_neg = (y_true == 0) & mask
        if actual_neg.sum() == 0:
            return None
        return (y_pred[actual_neg] == 0).mean()

    # "outlier" uses the frozen clustering rule (outlier_rule.joblib must already
    # match dataset_name -- see note above EXTRA_SUBGROUPS); the rest are hand-defined.
    subgroups = [("outlier", apply_outlier_rule(df))] + [
        (name, mask_fn(df)) for name, mask_fn in EXTRA_SUBGROUPS.get(dataset_name, [])
    ]

    for subgroup_name, mask in subgroups:
        print(f"\n{'=' * 60}\nSubgroup: {subgroup_name} (n={mask.sum()} / {len(df)})\n{'=' * 60}")

        record = {
            "n": int(mask.sum()),
            "total": int(len(df)),
            "definition": (
                "distance-to-cluster-centroid rule, fit on real data (simple_subgroups.py); "
                "explanation_tree below is a ~97%-fidelity decision-tree approximation for "
                "human reading, it is NOT the rule used to score any row"
                if subgroup_name == "outlier" else subgroup_name
            ),
            "explanation_tree": explain_outlier_rule() if subgroup_name == "outlier" else None,
            "characterization": characterize_subgroup(df, mask, categorical_cols),
            "metrics": {},
            "privacy": {},
            "representation": {},
        }

        # Does this subgroup still show up in synthetic data at all, not just
        # whether predictions for it are accurate? real_prevalence is the
        # subgroup's share of the full real dataset; synthetic prevalence is
        # pooled across every fold's synthetic training data (each fold
        # resynthesizes its own training split, so this is summed counts over
        # all folds, not one fold's numbers). retention_ratio=1.0 means the
        # subgroup is exactly as common in synthetic data as in real data;
        # 0.0 (n_pooled=0) means it disappeared entirely.
        real_prevalence = mask.sum() / len(df)
        print(f"\nRepresentation (does this subgroup survive synthesis at all?):")
        print(f"  real prevalence: {real_prevalence:.3%} ({int(mask.sum())}/{len(df)})")
        for branch in ["S1", "S2"]:
            n_pooled = synth_subgroup_counts[subgroup_name][branch]
            total_pooled = synth_total_counts[branch]
            synth_prevalence = n_pooled / total_pooled if total_pooled else None
            retention_ratio = (synth_prevalence / real_prevalence) if (synth_prevalence is not None and real_prevalence > 0) else None
            if retention_ratio is not None:
                print(f"  {branch}: synthetic prevalence = {synth_prevalence:.3%} "
                      f"({n_pooled}/{total_pooled}), retention_ratio={retention_ratio:.3f}")
            else:
                print(f"  {branch}: synthetic prevalence = {synth_prevalence} ({n_pooled}/{total_pooled})")
            record["representation"][branch] = {
                "n_pooled": n_pooled,
                "total_pooled": total_pooled,
                "synthetic_prevalence": synth_prevalence,
                "retention_ratio": retention_ratio,
            }

        n_neg_subgroup = int(((y_true == 0) & mask).sum())
        n_neg_non_subgroup = int(((y_true == 0) & ~mask).sum())
        if n_neg_subgroup == 0:
            print(f"\n(NOTE: 0 actual negative-class patients in subgroup '{subgroup_name}' -- "
                  f"specificity/FPR-gap is undefined for this subgroup, not just unstable)")

        tpr_gaps, spec_gaps = {}, {}
        for branch, proba in oof_proba.items():
            y_pred = (proba >= 0.5).astype(int)

            tpr_out = group_tpr(y_true, y_pred, mask)
            tpr_non = group_tpr(y_true, y_pred, ~mask)
            tpr_gap = tpr_non - tpr_out
            tpr_gaps[branch] = tpr_gap
            print(f"{branch}: tpr_subgroup={tpr_out:.3f} (n={mask.sum()}), "
                  f"tpr_non_subgroup={tpr_non:.3f} (n={(~mask).sum()}), "
                  f"tpr_gap={tpr_gap:.3f}")

            tnr_out = group_tnr(y_true, y_pred, mask)
            tnr_non = group_tnr(y_true, y_pred, ~mask)
            spec_gap = (tnr_non - tnr_out) if (tnr_out is not None and tnr_non is not None) else None
            spec_gaps[branch] = spec_gap
            if spec_gap is not None:
                print(f"{branch}: specificity_subgroup={tnr_out:.3f} (n_neg={n_neg_subgroup}), "
                      f"specificity_non_subgroup={tnr_non:.3f} (n_neg={n_neg_non_subgroup}), "
                      f"specificity_gap={spec_gap:.3f}")
            else:
                print(f"{branch}: specificity_subgroup={tnr_out} (n_neg={n_neg_subgroup}), "
                      f"specificity_non_subgroup={tnr_non} (n_neg={n_neg_non_subgroup}) "
                      f"-- gap undefined, not just unstable")

            record["metrics"][branch] = {
                "tpr_subgroup": float(tpr_out) if tpr_out is not None else None,
                "tpr_non_subgroup": float(tpr_non) if tpr_non is not None else None,
                "tpr_gap": float(tpr_gap) if tpr_gap is not None else None,
                "n_neg_subgroup": n_neg_subgroup,
                "n_neg_non_subgroup": n_neg_non_subgroup,
                "specificity_subgroup": float(tnr_out) if tnr_out is not None else None,
                "specificity_non_subgroup": float(tnr_non) if tnr_non is not None else None,
                "specificity_gap": float(spec_gap) if spec_gap is not None else None,
            }
            if branch != "R":
                # NOTE: no widens/narrows label here on purpose -- a raw signed
                # delta can't distinguish "disparity shrank" from "disparity
                # flipped sign and grew in the opposite direction" (see the
                # age>=50/S2 hepatitis case: R=0.121, S2=-0.260 -- the naive
                # label would call this "narrows" even though |gap| more than
                # doubled). Always read tpr_gap/specificity_gap for R and this
                # branch together, not the delta alone.
                tpr_delta = tpr_gap - tpr_gaps["R"]
                print(f"  {branch} TPR gap delta vs R = {tpr_delta:+.3f} "
                      f"(R gap={tpr_gaps['R']:+.3f}, {branch} gap={tpr_gap:+.3f})")
                record["metrics"][branch]["tpr_delta_vs_R"] = float(tpr_delta)

                if spec_gap is not None and spec_gaps.get("R") is not None:
                    spec_delta = spec_gap - spec_gaps["R"]
                    print(f"  {branch} specificity gap delta vs R = {spec_delta:+.3f} "
                          f"(R gap={spec_gaps['R']:+.3f}, {branch} gap={spec_gap:+.3f})")
                    record["metrics"][branch]["specificity_delta_vs_R"] = float(spec_delta)
                else:
                    record["metrics"][branch]["specificity_delta_vs_R"] = None

        if RUN_PRIVACY_CHECKS:
            print(f"\nSingling-out privacy risk for subgroup '{subgroup_name}' "
                  f"(NOTE: anonymeter's rng is unseeded -- these numbers are NOT "
                  f"reproducible run-to-run, see earlier caveat):")
            for branch in ["S1", "S2"]:
                mean_risk = np.mean(so_risk[branch])
                print(f"{branch}: mean risk across folds = {mean_risk:.4f} (std={np.std(so_risk[branch]):.4f})")
                attacked_arr = so_attacked_mask[branch].to_numpy()
                out_rate = attacked_arr[mask].mean() if mask.sum() else float("nan")
                non_rate = attacked_arr[~mask].mean() if (~mask).sum() else float("nan")
                print(f"  subgroup attack rate:     {out_rate:.3f} "
                      f"({int(attacked_arr[mask].sum())}/{int(mask.sum())})")
                print(f"  non-subgroup attack rate: {non_rate:.3f} "
                      f"({int(attacked_arr[~mask].sum())}/{int((~mask).sum())})")
                print(f"  gap (subgroup - non-subgroup): {out_rate - non_rate:+.3f}")
                record["privacy"][branch] = {
                    "mean_risk_across_folds": float(mean_risk),
                    "std_risk_across_folds": float(np.std(so_risk[branch])),
                    "subgroup_attack_rate": float(out_rate) if not np.isnan(out_rate) else None,
                    "non_subgroup_attack_rate": float(non_rate) if not np.isnan(non_rate) else None,
                    "gap": float(out_rate - non_rate) if not (np.isnan(out_rate) or np.isnan(non_rate)) else None,
                    "note": "anonymeter's rng is unseeded -- not reproducible run-to-run",
                }

        update_subgroup_metadata(dataset_name, subgroup_name, record)
        print(f"\n(subgroup metadata for '{subgroup_name}' written to {SUBGROUP_METADATA_JSON})")

elif RUN_PRIVACY_CHECKS:
    # RUN_SUBGROUP_CHECKS is off -- no mask to break down by, just the overall risk
    print("\nSingling-out privacy risk (S1 vs S2):")
    for branch in ["S1", "S2"]:
        mean_risk = np.mean(so_risk[branch])
        print(f"{branch}: mean risk across folds = {mean_risk:.4f} (std={np.std(so_risk[branch]):.4f})")
