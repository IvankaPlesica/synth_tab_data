# ============================================================
# CKD MECHANISM-BASED IMPUTATION (Python)
# MAR block -> IterativeImputer (MICE-equivalent)
# MNAR blocks -> delta-adjustment sensitivity analysis
# ============================================================

import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer
from sklearn.ensemble import RandomForestRegressor

# --- 1. Load data ---
df = pd.read_csv("ckd_with_egfr.csv")
egfr_cols = ["egfr_star", "ckd_stage", "ckd_stage_cat"]
df = df.drop(columns=[c for c in egfr_cols if c in df.columns])
df["class"] = df["class"].str.strip()

# ============================================================
# STEP A: STANDARD MULTIPLE IMPUTATION FOR MAR-CONSISTENT COLUMNS
# (urinalysis block: al, su, sg, pc)
# ============================================================

def run_multiple_imputation(df, n_imputations=20, exclude_cols=("class",)):
    """
    Runs IterativeImputer n_imputations times (different random_state each time)
    to approximate multiple imputation. Returns a list of completed DataFrames.
    """
    num_cols = df.select_dtypes(include="number").columns.tolist()
    cat_cols = [c for c in df.columns if c not in num_cols and c not in exclude_cols]

    # one-hot encode categoricals for the imputer, keep track to reverse later
    df_encoded = pd.get_dummies(df.drop(columns=list(exclude_cols)),
                                 columns=cat_cols, dummy_na=False)

    imputed_datasets = []
    for i in range(n_imputations):
        imputer = IterativeImputer(
            estimator=RandomForestRegressor(n_estimators=50),
            max_iter=10,
            random_state=i,
            sample_posterior=False
        )
        imputed_array = imputer.fit_transform(df_encoded)
        imputed_df = pd.DataFrame(imputed_array, columns=df_encoded.columns, index=df.index)
        for col in exclude_cols:
            imputed_df[col] = df[col].values
        imputed_datasets.append(imputed_df)

    return imputed_datasets


mar_imputations = run_multiple_imputation(df, n_imputations=20)

# example: pooled logistic regression across the 20 imputations (Rubin's rules,
# simplified -- averaging coefficients and combining variance)
def pool_glm(imputations, formula):
    coefs, variances = [], []
    for data in imputations:
        model = smf.glm(formula, data=data, family=sm.families.Binomial()).fit()
        coefs.append(model.params)
        variances.append(model.bse ** 2)

    coefs_df = pd.concat(coefs, axis=1)
    var_df = pd.concat(variances, axis=1)

    pooled_est = coefs_df.mean(axis=1)
    within_var = var_df.mean(axis=1)
    between_var = coefs_df.var(axis=1)
    total_var = within_var + between_var * (1 + 1 / len(imputations))
    pooled_se = np.sqrt(total_var)

    return pd.DataFrame({
        "estimate": pooled_est.round(4),
        "se": pooled_se.round(4)
    })


pooled = pool_glm(
    mar_imputations,
    "class_ckd ~ al + su + sg + pc"  # adjust column names post-dummy if needed
)
print(pooled)

# ============================================================
# STEP B: DELTA-ADJUSTMENT SENSITIVITY ANALYSIS
# for MNAR-confirmed columns: pot, sod, rbcc, wbcc, pcv, hemo
# ============================================================

mnar_cols = ["pot", "sod", "rbcc", "wbcc", "pcv", "hemo"]

# per-column delta ranges, scaled to each variable's clinical range
# (edit these to whatever your domain knowledge suggests is plausible)
delta_ranges = {
    "pot":  np.arange(-1.0, 1.01, 0.5),      # mmol/L
    "sod":  np.arange(-5.0, 5.01, 2.5),      # mmol/L
    "rbcc": np.arange(-0.5, 0.51, 0.25),     # millions/cmm
    "wbcc": np.arange(-1000, 1001, 500),     # cells/cmm
    "pcv":  np.arange(-3.0, 3.01, 1.5),      # %
    "hemo": np.arange(-1.0, 1.01, 0.5),      # g/dL
}

def run_delta_adjustment(df, mnar_cols, delta_ranges, outcome_col="class"):
    y_outcome = (df[outcome_col] == "ckd").astype(int)
    results = []

    # base MAR imputation (delta = 0 baseline) using RF-based IterativeImputer
    num_cols = df.select_dtypes(include="number").columns.tolist()
    imputer = IterativeImputer(estimator=RandomForestRegressor(n_estimators=50),
                                max_iter=10, random_state=42)
    imputed_array = imputer.fit_transform(df[num_cols])
    base_imputed = pd.DataFrame(imputed_array, columns=num_cols, index=df.index)

    missing_masks = {col: df[col].isnull() for col in mnar_cols}

    # sweep one column's delta at a time, holding others at 0, to isolate effects
    for target_col in mnar_cols:
        for delta in delta_ranges[target_col]:
            shifted = base_imputed.copy()
            shifted.loc[missing_masks[target_col], target_col] += delta

            model_df = shifted[mnar_cols].copy()
            model_df["y"] = y_outcome.values

            model = sm.GLM(model_df["y"], sm.add_constant(model_df[mnar_cols]),
                            family=sm.families.Binomial()).fit()

            results.append({
                "target_col": target_col,
                "delta": delta,
                "coef": round(model.params[target_col], 4),
                "p_value": round(model.pvalues[target_col], 4),
            })

    return pd.DataFrame(results)


sensitivity_results = run_delta_adjustment(df, mnar_cols, delta_ranges)
print(sensitivity_results.to_string(index=False))

# ============================================================
# STEP C: FIND TIPPING POINTS
# ============================================================

def find_tipping_points(sensitivity_df, alpha=0.05):
    tipping_points = []
    for col in sensitivity_df["target_col"].unique():
        subset = sensitivity_df[sensitivity_df["target_col"] == col].sort_values("delta")
        crosses = subset[subset["p_value"] >= alpha]
        if not crosses.empty:
            tipping_points.append({
                "column": col,
                "first_delta_losing_significance": crosses.iloc[0]["delta"]
            })
        else:
            tipping_points.append({
                "column": col,
                "first_delta_losing_significance": "robust across tested range"
            })
    return pd.DataFrame(tipping_points)


print(find_tipping_points(sensitivity_results))