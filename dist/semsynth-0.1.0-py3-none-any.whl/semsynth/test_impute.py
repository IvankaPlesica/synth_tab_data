import pandas as pd
from imputation import categoricals_to_numeric_codes

X_train = pd.DataFrame({"color": ["red", "blue", None]})
X_test  = pd.DataFrame({"color": ["blue", "purple"]})

train_out, test_out = categoricals_to_numeric_codes(X_train, X_test)
print(train_out, test_out, sep="\n")
