import pandas as pd
from rule_mining import missing_matrix

df = pd.read_csv("ckd_with_patterns.csv")
M = missing_matrix(df.drop(columns=["missingness_pattern", "class"]))

# rows currently mp0 but have missing values
unstructured = (df["missingness_pattern"] == "mp0") & M.any(axis=1)
df.loc[unstructured, "missingness_pattern"] = "mp_other"

print(df["missingness_pattern"].value_counts())
df.to_csv("ckd_patterns.csv", index=False)