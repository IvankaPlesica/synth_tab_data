import pandas as pd
import numpy as np
import pysubgroup as ps
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.cluster import DBSCAN

# ── load and clean CKD data ───────────────────────────────────────────────────

def load_ckd(path="/Users/goran/semsynth/downloads-cache/uciml/336.csv.gz"):
    df = pd.read_csv(path)
    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
    df["dm"] = df["dm"].replace("\tno", "no")
    df["class"] = df["class"].replace("ckd\t", "ckd")
    return df

df = load_ckd()
print(f"Loaded CKD dataset: {df.shape}")
print(f"\nMissingness per column:")
print(df.isnull().mean().round(3).sort_values(ascending=False))

# ── column definitions ────────────────────────────────────────────────────────

numeric_cols = [c for c in ['age', 'bp', 'bgr', 'bu', 'sc',
                             'sod', 'pot', 'hemo', 'pcv', 'wbcc', 'rbcc']
                if c in df.columns]
ordinal_cols = [c for c in ['sg', 'al', 'su']
                if c in df.columns]
cat_cols = [c for c in ['rbc', 'pc', 'pcc', 'ba', 'htn', 'dm', 'cad',
                         'appet', 'pe', 'ane']
            if c in df.columns]

print(f"\nNumeric: {numeric_cols}")
print(f"Ordinal: {ordinal_cols}")
print(f"Categorical: {cat_cols}")

# ── dense representation ──────────────────────────────────────────────────────

def build_dense(df, numeric_cols, ordinal_cols, cat_cols):
    out = pd.DataFrame(index=df.index)
    le = LabelEncoder()
    for col in numeric_cols:
        out[col] = pd.to_numeric(df[col], errors='coerce')
        out[f'{col}_missing'] = out[col].isna().astype(float)
        out[col] = out[col].fillna(out[col].median())
    for col in ordinal_cols:
        out[col] = pd.to_numeric(df[col], errors='coerce')
        out[f'{col}_missing'] = out[col].isna().astype(float)
        out[col] = out[col].fillna(out[col].median())
    for col in cat_cols:
        s = df[col].astype(str).replace('nan', np.nan)
        out[f'{col}_missing'] = s.isna().astype(float)
        out[col] = le.fit_transform(
            s.fillna(s.mode()[0] if s.notna().any() else 'unknown'))
    scale_cols = numeric_cols + ordinal_cols
    out[scale_cols] = StandardScaler().fit_transform(out[scale_cols])
    return out

X_dense = build_dense(df, numeric_cols, ordinal_cols, cat_cols)
print(f"\nDense representation shape: {X_dense.shape}")

# ── tune clustering ───────────────────────────────────────────────────────────

print(f"\n{'contam':>8} {'eps':>6} {'min_s':>6} {'clusters':>10} "
      f"{'noise':>8} {'min_sg':>8} {'max_sg':>8} {'total':>8}")
print("-"*70)

for contamination in [0.1, 0.15, 0.2, 0.25, 0.3]:
    iso_t = IsolationForest(
        contamination=contamination, random_state=42, n_jobs=-1)
    mask_t = iso_t.fit_predict(X_dense) == -1
    X_t = X_dense[mask_t].values
    scores_t = iso_t.score_samples(X_dense[mask_t])
    X_db = np.column_stack([X_t, scores_t])

    for eps in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0]:
        for min_samples in [3, 5, 8]:
            labels = DBSCAN(
                eps=eps, min_samples=min_samples, n_jobs=-1
            ).fit_predict(X_db)
            unique = set(labels) - {-1}
            n_clusters = len(unique)
            if n_clusters < 2:
                continue
            sizes = sorted([(labels == c).sum() for c in unique])
            if sizes[0] < 5:
                continue
            print(f"{contamination:>8.2f} {eps:>6.1f} {min_samples:>6} "
                  f"{n_clusters:>10} {(labels==-1).sum():>8} "
                  f"{sizes[0]:>8} {sizes[-1]:>8} {sum(sizes):>8}")

# ── clustering on full real data ──────────────────────────────────────────────

iso = IsolationForest(contamination=0.1, random_state=42, n_jobs=-1)
anomaly_pred = iso.fit_predict(X_dense)
anomaly_mask = anomaly_pred == -1
print(f"\nAnomalous rows: {anomaly_mask.sum()}")

X_anom = X_dense[anomaly_mask].values
scores = iso.score_samples(X_dense[anomaly_mask])
X_for_db = np.column_stack([X_anom, scores])

db = DBSCAN(eps=4.0, min_samples=5, n_jobs=-1)
cluster_labels_anom = db.fit_predict(X_for_db)

print(f"Clusters found: {len(set(cluster_labels_anom)) - (1 if -1 in cluster_labels_anom else 0)}")
print(f"Noise points: {(cluster_labels_anom == -1).sum()}")

subgroup_labels = pd.Series('inlier', index=df.index)
for i, idx in enumerate(df.index[anomaly_mask]):
    cl = cluster_labels_anom[i]
    subgroup_labels[idx] = 'noise' if cl == -1 else f'S{cl+1}'

print(f"\nSubgroup distribution:")
print(subgroup_labels.value_counts())

valid_subgroups = sorted([s for s in subgroup_labels.unique()
                          if s not in ['inlier', 'noise']])
print(f"\nSubgroups for rule discovery: {valid_subgroups}")

# ── sparse representation ─────────────────────────────────────────────────────

def build_sparse(df, numeric_cols, ordinal_cols, cat_cols):
    out = pd.DataFrame(index=df.index)
    for col in numeric_cols:
        out[col] = pd.to_numeric(df[col], errors='coerce')
        if out[col].isna().any():
            out[f'{col}_missing'] = out[col].isna().astype(int)
    for col in ordinal_cols:
        out[col] = pd.to_numeric(df[col], errors='coerce')
        if out[col].isna().any():
            out[f'{col}_missing'] = out[col].isna().astype(int)
    for col in cat_cols:
        s = df[col].astype(str).replace('nan', np.nan)
        out[col] = s
        if s.isna().any():
            out[f'{col}_missing'] = s.isna().astype(int)
    return out

df_sparse = build_sparse(df, numeric_cols, ordinal_cols, cat_cols)
print(f"\nSparse representation shape: {df_sparse.shape}")

# ── rule discovery ────────────────────────────────────────────────────────────

def discover_rules(df, labels, subgroups, n_results=20, depth=3):
    df_work = df.copy()
    best_rules = {}
    for sg in subgroups:
        df_work['target'] = (labels == sg).astype(int)
        n_pos = df_work['target'].sum()
        if n_pos < 5:
            print(f"Skipping {sg}: only {n_pos} rows")
            continue
        target = ps.BinaryTarget('target', True)
        searchspace = ps.create_selectors(df_work, ignore=['target'])
        task = ps.SubgroupDiscoveryTask(
            data=df_work,
            target=target,
            search_space=searchspace,
            result_set_size=n_results,
            depth=depth,
            qf=ps.WRAccQF()
        )
        result = ps.BeamSearch().execute(task)
        for quality, subgroup in result.to_descriptions():
            rule_str = str(subgroup)
            if 'isnull' not in rule_str:
                mask = subgroup.covers(df_work)
                n_covered = mask.sum()
                n_correct = (mask & (df_work['target'] == 1)).sum()
                precision = n_correct / n_covered if n_covered > 0 else 0
                recall = n_correct / n_pos if n_pos > 0 else 0
                f1 = (2 * precision * recall / (precision + recall)
                      if (precision + recall) > 0 else 0)
                best_rules[sg] = {
                    'rule_str': rule_str,
                    'subgroup_obj': subgroup,
                    'quality': round(quality, 4),
                    'precision': round(precision, 3),
                    'recall': round(recall, 3),
                    'f1': round(f1, 3),
                    'support': int(n_covered)
                }
                break
        if sg not in best_rules:
            print(f"WARNING: no clean rule found for {sg}")
    return best_rules


def apply_rules(df, best_rules):
    assigned = pd.Series('unassigned', index=df.index)
    for sg, rule_info in best_rules.items():
        try:
            mask = rule_info['subgroup_obj'].covers(df)
            unassigned = assigned == 'unassigned'
            assigned[mask & unassigned] = sg
        except Exception as e:
            print(f"Error applying rule for {sg}: {e}")
    return assigned


def evaluate_transfer(assigned, true_labels, subgroups):
    rows = []
    for sg in subgroups:
        tp = ((assigned == sg) & (true_labels == sg)).sum()
        fp = ((assigned == sg) & (true_labels != sg)).sum()
        fn = ((assigned != sg) & (true_labels == sg)).sum()
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = (2 * precision * recall / (precision + recall)
              if (precision + recall) > 0 else 0)
        jaccard = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else 0
        rows.append({
            'subgroup': sg,
            'true_n': int((true_labels == sg).sum()),
            'assigned_n': int((assigned == sg).sum()),
            'tp': int(tp),
            'precision': round(precision, 3),
            'recall': round(recall, 3),
            'f1': round(f1, 3),
            'jaccard': round(jaccard, 3)
        })
    return pd.DataFrame(rows)


# ── run ───────────────────────────────────────────────────────────────────────

print("\n" + "="*60)
print("STEP 1: Discover rules on full real sparse data")
print("="*60)
best_rules = discover_rules(df_sparse, subgroup_labels, valid_subgroups)

print("\nBest rule per subgroup:")
for sg, info in best_rules.items():
    print(f"\n{sg}:")
    print(f"  Rule:      {info['rule_str']}")
    print(f"  Quality:   {info['quality']}")
    print(f"  Precision: {info['precision']}")
    print(f"  Recall:    {info['recall']}")
    print(f"  F1:        {info['f1']}")
    print(f"  Support:   {info['support']}")

print("\n" + "="*60)
print("STEP 2: Sanity check — apply rules back to real data")
print("="*60)
assigned_real = apply_rules(df_sparse, best_rules)
eval_real = evaluate_transfer(assigned_real, subgroup_labels, valid_subgroups)
print(eval_real.to_string(index=False))
print(f"Unassigned: {(assigned_real == 'unassigned').sum()}")

print("\nRules ready. Next: apply to synthetic sparse data.")