import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from anonymeter.evaluators import SinglingOutEvaluator, LinkabilityEvaluator, InferenceEvaluator

np.random.seed(42)

# ── data generation ───────────────────────────────────────────────────────────

def make_ckd_like(n, seed=42):
    rng = np.random.RandomState(seed)
    age = rng.randint(20, 80, n).astype(float)
    ckd = rng.binomial(1, 0.6, n)
    creatinine = np.where(ckd, rng.uniform(1.5, 8.0, n),
                               rng.uniform(0.5, 1.2, n))
    urea = np.where(ckd, rng.uniform(40, 200, n),
                         rng.uniform(10, 40, n))
    sodium = rng.uniform(135, 145, n)
    hemoglobin = np.where(ckd, rng.uniform(7, 12, n),
                               rng.uniform(12, 17, n))
    wbc = rng.uniform(4000, 11000, n)
    albumin = np.where(ckd, rng.uniform(1, 4, n),
                            rng.uniform(3, 5, n))
    df = pd.DataFrame({
        'age': age,
        'creatinine': creatinine,
        'urea': urea,
        'sodium': sodium,
        'hemoglobin': hemoglobin,
        'wbc': wbc,
        'albumin': albumin,
        'diagnosis': np.where(ckd, 'ckd', 'notckd')
    })
    renal_missing = rng.binomial(1, 0.4, n).astype(bool)
    df.loc[renal_missing, ['creatinine', 'urea', 'sodium']] = np.nan
    blood_missing = rng.binomial(1,
        np.where(ckd, 0.15, 0.45), n).astype(bool)
    df.loc[blood_missing, ['hemoglobin', 'wbc']] = np.nan
    albumin_missing = (ckd == 1) & (creatinine > 5)
    df.loc[albumin_missing, 'albumin'] = np.nan
    return df

real_full = make_ckd_like(500, seed=42)
train = real_full.iloc[:400].copy().reset_index(drop=True)
control = real_full.iloc[400:].copy().reset_index(drop=True)
syn = make_ckd_like(400, seed=123).reset_index(drop=True)
syn['diagnosis'] = train['diagnosis'].values

feature_cols = ['age', 'creatinine', 'urea',
                'sodium', 'hemoglobin', 'wbc', 'albumin']

# ── representations V1–V4 ────────────────────────────────────────────────────

def add_indicators(df, cols):
    out = df.copy()
    for col in cols:
        out[f'{col}_missing'] = df[col].isna().astype(int)
    return out

def add_pattern_label(df, cols):
    out = df.copy()
    mask = df[cols].isna().astype(int)
    out['pattern'] = mask.apply(
        lambda row: '_'.join(row.astype(str).values), axis=1)
    return out

indicator_cols = [f'{c}_missing' for c in feature_cols]

# V1 — original only
train_v1 = train.copy()
syn_v1 = syn.copy()
ctrl_v1 = control.copy()

# V2 — original + indicators
train_v2 = add_indicators(train, feature_cols)
syn_v2 = add_indicators(syn, feature_cols)
ctrl_v2 = add_indicators(control, feature_cols)

# V3 — original + pattern label
train_v3 = add_pattern_label(train, feature_cols)
syn_v3 = add_pattern_label(syn, feature_cols)
ctrl_v3 = add_pattern_label(control, feature_cols)

# V4 — original + indicators + pattern label
train_v4 = add_pattern_label(add_indicators(train, feature_cols), feature_cols)
syn_v4 = add_pattern_label(add_indicators(syn, feature_cols), feature_cols)
ctrl_v4 = add_pattern_label(add_indicators(control, feature_cols), feature_cols)

print("Dataset sizes:")
print(f"Train: {len(train)}, Synthetic: {len(syn)}, Control: {len(control)}")
print(f"\nMissingness in train:")
print(train[feature_cols].isna().mean().round(3))

n_attacks = min(30, len(control))

# ── attack functions ──────────────────────────────────────────────────────────

def inference_attack_rf(ori, syn, control, aux_cols, secret, n_attacks):
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(syn[aux_cols].fillna(-999), syn[secret])
    ori_s = ori.sample(min(n_attacks, len(ori)), random_state=42)
    ctrl_s = control.sample(min(n_attacks, len(control)), random_state=42)
    main = (clf.predict(ori_s[aux_cols].fillna(-999)) == ori_s[secret]).mean()
    ctrl = (clf.predict(ctrl_s[aux_cols].fillna(-999)) == ctrl_s[secret]).mean()
    return main, ctrl, main - ctrl

def mask_mia_auc(train, syn, holdout, feature_cols):
    M_train = train[feature_cols].isna().astype(int)
    M_holdout = holdout[feature_cols].isna().astype(int)
    M_synth = syn[feature_cols].isna().astype(int)
    X_adv = pd.concat([M_train, M_holdout])
    y_adv = [1]*len(M_train) + [0]*len(M_holdout)
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_adv, y_adv)
    X_eval = pd.concat([M_synth, M_holdout])
    y_eval = [1]*len(M_synth) + [0]*len(M_holdout)
    probs = clf.predict_proba(X_eval)[:,1]
    return roc_auc_score(y_eval, probs)

# ── custom RF inference V1–V4 ─────────────────────────────────────────────────

print("\n" + "="*60)
print("CUSTOM RF INFERENCE ATTACK (V1–V4)")
print("="*60)

configs = [
    ("V1 original only",
     train_v1, syn_v1, ctrl_v1, feature_cols),
    ("V2 + indicators",
     train_v2, syn_v2, ctrl_v2, feature_cols + indicator_cols),
    ("V3 + pattern label",
     train_v3, syn_v3, ctrl_v3, feature_cols + ['pattern']),
    ("V4 + indicators + pattern",
     train_v4, syn_v4, ctrl_v4, feature_cols + indicator_cols + ['pattern']),
]

for label, tr, sy, ct, aux in configs:
    try:
        m, c, r = inference_attack_rf(tr, sy, ct, aux, 'diagnosis', n_attacks)
        print(f"{label:30s}  main={m:.3f}  ctrl={c:.3f}  risk={r:+.3f}")
    except Exception as e:
        print(f"{label:30s}  ERROR: {e}")

# ── anonymeter singling out V1–V4 ─────────────────────────────────────────────

print("\n" + "="*60)
print("ANONYMETER SINGLING OUT (V1–V4)")
print("="*60)

for label, tr, sy, ct, _ in configs:
    try:
        so = SinglingOutEvaluator(
            ori=tr, syn=sy, control=ct, n_attacks=n_attacks)
        so.evaluate(mode='univariate')
        print(f"{label:30s}  risk={so.risk().value:.4f}")
    except Exception as e:
        print(f"{label:30s}  ERROR: {e}")

# ── anonymeter linkability V1–V4 ──────────────────────────────────────────────

print("\n" + "="*60)
print("ANONYMETER LINKABILITY (V1–V4)")
print("="*60)

n_col = len(feature_cols)
aux_link = feature_cols[:n_col//2]
secret_link = feature_cols[n_col//2:]

for label, tr, sy, ct, _ in configs:
    try:
        lr = LinkabilityEvaluator(
            ori=tr, syn=sy, control=ct,
            n_attacks=n_attacks,
            aux_cols=aux_link,
            n_neighbors=5)
        lr.evaluate()
        print(f"{label:30s}  risk={lr.risk().value:.4f}")
    except Exception as e:
        print(f"{label:30s}  ERROR: {e}")

# ── anonymeter inference V1–V4 ────────────────────────────────────────────────

print("\n" + "="*60)
print("ANONYMETER INFERENCE (V1–V4)")
print("="*60)

for label, tr, sy, ct, aux in configs:
    try:
        inf = InferenceEvaluator(
            ori=tr, syn=sy, control=ct,
            aux_cols=aux,
            secret='diagnosis',
            n_attacks=n_attacks)
        inf.evaluate()
        print(f"{label:30s}  risk={inf.risk().value:.4f}")
    except Exception as e:
        print(f"{label:30s}  ERROR: {e}")

# ── mask mia auc ──────────────────────────────────────────────────────────────

print("\n" + "="*60)
print("MASK MIA AUC")
print("="*60)

auc = mask_mia_auc(train, syn, control, feature_cols)
print(f"Mask MIA AUC: {auc:.4f}")
print("0.5 = no leakage, >0.5 = synthetic masks resemble training masks")

# ── summary table ─────────────────────────────────────────────────────────────

print("\n" + "="*60)
print("SUMMARY")
print("="*60)
print(f"{'Metric':<35} {'V1':>8} {'V2':>8} {'V3':>8} {'V4':>8}")
print("-"*60)
print("(run above sections and fill in manually or extend code)")
print(f"Mask MIA AUC (global): {auc:.4f}")