"""Retry-with-different-fit-seed wrapper for the PyBNesian CLG sampling segfault
(see pybnesian_bug_repro/FINDINGS.md): CLinearGaussianCPD leaves a node's factor
unfitted (None) for any discrete-parent combination with zero training rows,
and .sample() dereferences that null factor instead of raising -- a native
segfault, uncatchable in Python.

hc() structure learning is not deterministic given a fixed seed (confirmed:
repeated calls on identical data produced different DAGs), so not every fit
has this defect. The check below is itself crash-safe (confirmed empirically:
cpd.conditional_factor() on an unfit combination returns None, it does not
crash -- only .sample() does), so no subprocess isolation is needed: fit,
check, and only sample once a fit is confirmed clean.
"""

from itertools import product

from semsynth.backends.pybnesian import learn_bn


def is_bn_safe_to_sample(model, train_df):
    """True if every CLG node's discrete-parent combinations have a fitted factor.
    Enumerates the FULL cartesian product of each discrete parent's category
    levels (from train_df's category dtype, the same categories the model was
    fit on), not just training-observed combinations -- ancestral sampling can
    draw any combination, not just ones that appeared in training."""
    import pybnesian

    node_types = model.node_types()
    discrete_nodes = {n for n, t in node_types.items() if "discrete" in type(t).__name__.lower()}

    for node, ftype in node_types.items():
        if node in discrete_nodes:
            continue  # DiscreteFactor nodes don't have this unfitted-cell failure mode
        cpd = model.cpd(node)
        discrete_parents = [p for p in cpd.evidence() if p in discrete_nodes]
        if not discrete_parents:
            continue
        categories = [train_df[p].cat.categories for p in discrete_parents]
        for combo in product(*categories):
            assignment = pybnesian.Assignment(dict(zip(discrete_parents, combo)))
            if cpd.conditional_factor(assignment) is None:
                return False, node, dict(zip(discrete_parents, combo))
    return True, None, None


def learn_bn_safe(
    train_df, bn_type="clg", random_state=42, arc_blacklist=None,
    score=None, operators=None, max_indegree=None, max_retries=20,
):
    """Same as semsynth.backends.pybnesian.learn_bn, but retries with a different
    random_state (random_state, random_state+1, ...) whenever the fitted model
    would segfault on sampling, until a safe fit is found or max_retries is hit."""
    last_bad = None
    for attempt in range(max_retries):
        seed = random_state + attempt
        bn_art = learn_bn(
            train_df, bn_type=bn_type, random_state=seed, arc_blacklist=arc_blacklist,
            score=score, operators=operators, max_indegree=max_indegree,
        )
        safe, bad_node, bad_combo = is_bn_safe_to_sample(bn_art.model, train_df)
        if safe:
            return bn_art, attempt, seed
        last_bad = (bad_node, bad_combo)

    raise RuntimeError(
        f"learn_bn_safe: no safe fit found in {max_retries} attempts "
        f"(last failure: node={last_bad[0]!r}, unfit combination={last_bad[1]!r})"
    )
