"""Generates the final CKD synthetic-dataset CSV artifacts for analysis/plots.

Runs the same S1 (shadow columns) and S2 (shadow patterns) synthesis
branches as evaluate_ckd_missingness_strategies.py, but on the full
dataset with no train/test split -- this script's job is to produce
artifacts, not to score them. Writes three CSVs:

- ckd_synthetic_s1.csv: synthetic features + real missingness reinserted
  1:1 per column (imputation.reinsert_shadow_columns_1to1).
- ckd_synthetic_s2.csv: synthetic features (synthesized together with a
  mined missingness_pattern joint variable) + missingness reinserted
  deterministically per co-occurring column block plus residual resampling,
  driven by the pattern label the synthesizer itself generated for each row
  (imputation.run_s2_branch), preserving cross-column missingness patterns.
- ckd_synthetic_b.csv: the real data, unmodified -- a baseline for
  comparison, not itself synthetic.

Consumed downstream by analyze_ckd_missingness_patterns.py, which loads
one of these CSVs and analyzes its missingness-block rates by class/stage.
"""

import pandas as pd
from imputation import simple_impute
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
from Missingness_Model import MissingnessModel

from dataset_registry import DATASET_REGISTRY
from egfr_staging import add_egfr_columns
from hepatitis_albi_staging import add_albi_columns

dataset_name = "ckd"
config = DATASET_REGISTRY[dataset_name]
df = config["loader"]()
positive_label = config["positive_label"]
categorical_cols = config["categorical_cols"]
min_support = config["min_support"]
min_any_confidence = config["min_any_confidence"]

negative_label = next(v for v in df["class"].unique() if v != positive_label)


def print_sanity_checks(name, out_df):
    print(f"\n--- {name} sanity checks ---")
    print(f"shape: {out_df.shape}")
    print("missing values per column:")
    print(out_df.isnull().sum())
    print("class distribution:")
    print(out_df["class"].value_counts())


def restore_class_labels(synth_label):
    return synth_label.astype(str).map({"1": positive_label, "0": negative_label})


# Full-data preparation (no train/test split -- this script produces final artifacts)
X = df.drop(columns=["class"])
y = df["class"]

for c in categorical_cols:
    if c in X.columns:
        X[c] = X[c].astype("object")

y_encoded = (y == positive_label).astype(int)

# Missingness block mining on full data. This script has no fold split, so
# there is only ever one set of block definitions -- global by construction,
# just like the per-fold mining_model.blocks in
# evaluate_ckd_missingness_strategies.py's approach (mined once, then
# reused for pattern assignment and residual rates below).
mining_model = MissingnessModel().fit(X, min_support=min_support, min_any_confidence=min_any_confidence)
print(f"Global missingness blocks (mined once on full data): "
      f"{len(mining_model.blocks)} blocks (min_support={min_support}, "
      f"min_any_confidence={min_any_confidence}):")
for i, block in enumerate(mining_model.blocks):
    print(f"    Block_{i}: {block['itemset']}")

# Shared: address missingness on the full data (each branch below runs its
# own synthesize() call on top of this, since S1's shadow columns and S2's
# missingness_pattern joint variable each shape the BN's learned structure
# differently and must not leak into each other's draw)
X_filled = simple_impute(X)

# --- Branch S1: shadow columns (BN learns missingness jointly via _NA
# indicator columns, matching evaluate_ckd_missingness_strategies.py) ---
shadow_cols = build_shadow_columns(X)
synth_features_with_shadows, synth_label_s1 = synthesize(
    X_filled, y_encoded, categorical_cols, shadow_cols=shadow_cols
)
s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X.columns)
synth_class_s1 = restore_class_labels(synth_label_s1)
s1_df = s1_features.copy()
s1_df["class"] = synth_class_s1.values
s1_path = f"{dataset_name}_synthetic_s1.csv"
#s1_path_albi = f"{dataset_name}_synthetic_s1_albi.csv"
s1_path_egfr = f"{dataset_name}_synthetic_s1_egfr.csv"
s1_df.to_csv(s1_path, index=False)
print(f"\nSaved {s1_path}")
print_sanity_checks("S1", s1_df)

#s1_df_albi = add_albi_columns(s1_df, export_path=s1_path_albi)
s1_df_egfr = add_egfr_columns(s1_df, export_path=s1_path_egfr)
print(f"Saved {s1_path_egfr}")

# --- Branch S2: shadow patterns (own synthesize() draw, with the mined
# missingness_pattern fed in as a joint variable; see run_s2_branch) ---
s2_features, synth_label_s2 = run_s2_branch(
    X, X_filled, y_encoded, categorical_cols, mining_model
)
synth_class_s2 = restore_class_labels(synth_label_s2)
s2_df = s2_features.copy()
s2_df["class"] = synth_class_s2.values
s2_path = f"{dataset_name}_synthetic_s2.csv"
#s2_path_albi = f"{dataset_name}_synthetic_s2_albi.csv"
s2_path_egfr = f"{dataset_name}_synthetic_s2_egfr.csv"
s2_df.to_csv(s2_path, index=False)
print(f"\nSaved {s2_path}")
print_sanity_checks("S2", s2_df)

#s2_df_albi= add_albi_columns(s2_df, export_path=s2_path_albi)
s2_df_egfr = add_egfr_columns(s2_df, export_path=s2_path_egfr)
print(f"Saved {s2_path_egfr}")


# --- Branch B: baseline (real data, unmodified) ---
b_path = f"{dataset_name}_synthetic_b.csv"  # or "..._real.csv", to avoid implying it's synthetic
#b_path_albi = f"{dataset_name}_synthetic_b_albi.csv"
b_path_egfr = f"{dataset_name}_synthetic_b_egfr.csv"
df.to_csv(b_path, index=False)
print(f"\nSaved {b_path}")
print_sanity_checks("B (real data)", df)

df_egfr = add_egfr_columns(df, export_path=b_path_egfr)
#df_qlbi = add_albi_columns(df, export_path=b_path_albi)
#print(f"Saved {b_path_egfr}")