"""Packaged curated SemMap mappings."""
