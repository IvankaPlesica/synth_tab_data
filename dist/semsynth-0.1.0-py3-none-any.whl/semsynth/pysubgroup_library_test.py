'''
"""Simplest possible pysubgroup run on real CKD data.

Unlike the KMeans-based clustering (unsupervised, tested against an
outcome afterward), pysubgroup works the other way: it needs the
target up front, then searches directly for feature-condition rules
whose target rate deviates most from the overall population.
"""

import pandas as pd
import pysubgroup as ps

from dataset_registry import DATASET_REGISTRY
from imputation import simple_impute

config = DATASET_REGISTRY["ckd"]
df = pd.read_csv("ckd_synthetic_b.csv")  # real data

# pysubgroup can't handle NaN in the search space out of the box -- fill with
# simple_impute (median for numeric, most-frequent for categorical, per-column,
# imputation.py) instead of dropping incomplete rows.
# (A more careful version would keep missingness as its own selector, but
# that's a later refinement, not needed for a first working run.)
df_complete = simple_impute(df)
print(f"Using all {len(df_complete)} rows (imputed) for this first pass")

# target: class (binary, ckd vs notckd) -- not derived from any other
# column in this dataset, so no circularity concern here
target = ps.BinaryTarget("class", "ckd")

# search space: every column except the target itself
searchspace = ps.create_selectors(df_complete, ignore=["class"])

task = ps.SubgroupDiscoveryTask(
    df_complete,
    target,
    searchspace,
    result_set_size=5,   # top 5 subgroups
    depth=3,             # rules with up to 2 conditions combined
    qf=ps.WRAccQF(),      # Weighted Relative Accuracy, same as the library's own example
)

result = ps.DFS().execute(task)
print(result.to_dataframe())
'''

"""pysubgroup run restricted to CKD-positive patients, searching for
severity/phenotype subgroups rather than diagnosis predictors.

Restricting to CKD-positive rows means class is constant and cannot be
used as the target (same reason class was dropped from the KMeans
clustering earlier -- see simple_subgroups.py). A different target is
needed: ckd_stage_cat is used here as the most readily available
graded severity outcome, with the known caveat that it is derived
from sc and age, which remain in the search space -- this reproduces
the same circularity concern already quantified for the clustering
approach (~85% of the cluster-outcome association survived even after
removing sc/age from clustering inputs).

pysubgroup's installed version has no NominalTarget class -- only
BinaryTarget, NumericTarget, FITarget, SoftClassifierTarget. ckd_stage_cat
is converted to a binary is_severe flag (Failure/Disease vs Early/Normal)
to use BinaryTarget.
"""

import pandas as pd
import pysubgroup as ps

from dataset_registry import DATASET_REGISTRY
from imputation import simple_impute
from egfr_staging import add_egfr_columns

config = DATASET_REGISTRY["ckd"]
df = pd.read_csv("ckd_synthetic_b.csv")

df_ckd = df.loc[df["class"] == "ckd"].copy()
print(f"Restricted to {len(df_ckd)} CKD-positive rows")

df_ckd = add_egfr_columns(df_ckd, sc_col="sc", age_col="age")
n_before = len(df_ckd)
df_ckd = df_ckd.dropna(subset=["ckd_stage_cat"])
print(f"Dropped {n_before - len(df_ckd)} unstageable rows; {len(df_ckd)} remain")

# binary severity flag: Failure/Disease = severe, Early/Normal = not severe
df_ckd["is_severe"] = df_ckd["ckd_stage_cat"].isin(["Failure", "Disease"])
print(df_ckd["is_severe"].value_counts())

df_filled = simple_impute(df_ckd)

exclude_cols = ["class", "ckd_stage", "egfr_star", "ckd_stage_cat", "is_severe"]
search_cols = [c for c in df_filled.columns if c not in exclude_cols]

target = ps.BinaryTarget("is_severe", True)
searchspace = ps.create_selectors(df_filled[search_cols + ["is_severe"]], ignore=["is_severe"])

task = ps.SubgroupDiscoveryTask(
    df_filled,
    target,
    searchspace,
    result_set_size=5,
    depth=3,
    qf=ps.WRAccQF(),
)

result = ps.DFS().execute(task)
print(result.to_dataframe())