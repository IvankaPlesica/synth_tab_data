"""
Groups pruned association rules by antecedent, producing "rule families"
-- a more interpretable summary than a flat rule list.

Where a flat rule list shows:
    al,rbcc -> su   conf=0.95
    al,rbcc -> pc   conf=0.93
    al,rbcc -> rbc  conf=0.94
    al,rbcc -> sg   conf=0.96

a rule family summarizes this as:
    antecedent: [al, rbcc]
    predicts:   [pc, rbc, sg, su]
    avg_confidence: 0.945
    n_rules: 4
"""
from collections import defaultdict


def group_into_families(rules):
    """
    Groups rules by antecedent (if_missing), collapsing multiple
    single-target rules sharing the same antecedent into one family.

    Returns
    -------
    list of dicts, one per family, sorted by family size (most
    predicted targets first). Each dict has:
        antecedent      : sorted list of columns in the antecedent
        predicts        : sorted list of target columns this
                           antecedent predicts
        avg_confidence  : mean confidence across the family's rules
        min_confidence  : weakest rule in the family (worth checking
                           if it's notably lower than the average)
        avg_support     : mean support across the family's rules
        n_rules         : how many original rules collapsed into this
                           family
    """
    families = defaultdict(list)
    for r in rules:
        key = frozenset(r["if_missing"])
        families[key].append(r)

    summary = []
    for antecedent, family_rules in families.items():
        confidences = [r["confidence"] for r in family_rules]
        supports = [r["support"] for r in family_rules]

        summary.append({
            "antecedent": sorted(antecedent),
            "predicts": sorted(r["then_missing"] for r in family_rules),
            "avg_confidence": round(sum(confidences) / len(confidences), 4),
            "min_confidence": round(min(confidences), 4),
            "avg_support": round(sum(supports) / len(supports), 4),
            "n_rules": len(family_rules),
        })

    return sorted(summary, key=lambda s: -s["n_rules"])


def print_families(families):
    """Pretty-prints the output of group_into_families."""
    for f in families:
        print(f"\nAntecedent: {f['antecedent']}")
        print(f"  predicts:        {f['predicts']}")
        print(f"  avg_confidence:  {f['avg_confidence']}  "
              f"(min: {f['min_confidence']})")
        print(f"  avg_support:     {f['avg_support']}")
        print(f"  n_rules:         {f['n_rules']}")
