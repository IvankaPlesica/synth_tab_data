"""Per-dataset settings for the missingness/synthesis experiment scripts.

Each entry bundles everything export_ckd_synthetic_datasets.py and
evaluate_ckd_missingness_strategies.py need to run against a given dataset:
how to load it, how to cross-validate it, which column is the positive
class, which columns are categorical, and the thresholds used when mining
missingness blocks (see Missingness_Model.py).
"""

from load_ckd import load_ckd
from load_hepatitis import load_hepatitis

DATASET_REGISTRY = {
    "ckd": {
        "min_support": 0.1, "min_any_confidence": 0.7,
        "loader": load_ckd, "n_splits": 5, "positive_label": "ckd",
        "categorical_cols": ["sg", "al", "su", "rbc", "pc", "pcc", "ba", "htn", "dm",
                              "cad", "appet", "pe", "ane"],
    },
    "hepatitis": {
        "min_support": 0.06, "min_any_confidence": 0.6,
        "loader": load_hepatitis, "n_splits": 3, "positive_label": 1,
        "categorical_cols": ["sex", "steroid", "antivirals", "fatigue",
                              "malaise", "anorexia", "liver_big", "liver_firm",
                              "spleen_palpable", "spiders", "ascites",
                              "varices", "histology"],
    },
}
