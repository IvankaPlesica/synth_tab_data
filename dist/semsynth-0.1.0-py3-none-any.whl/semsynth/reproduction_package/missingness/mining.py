"""Co-missingness block mining (RQ1): finds groups of columns that tend to be
missing together, via Apriori frequent-itemset mining over each row's
missingness indicator vector, filtered by any-confidence.

See PIPELINE_SPECIFICATIONS.md (parent semsynth/ directory) for the full
any-confidence / all-confidence / cross-support definitions and worked
examples.
"""

from efficient_apriori import apriori


def detect_relevant_blocks(itemsets, min_any_confidence):
    """Evaluate confidence on every frequent itemset (not just maximal ones).
    A large itemset failing confidence must not hide a smaller, stronger
    sub-itemset -- confidence is checked before any itemset is discarded, not
    after (checking only maximal itemsets first can swallow a rarer but
    stronger block, e.g. a strong {sod, pot} pair getting hidden inside a
    weaker, larger {rbc, sod, pot} just because the latter has bigger raw
    support).
    """
    all_sets = [
        (frozenset(items), level[items].itemset_count)
        for level in itemsets.values() for items in level
    ]

    results = []
    for itemset, count in all_sets:
        if len(itemset) < 2:
            continue

        singleton_counts = [
            itemsets[1][(col,)].itemset_count
            for col in itemset
            if (col,) in itemsets.get(1, {})
        ]
        if len(singleton_counts) < len(itemset):
            continue

        weakest = min(singleton_counts)
        strongest = max(singleton_counts)
        any_confidence = count / weakest
        all_confidence = count / strongest

        results.append({
            "itemset": sorted(itemset),
            "itemset_frozenset": itemset,
            "count": count,
            "any_confidence": round(any_confidence, 3),
            "all_confidence": round(all_confidence, 3),
            "cross_support": round(all_confidence / any_confidence, 3),
            "is_relevant_block": any_confidence >= min_any_confidence,
        })

    results.sort(key=lambda r: -r["any_confidence"])

    # Dedupe: only drop an itemset if it's a strict subset of a DIFFERENT
    # RELEVANT itemset -- not of any frequent itemset regardless of whether
    # that larger one actually qualified.
    relevant = [r for r in results if r["is_relevant_block"]]
    relevant_sets = [r["itemset_frozenset"] for r in relevant]

    final = []
    for r in relevant:
        is_subset_of_another = any(
            r["itemset_frozenset"] < other
            for other in relevant_sets
            if other != r["itemset_frozenset"]
        )
        if not is_subset_of_another:
            final.append(r)

    for r in final:
        del r["itemset_frozenset"]

    return final


class MissingnessModel:

    @staticmethod
    def missing_matrix(df):
        cols = [c for c in df.columns if df[c].isnull().any()]
        return df[cols].isnull()

    def fit(self, df, min_support, min_any_confidence):
        self.min_support = min_support
        self.min_any_confidence = min_any_confidence

        M = self.missing_matrix(df)
        self.columns = list(M.columns)
        self.base_rates = M.mean().to_dict()
        self.n_rows = len(M)

        cols = M.columns.to_numpy()
        transactions = [tuple(cols[row]) for row in M.to_numpy()]
        itemsets, _ = apriori(transactions, min_support=min_support,
                               output_transaction_ids=True)

        all_blocks = detect_relevant_blocks(itemsets, min_any_confidence)

        # detect_relevant_blocks only drops itemsets that are a strict subset
        # of another -- two maximal itemsets can still partially overlap
        # (e.g. {al,pc,sg,su} and {al,rbc,sg,su}), which violates the
        # column-disjointness downstream code relies on (see
        # missingness/patterns.py's build_column_to_block). Resolve overlaps
        # greedily in descending any_confidence order (the order all_blocks
        # is already sorted in): keep a block only if none of its columns
        # were already claimed by a stronger block.
        self.blocks = []
        claimed_cols = set()
        for b in all_blocks:
            if not b["is_relevant_block"]:
                continue
            if claimed_cols & set(b["itemset"]):
                continue
            self.blocks.append(b)
            claimed_cols.update(b["itemset"])

        self.block_conditionals = {}
        for b in self.blocks:
            key = tuple(b["itemset"])
            block_missing = M[b["itemset"]].all(axis=1)
            self.block_conditionals[key] = {
                col: block_missing[M[col]].mean() for col in b["itemset"]
            }

        return self

    def summary(self):
        print(f"{self.n_rows} rows, {len(self.columns)} columns")
        print(f"min_support={self.min_support}, "
              f"min_any_confidence={self.min_any_confidence}\n")

        print(f"Relevant blocks ({len(self.blocks)}):")
        for b in self.blocks:
            key = tuple(b["itemset"])
            print(f"  {b['itemset']}")
            print(f"    any-confidence: {b['any_confidence']:.3f}")
            print(f"    all-confidence: {b['all_confidence']:.3f}")
            print(f"    cross-support:  {b['cross_support']:.3f}")
            print(f"    conditionals: "
                  + ", ".join(f"{c}={p:.3f}" for c, p in self.block_conditionals[key].items()))

        block_cols = {c for b in self.blocks for c in b["itemset"]}
        independent = sorted(
            (c for c in self.columns if c not in block_cols),
            key=lambda c: -self.base_rates[c],
        )
        print(f"\nIndependent columns ({len(independent)}):")
        for col in independent:
            print(f"  {col}: {self.base_rates[col]:.3f}")
