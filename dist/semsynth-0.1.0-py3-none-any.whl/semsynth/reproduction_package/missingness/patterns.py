"""Per-row missingness-pattern labeling, driven by a fitted MissingnessModel
(missingness/mining.py). A row's label is the mined block(s) fully missing
for that row ("+"-joined column names, "&"-joined if multiple blocks fire),
"mp0" if nothing is missing, or "mp_other" if something is missing but no
mined block matches.
"""


def assign_pattern(row_isna, blocks):
    active = ["+".join(b["itemset"]) for b in blocks if row_isna[b["itemset"]].all()]
    if not active:
        return "mp0" if not row_isna.any() else "mp_other"
    return " & ".join(active)


def assign_patterns(df_features, model):
    """Vectorized convenience wrapper: returns a Series of pattern labels for
    every row in df_features, given a fitted MissingnessModel."""
    return df_features.apply(
        lambda row: assign_pattern(row.isna(), model.blocks), axis=1
    )
