"""Raw-data loaders for the two datasets this pipeline targets: UCI Chronic
Kidney Disease (id 336) and UCI Hepatitis (id 46). Both are cached locally as
gzip'd CSVs under data/cache/ so the package runs offline.
"""

import gzip
import os

import pandas as pd

CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")


def load_ckd(path=None):
    path = path or os.path.join(CACHE_DIR, "336.csv.gz")
    with gzip.open(path) as f:
        df = pd.read_csv(f)

    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

    # The raw UCI CSV has a handful of values corrupted with a literal tab
    # character (e.g. "\tno", "ckd\t") -- not a missingness encoding, just a
    # source-file quirk. Fixed here rather than left for downstream code to
    # trip over.
    df["dm"] = df["dm"].replace("\tno", "no")
    df["class"] = df["class"].replace("ckd\t", "ckd")

    return df


def load_hepatitis(path=None):
    path = path or os.path.join(CACHE_DIR, "46.csv.gz")
    with gzip.open(path) as f:
        df = pd.read_csv(f)

    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

    return df
