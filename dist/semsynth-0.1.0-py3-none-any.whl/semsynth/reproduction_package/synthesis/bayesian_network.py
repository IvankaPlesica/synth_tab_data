"""Thin wrapper around semsynth's PyBNesian backend -- shared by both the S1
(shadow-columns) and S2 (shadow-patterns) branches, which differ only in
which extra discrete column(s) they add to `working` before calling this.

bn_type="semiparametric", max_indegree=2: NOT the "clg"/max_indegree=5 the
thesis Design section describes -- this is a deliberate workaround for a
confirmed native segfault. CLGNetwork.sample() segfaults (unrecoverable, not
a catchable Python exception) whenever a learned node ends up with 2+
discrete parents whose joint combination has zero training rows: .fit()
silently leaves that factor's parameters as None, and .sample() dereferences
it without a null check. Semiparametric networks don't hit this path, and
capping max_indegree at 2 sharply reduces how many discrete-parent
combinations can end up empty in the first place. See
EVALUATION_PIPELINE_DOCUMENTATION.md (parent semsynth/ directory) for the
full repro.

Non-determinism caveat: PyBNesian's hill-climbing structure search (hc(), via
learn_bn) is NOT fully deterministic given a fixed random_state -- repeated
calls on identical data can return different DAGs. This has been observed to
flip which of S1/S2 "wins" between two otherwise-identical pipeline runs. See
the README's Non-determinism section before treating any single run's
S1-vs-S2 comparison as final.
"""

import pandas as pd
from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    coerce_continuous_to_float,
    coerce_discrete_to_category,
    rename_categorical_categories_to_str,
)


def synthesize(X_train_filled, y_train, categorical_cols, shadow_cols=None,
                pattern_labels=None, seed=42):
    working = X_train_filled.copy()
    working["class"] = y_train.values
    extra_disc_cols = []
    if shadow_cols is not None:
        working = pd.concat([working, shadow_cols], axis=1)
        extra_disc_cols += list(shadow_cols.columns)
    if pattern_labels is not None:
        working["missingness_pattern"] = pattern_labels
        extra_disc_cols.append("missingness_pattern")
    disc_cols = [c for c in categorical_cols if c in working.columns] + ["class"] + extra_disc_cols
    cont_cols = [c for c in working.columns if c not in disc_cols]
    working = coerce_discrete_to_category(working, disc_cols)
    working = rename_categorical_categories_to_str(working, disc_cols)
    working = coerce_continuous_to_float(working, cont_cols)
    bn_art = learn_bn(
        working, bn_type="semiparametric", random_state=seed, arc_blacklist=[], max_indegree=2
    )
    synth = bn_art.model.sample(len(working), seed=seed)
    synth_df = synth.to_pandas().reindex(columns=working.columns)
    for c in disc_cols:
        if c in synth_df.columns:
            synth_df[c] = synth_df[c].astype("category")
    synth_label = synth_df["class"]
    synth_features_with_shadows = synth_df.drop(columns=["class"])
    return synth_features_with_shadows, synth_label


def extract_synth_pattern_labels(synth_features_with_pattern):
    out = synth_features_with_pattern.copy()
    pattern_labels = out["missingness_pattern"].astype(str)
    out = out.drop(columns=["missingness_pattern"])
    return out, pattern_labels
