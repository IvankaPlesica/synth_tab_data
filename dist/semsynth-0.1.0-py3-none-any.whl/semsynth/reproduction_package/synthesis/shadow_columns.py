"""S1 branch: missingness represented as one extra binary "_NA" indicator
column per original column, synthesized jointly with the real features so the
BN can learn correlations between missingness and value. Reinsertion is exact
per-column 1:1: a synthetic row's _NA indicator directly determines whether
that column is blanked in the output.
"""

import numpy as np


def build_shadow_columns(X_train):
    return X_train.isnull().astype(int).add_suffix("_NA")


def reinsert_from_shadow_columns(synth_features_with_shadows, original_cols):
    out = synth_features_with_shadows.copy()
    for col in original_cols:
        na_col = f"{col}_NA"
        if na_col in out.columns:
            mask = out[na_col].astype(str) == "1"
            out.loc[mask, col] = np.nan
    out = out.drop(columns=[c for c in out.columns if c.endswith("_NA")])
    return out
