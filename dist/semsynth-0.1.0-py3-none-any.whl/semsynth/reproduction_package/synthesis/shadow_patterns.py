"""S2 branch: missingness represented as a single joint "missingness_pattern"
categorical variable (one mined co-missingness block, or "mp0"/"mp_other"),
synthesized alongside the real features. Reinsertion has two stages:

  1. Deterministic: blank out exactly the block columns implied by each
     synthetic row's generated pattern label.
  2. Residual noise: every column not already blanked by stage 1 gets an
     independent Bernoulli draw at that column's real-data residual
     missingness rate (rows where the column's own block, if any, did NOT
     trigger), computed separately per class.

Both stages preserve the mined block structure while still allowing the
"other" (unblocked) missingness the mined blocks don't explain.
"""

import numpy as np

from missingness.patterns import assign_patterns
from synthesis.bayesian_network import synthesize, extract_synth_pattern_labels


def expand_label(label):
    if label in {"mp0", "mp_other"}:
        return set()
    cols = set()
    for block in label.split(" & "):
        cols.update(block.split("+"))
    return cols


def build_column_to_block(blocks):
    """Map every block member to the full block it belongs to."""
    column_to_block = {}
    seen = set()
    for b in blocks:
        itemset = set(b["itemset"])
        overlap = seen & itemset
        assert not overlap, f"mined blocks overlap on column(s) {overlap}: {blocks}"
        seen.update(itemset)
        for col in itemset:
            column_to_block[col] = itemset
    return column_to_block


def get_residual_rates(X_train, blocks, real_pattern_labels, y_train):
    """Residual missingness rate for every column, computed separately per
    class -- a single flat rate blends together classes with very different
    missingness rates, producing a rate that's wrong for both. Returns
    {str(class_value): {col: rate}} -- keys forced to string so they match
    synth_class after synthesize()'s rename_categorical_categories_to_str.
    """
    residual_rates_by_class = {}

    for class_value in y_train.unique():
        class_mask = (y_train == class_value)
        X_class = X_train.loc[class_mask]
        labels_class = real_pattern_labels.loc[class_mask]

        residual_rates = X_class.isnull().mean().to_dict()

        for b in blocks:
            itemset = b["itemset"]
            block_cols = set(itemset)
            triggered = labels_class.apply(lambda label: block_cols.issubset(expand_label(label)))
            subset = X_class.loc[~triggered]
            for col in itemset:
                residual_rates[col] = subset[col].isnull().mean() if len(subset) else 0.0

        residual_rates_by_class[str(class_value)] = residual_rates

    return residual_rates_by_class


def apply_deterministic_patterns(synth_features, synth_pattern_labels):
    """Blank out each row's block columns exactly, per its label."""
    out = synth_features.copy()
    parsed_labels = [expand_label(label) for label in synth_pattern_labels]

    for i, cols in enumerate(parsed_labels):
        if cols:
            out.loc[out.index[i], list(cols)] = np.nan

    return out, parsed_labels


def apply_residual_noise(out, synth_pattern_labels, parsed_labels, column_to_block,
                          residual_rates_by_class, synth_class, rng):
    eligible_base = np.asarray(synth_pattern_labels) != "mp0"  # excludes true complete rows only
    synth_class_arr = np.asarray(synth_class).astype(str)

    for col in out.columns:
        if col in column_to_block:
            block_cols = column_to_block[col]
            eligible = np.array([
                eligible_base[i] and not block_cols.issubset(parsed_labels[i])
                for i in range(len(out))
            ])
        else:
            eligible = eligible_base  # non-block columns: eligible on every non-mp0 row
        rate = np.array([
            residual_rates_by_class.get(synth_class_arr[i], {}).get(col, 0.0)
            for i in range(len(out))
        ])
        missing = rng.random(len(out)) < rate
        out.loc[missing & eligible, col] = np.nan
    return out


def reinsert_pattern_missingness(synth_features, synth_pattern_labels, column_to_block,
                                  residual_rates_by_class, synth_class, seed=42):
    rng = np.random.default_rng(seed)
    out, parsed_labels = apply_deterministic_patterns(synth_features, synth_pattern_labels)
    out = apply_residual_noise(
        out, synth_pattern_labels, parsed_labels, column_to_block,
        residual_rates_by_class, synth_class, rng
    )
    return out


def run_s2_branch(X, X_filled, y_train, categorical_cols, mining_model, seed=42):
    real_pattern_labels = assign_patterns(X, mining_model)
    column_to_block = build_column_to_block(mining_model.blocks)
    residual_rates_by_class = get_residual_rates(X, mining_model.blocks, real_pattern_labels, y_train)

    synth_features_with_pattern, synth_label = synthesize(
        X_filled, y_train, categorical_cols, pattern_labels=real_pattern_labels, seed=seed
    )
    synth_features, synth_pattern_labels = extract_synth_pattern_labels(synth_features_with_pattern)

    s2_features = reinsert_pattern_missingness(
        synth_features, synth_pattern_labels, column_to_block,
        residual_rates_by_class, synth_label, seed=seed,
    )
    return s2_features, synth_label
