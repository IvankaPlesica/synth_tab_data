#!/usr/bin/env python
"""Entry point 3: missingness-pattern preservation (Dmis) across repeated
synthesis draws.

evaluate.py's Dmis (--pipeline-metadata) is computed once per run, from
synthetic features pooled across CV folds trained on ~80% of the data each.
This script is a separate, decoupled analysis: it draws multiple *full*
synthetic datasets (one BN structure-learn + sample per branch per seed, on
all of the real data, same regime as export_synthetic.py) and computes one
Dmis per draw, so that Dmis can be treated as a random variable and its
run-to-run spread quantified -- necessary because PyBNesian's hill-climbing
structure search is not fully deterministic given a fixed seed (see
synthesis/bayesian_network.py and the README's Non-determinism section).

The missingness blocks are mined once per dataset, on the full real feature
set, matching evaluate.py's Dmis convention: the same fixed set of blocks is
used to assign pattern labels to the real data and to every synthetic draw,
so that Dmis measures how well the SAME real-data pattern definition is
reproduced by different draws, not different re-minings of the blocks
themselves.

Usage:
    python multiseed_dmis.py --dataset ckd --seeds 101 102 103 104 105
    python multiseed_dmis.py --dataset ckd --seeds 106 107 108 109 110 111 112 113 114 115
    python multiseed_dmis.py --dataset hepatitis --seeds 101 102 103 104 105

Writes outputs/multiseed/<dataset>/seed_<seed>/<dataset>_synthetic_{s1,s2}.csv
(the full synthetic draws, one per seed -- same artifact shape as
export_synthetic.py, for later inspection) and appends to
outputs/multiseed/dmis_history.csv (append-only, like metrics_history.csv:
reruns with new seeds accumulate rows rather than overwriting).
"""

import argparse
import os

import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu

from config import DATASET_REGISTRY
from imputation import simple_impute
from missingness.mining import MissingnessModel
from missingness.patterns import assign_patterns
from synthesis.shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis.shadow_patterns import run_s2_branch
from synthesis.bayesian_network import synthesize
from evaluate import compute_dmis

OUTPUTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "multiseed")
DMIS_HISTORY_FIELDS = ["dataset", "branch", "seed", "dmis"]


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", required=True, choices=sorted(DATASET_REGISTRY))
    p.add_argument("--seeds", type=int, nargs="+", required=True,
                   help="One or more seeds; each produces one full synthetic draw per branch.")
    p.add_argument("--output-dir", default=OUTPUTS_DIR)
    p.add_argument("--save-draws", action=argparse.BooleanOptionalAction, default=True,
                   help="Also write each draw's synthetic CSVs to "
                        "<output-dir>/<dataset>/seed_<seed>/ (default on).")
    return p.parse_args()


def generate_draw(dataset_name, config, mining_model, seed):
    """One full-dataset S1 + S2 synthesis draw, same regime as
    export_synthetic.py (fit on all real rows, no CV split)."""
    df = config.loader()
    positive_label = config.positive_label
    categorical_cols = config.categorical_cols

    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")
    y_encoded = (y == positive_label).astype(int)

    X_filled = simple_impute(X)

    shadow_cols = build_shadow_columns(X)
    synth_features_with_shadows, _ = synthesize(
        X_filled, y_encoded, categorical_cols, shadow_cols=shadow_cols, seed=seed
    )
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X.columns)

    s2_features, _ = run_s2_branch(X, X_filled, y_encoded, categorical_cols, mining_model, seed=seed)

    return s1_features, s2_features


def append_dmis_history(records, path):
    write_header = not os.path.exists(path)
    with open(path, "a") as f:
        if write_header:
            f.write(",".join(DMIS_HISTORY_FIELDS) + "\n")
        for r in records:
            f.write(",".join(str(r[k]) for k in DMIS_HISTORY_FIELDS) + "\n")


def main():
    args = parse_args()
    dataset_name = args.dataset
    config = DATASET_REGISTRY[dataset_name]

    df = config.loader()
    X = df.drop(columns=["class"])

    # Mined ONCE on the full real data, shared across every seed's draw --
    # same convention evaluate.py uses for its own Dmis computation.
    mining_model = MissingnessModel().fit(X, min_support=config.min_support, min_any_confidence=config.min_any_confidence)
    real_labels = assign_patterns(X, mining_model)

    dataset_outdir = os.path.join(args.output_dir, dataset_name)
    os.makedirs(dataset_outdir, exist_ok=True)
    history_path = os.path.join(args.output_dir, "dmis_history.csv")

    records = []
    dmis_by_branch = {"S1": [], "S2": []}
    for seed in args.seeds:
        print(f"--- seed {seed} ---")
        s1_features, s2_features = generate_draw(dataset_name, config, mining_model, seed)

        if args.save_draws:
            seed_dir = os.path.join(dataset_outdir, f"seed_{seed}")
            os.makedirs(seed_dir, exist_ok=True)
            s1_features.to_csv(os.path.join(seed_dir, f"{dataset_name}_synthetic_s1.csv"), index=False)
            s2_features.to_csv(os.path.join(seed_dir, f"{dataset_name}_synthetic_s2.csv"), index=False)

        for branch, features in [("S1", s1_features), ("S2", s2_features)]:
            synth_labels = assign_patterns(features, mining_model)
            dmis = compute_dmis(real_labels, synth_labels)
            dmis_by_branch[branch].append(dmis)
            records.append({"dataset": dataset_name, "branch": branch, "seed": seed, "dmis": round(dmis, 4)})
            print(f"  {branch}: Dmis = {dmis:.4f}")

    append_dmis_history(records, history_path)
    print(f"\nAppended {len(records)} rows to {history_path}")

    for branch, vals in dmis_by_branch.items():
        print(f"{branch}: n={len(vals)} mean={np.mean(vals):.4f} std={np.std(vals):.4f} "
              f"min={np.min(vals):.4f} max={np.max(vals):.4f}")

    if len(dmis_by_branch["S1"]) >= 2 and len(dmis_by_branch["S2"]) >= 2:
        u, p = mannwhitneyu(dmis_by_branch["S1"], dmis_by_branch["S2"], alternative="two-sided")
        print(f"\nMann-Whitney U (this run's seeds only): U={u}, p={p:.4f}")
        print("(For a test across ALL accumulated seeds, not just this run's, "
              f"load {history_path} and compare per branch.)")


if __name__ == "__main__":
    main()
