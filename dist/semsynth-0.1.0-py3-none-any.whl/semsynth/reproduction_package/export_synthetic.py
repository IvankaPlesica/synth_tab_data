#!/usr/bin/env python
"""Entry point 2: generate synthetic-dataset CSV artifacts for a dataset.

Runs the same S1 (shadow columns) and S2 (shadow patterns) synthesis
branches as evaluate.py, but on the full dataset with no train/test split --
this script's job is to produce artifacts for downstream analysis/plots, not
to score them. Writes three CSVs to outputs/:

  <dataset>_synthetic_s1.csv : synthetic features + real missingness
      reinserted 1:1 per column.
  <dataset>_synthetic_s2.csv : synthetic features (synthesized jointly with a
      mined missingness_pattern variable) + missingness reinserted per
      co-occurring column block plus residual resampling.
  <dataset>_synthetic_b.csv  : the real data, unmodified -- a baseline, not
      itself synthetic.

--with-staging additionally writes a "_staged" sibling of each CSV with the
dataset-appropriate post-hoc disease-severity columns added (eGFR/CKD stage
for CKD, ALBI score/grade for hepatitis) -- see config.DATASET_REGISTRY.
"""

import argparse
import json
import os

from config import DATASET_REGISTRY
from imputation import simple_impute
from missingness.mining import MissingnessModel
from synthesis.shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis.shadow_patterns import run_s2_branch
from synthesis.bayesian_network import synthesize

OUTPUTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")


def write_missingness_metadata(dataset_name, mining_model, path):
    """Persist the mined blocks' own measures (any-confidence, all-confidence,
    cross-support, and the conditional probability of the whole block missing
    given each member is missing -- same figures MissingnessModel.summary()
    prints, here written out instead of only ever appearing in a terminal)
    plus the missingness support of columns not claimed by any block. This
    describes the real data / generator config, not downstream fidelity, so
    it lives next to the synthetic-data artifacts, not in pipeline_metadata.json.
    Overwrites (does not append) this dataset's entry, same convention as
    evaluate.py's write_pipeline_metadata."""
    block_cols = {c for b in mining_model.blocks for c in b["itemset"]}
    independent_columns = {
        col: round(float(rate), 4)
        for col, rate in mining_model.base_rates.items()
        if col not in block_cols
    }
    blocks_metadata = [
        {
            "itemset": b["itemset"],
            "any_confidence": b["any_confidence"],
            "all_confidence": b["all_confidence"],
            "cross_support": b["cross_support"],
            "conditionals": {
                col: round(float(p), 4)
                for col, p in mining_model.block_conditionals[tuple(b["itemset"])].items()
            },
        }
        for b in mining_model.blocks
    ]
    record = {
        "min_support": mining_model.min_support,
        "min_any_confidence": mining_model.min_any_confidence,
        "blocks": blocks_metadata,
        "independent_columns": independent_columns,
    }

    all_metadata = {}
    if os.path.exists(path):
        with open(path) as f:
            all_metadata = json.load(f)
    all_metadata[dataset_name] = record
    with open(path, "w") as f:
        json.dump(all_metadata, f, indent=2)


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", required=True, choices=sorted(DATASET_REGISTRY))
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--output-dir", default=OUTPUTS_DIR)
    p.add_argument("--with-staging", action="store_true",
                    help="Also write a disease-staged sibling CSV per branch "
                         "(eGFR for CKD, ALBI for hepatitis).")
    return p.parse_args()


def print_sanity_checks(name, out_df):
    print(f"\n--- {name} sanity checks ---")
    print(f"shape: {out_df.shape}")
    print("missing values per column:")
    print(out_df.isnull().sum())
    print("class distribution:")
    print(out_df["class"].value_counts())


def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    dataset_name = args.dataset
    config = DATASET_REGISTRY[dataset_name]

    df = config.loader()
    positive_label = config.positive_label
    categorical_cols = config.categorical_cols
    min_support = config.min_support
    min_any_confidence = config.min_any_confidence
    negative_label = next(v for v in df["class"].unique() if v != positive_label)

    def restore_class_labels(synth_label):
        return synth_label.astype(str).map({"1": positive_label, "0": negative_label})

    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")
    y_encoded = (y == positive_label).astype(int)

    # Missingness block mining on the full data -- no fold split here, so
    # there is only ever one set of block definitions.
    mining_model = MissingnessModel().fit(X, min_support=min_support, min_any_confidence=min_any_confidence)
    print(f"Global missingness blocks (mined once on full data): {len(mining_model.blocks)} blocks "
          f"(min_support={min_support}, min_any_confidence={min_any_confidence}):")
    for i, block in enumerate(mining_model.blocks):
        print(f"    Block_{i}: {block['itemset']}")

    missingness_json_path = os.path.join(args.output_dir, "missingness_metadata.json")
    write_missingness_metadata(dataset_name, mining_model, missingness_json_path)
    print(f"(missingness block metadata written to {missingness_json_path})")

    # Shared: address missingness on the full data. Each branch below runs
    # its own synthesize() call on top of this, since S1's shadow columns and
    # S2's missingness_pattern joint variable each shape the BN's learned
    # structure differently and must not leak into each other's draw.
    X_filled = simple_impute(X)

    # --- Branch S1: shadow columns ---
    shadow_cols = build_shadow_columns(X)
    synth_features_with_shadows, synth_label_s1 = synthesize(
        X_filled, y_encoded, categorical_cols, shadow_cols=shadow_cols, seed=args.seed
    )
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X.columns)
    s1_df = s1_features.copy()
    s1_df["class"] = restore_class_labels(synth_label_s1).values
    s1_path = os.path.join(args.output_dir, f"{dataset_name}_synthetic_s1.csv")
    s1_df.to_csv(s1_path, index=False)
    print(f"\nSaved {s1_path}")
    print_sanity_checks("S1", s1_df)

    # --- Branch S2: shadow patterns ---
    s2_features, synth_label_s2 = run_s2_branch(X, X_filled, y_encoded, categorical_cols, mining_model, seed=args.seed)
    s2_df = s2_features.copy()
    s2_df["class"] = restore_class_labels(synth_label_s2).values
    s2_path = os.path.join(args.output_dir, f"{dataset_name}_synthetic_s2.csv")
    s2_df.to_csv(s2_path, index=False)
    print(f"\nSaved {s2_path}")
    print_sanity_checks("S2", s2_df)

    # --- Branch B: baseline (real data, unmodified) ---
    b_path = os.path.join(args.output_dir, f"{dataset_name}_synthetic_b.csv")
    df.to_csv(b_path, index=False)
    print(f"\nSaved {b_path}")
    print_sanity_checks("B (real data)", df)

    if args.with_staging:
        for name, out_df, path in [("S1", s1_df, s1_path), ("S2", s2_df, s2_path), ("B", df, b_path)]:
            staged_path = path.replace(".csv", "_staged.csv")
            config.staging_fn(out_df, export_path=staged_path, **config.staging_kwargs)
            print(f"Saved {staged_path}")


if __name__ == "__main__":
    main()
