#!/usr/bin/env python
"""Entry point 6: summarize subgroup disparity (D) and privacy risk across
repeated synthesis runs.

Neither outputs/multiseed/subgroup_history.csv (written by
multiseed_subgroups.py) nor outputs/multiseed/privacy_history.csv (written
by multiseed_subgroups.py --privacy-checks and multiseed_privacy.py) store
cross-run summaries -- each is a tidy, append-only table of one row per
run x subgroup x branch, by design (so reruns with new seeds accumulate
rather than overwrite). Neither file computes D_S1/D_S2 (the
synthetic-vs-real change in disparity, i.e. Delta_S1 - Delta_R /
Delta_S2 - Delta_R) at all -- that requires pairing each run's S1/S2 gap
against that SAME run's R gap before averaging, which a per-row CSV can't
express on its own.

This script reads both history files, does that pairing per seed (not
difference-of-means -- matched per run, matching how Delta/D are defined
in the RQ3 methods section), and writes two summary CSVs. It is read-only
with respect to the history files and can be re-run at any time to
refresh the summary as more seeds are added; it does not itself run any
synthesis.

Usage:
    python summarize_subgroups.py [--input-dir outputs/multiseed/] [--output-dir outputs/multiseed/]

Writes outputs/multiseed/subgroup_disparity_summary.csv (one row per
dataset x subgroup; TPR/TNR gaps for R/S1/S2 plus D_S1/D_S2, mean +/- std
across runs, TNR columns blank when specificity is structurally undefined
for that subgroup -- 0 cases of one outcome class in every run, not merely
small) and outputs/multiseed/privacy_summary.csv (one row per dataset x
subgroup x branch; mean_risk/subgroup_attack_rate/non_subgroup_attack_rate,
mean +/- std across runs).
"""

import argparse
import os

import numpy as np
import pandas as pd

DEFAULT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "multiseed")


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input-dir", default=DEFAULT_DIR)
    p.add_argument("--output-dir", default=DEFAULT_DIR)
    return p.parse_args()


def _assign_run_id(g):
    """seed is NOT a reliable unique run identifier -- the same seed value
    can appear in two separate invocations (e.g. one fairness-only run and
    one --privacy-checks run), and PyBNesian's non-determinism means those
    are two different draws, not a duplicate. Rows are always written as a
    complete (R, S1, S2) triplet per run, in that order, in a single
    append_csv() call (see multiseed_subgroups.py), so file order reliably
    identifies which rows belong to the same run even when seed doesn't."""
    return np.arange(len(g)) // 3


def summarize_disparity(subgroup_history_path):
    sg = pd.read_csv(subgroup_history_path)
    rows = []
    for dataset in sorted(sg["dataset"].unique()):
        sub = sg[sg["dataset"] == dataset]
        for subgroup in sub["subgroup"].unique():
            g = sub[sub["subgroup"] == subgroup].copy()
            g["run_id"] = _assign_run_id(g)
            piv_tpr = g.pivot_table(index="run_id", columns="branch", values="tpr_gap", aggfunc="first")
            n_runs = len(piv_tpr)

            row = {"dataset": dataset, "subgroup": subgroup, "n_runs": n_runs}

            for label, col in [("R", "R"), ("S1", "S1"), ("S2", "S2")]:
                row[f"tpr_{label}_mean"] = round(piv_tpr[col].mean(), 4)
                row[f"tpr_{label}_std"] = round(piv_tpr[col].std(), 4)
            d_s1 = (piv_tpr["S1"] - piv_tpr["R"]).dropna()
            d_s2 = (piv_tpr["S2"] - piv_tpr["R"]).dropna()
            row["tpr_D_S1_mean"] = round(d_s1.mean(), 4)
            row["tpr_D_S1_std"] = round(d_s1.std(), 4)
            row["tpr_D_S2_mean"] = round(d_s2.mean(), 4)
            row["tpr_D_S2_std"] = round(d_s2.std(), 4)

            tnr_defined = g["specificity_gap"].notna().any()
            row["tnr_defined"] = tnr_defined
            if tnr_defined:
                piv_tnr = g.pivot_table(index="run_id", columns="branch", values="specificity_gap", aggfunc="first")
                for label, col in [("R", "R"), ("S1", "S1"), ("S2", "S2")]:
                    row[f"tnr_{label}_mean"] = round(piv_tnr[col].mean(), 4)
                    row[f"tnr_{label}_std"] = round(piv_tnr[col].std(), 4)
                d_s1_tnr = (piv_tnr["S1"] - piv_tnr["R"]).dropna()
                d_s2_tnr = (piv_tnr["S2"] - piv_tnr["R"]).dropna()
                row["tnr_D_S1_mean"] = round(d_s1_tnr.mean(), 4)
                row["tnr_D_S1_std"] = round(d_s1_tnr.std(), 4)
                row["tnr_D_S2_mean"] = round(d_s2_tnr.mean(), 4)
                row["tnr_D_S2_std"] = round(d_s2_tnr.std(), 4)
            else:
                for label in ["R", "S1", "S2", "D_S1", "D_S2"]:
                    row[f"tnr_{label}_mean"] = ""
                    row[f"tnr_{label}_std"] = ""
            rows.append(row)
    return pd.DataFrame(rows)


def summarize_privacy(privacy_history_path):
    pv = pd.read_csv(privacy_history_path)
    rows = []
    for dataset in sorted(pv["dataset"].unique()):
        sub = pv[pv["dataset"] == dataset]
        for subgroup in sub["subgroup"].unique():
            g = sub[sub["subgroup"] == subgroup]
            for branch in ["S1", "S2"]:
                b = g[g["branch"] == branch]
                if b.empty:
                    continue
                rows.append({
                    "dataset": dataset, "subgroup": subgroup, "branch": branch, "n_runs": len(b),
                    "mean_risk_mean": round(b["mean_risk_across_folds"].mean(), 4),
                    "mean_risk_std": round(b["mean_risk_across_folds"].std(), 4),
                    "subgroup_attack_rate_mean": round(b["subgroup_attack_rate"].mean(), 4),
                    "subgroup_attack_rate_std": round(b["subgroup_attack_rate"].std(), 4),
                    "non_subgroup_attack_rate_mean": round(b["non_subgroup_attack_rate"].mean(), 4),
                    "non_subgroup_attack_rate_std": round(b["non_subgroup_attack_rate"].std(), 4),
                })
    return pd.DataFrame(rows)


def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    subgroup_history_path = os.path.join(args.input_dir, "subgroup_history.csv")
    privacy_history_path = os.path.join(args.input_dir, "privacy_history.csv")

    if os.path.exists(subgroup_history_path):
        disparity_summary = summarize_disparity(subgroup_history_path)
        out_path = os.path.join(args.output_dir, "subgroup_disparity_summary.csv")
        disparity_summary.to_csv(out_path, index=False)
        print(f"Wrote {out_path} ({len(disparity_summary)} rows)")
        print(disparity_summary.to_string(index=False))
    else:
        print(f"(skipping disparity summary -- {subgroup_history_path} not found)")

    print()

    if os.path.exists(privacy_history_path):
        privacy_summary = summarize_privacy(privacy_history_path)
        out_path = os.path.join(args.output_dir, "privacy_summary.csv")
        privacy_summary.to_csv(out_path, index=False)
        print(f"Wrote {out_path} ({len(privacy_summary)} rows)")
        print(privacy_summary.to_string(index=False))
    else:
        print(f"(skipping privacy summary -- {privacy_history_path} not found)")


if __name__ == "__main__":
    main()
