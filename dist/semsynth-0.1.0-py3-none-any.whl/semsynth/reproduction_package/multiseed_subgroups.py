#!/usr/bin/env python
"""Entry point 4: subgroup fairness (and, optionally, subgroup-broken-down
privacy risk) across repeated synthesis draws.

evaluate.py --subgroup-metadata computes subgroup TPR/specificity gaps and
(if --privacy-checks is also on) subgroup-broken-down privacy risk once per
run, writing/overwriting subgroup_metadata.json -- a single-run "first look"
that this script deliberately leaves untouched (no seed column, no way to
accumulate multiple runs without losing earlier ones). This script is a
separate, decoupled analysis: like multiseed_dmis.py did for Dmis, it treats
each per-subgroup metric as a random variable across repeated, independent
CV runs (each with its own seed, hence its own non-deterministically learned
BN structures), and accumulates results in append-only CSVs instead.

Fairness (TPR/specificity gaps) and privacy risk are run as decoupled
batches on purpose -- pass --privacy-checks to also compute subgroup privacy
risk (much slower: a 500-query singling-out attack per branch per fold), or
leave it off for a fairness-only run. Because each run independently
re-learns the BN structure per fold, a fairness-only run's synthetic draws
are NOT the same draws as a --privacy-checks run's, even at the same seed --
by design (see the project discussion this script came out of): we are
estimating each metric's own marginal distribution across draws, not making
any claim about fairness and privacy being correlated within a single draw.

Representation/prevalence is NOT recomputed here -- it's already present in
the existing subgroup_metadata.json from evaluate.py's original runs
(representation doesn't depend on --privacy-checks, so both datasets'
existing runs already have it).

Usage:
    python multiseed_subgroups.py --dataset hepatitis --seed 101
    python multiseed_subgroups.py --dataset hepatitis --seed 101 --privacy-checks
    python multiseed_subgroups.py --dataset ckd --seed 101 --privacy-checks

Appends to outputs/multiseed/subgroup_history.csv (always) and
outputs/multiseed/privacy_history.csv (only if --privacy-checks).
"""

import argparse
import os
import warnings

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from statsmodels.genmod.generalized_linear_model import PerfectSeparationWarning

from config import DATASET_REGISTRY
from imputation import simple_impute, mice_and_regression
from missingness.mining import MissingnessModel
from synthesis.shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis.shadow_patterns import run_s2_branch
from synthesis.bayesian_network import synthesize
from subgroups.outlier_rule import OutlierRule
from evaluate import group_tpr, group_tnr

warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=PerfectSeparationWarning)

OUTPUTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "multiseed")
SUBGROUP_FIELDS = ["dataset", "subgroup", "branch", "seed", "n_subgroup", "total",
                    "tpr_gap", "specificity_gap", "n_neg_subgroup", "n_neg_non_subgroup"]
PRIVACY_FIELDS = ["dataset", "subgroup", "branch", "seed",
                   "mean_risk_across_folds", "subgroup_attack_rate", "non_subgroup_attack_rate"]


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", required=True, choices=sorted(DATASET_REGISTRY))
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--output-dir", default=OUTPUTS_DIR)
    p.add_argument("--privacy-checks", action=argparse.BooleanOptionalAction, default=False,
                   help="Also compute subgroup-broken-down privacy risk (500-query "
                        "singling-out attack per branch per fold -- much slower).")
    return p.parse_args()


def append_csv(records, fields, path):
    write_header = not os.path.exists(path)
    with open(path, "a") as f:
        if write_header:
            f.write(",".join(fields) + "\n")
        for r in records:
            f.write(",".join(str(r[k]) for k in fields) + "\n")


def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    dataset_name = args.dataset
    config = DATASET_REGISTRY[dataset_name]

    outlier_rule = OutlierRule.load(dataset_name)
    if args.privacy_checks:
        from anonymeter.evaluators import SinglingOutEvaluator
        from subgroups.privacy import attacked_rows

    df = config.loader()
    n_splits = config.n_splits
    positive_label = config.positive_label
    categorical_cols = config.categorical_cols
    min_support = config.min_support
    min_any_confidence = config.min_any_confidence

    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=args.seed)
    print(f"\nDataset: {dataset_name}  |  seed: {args.seed}  |  privacy_checks: {args.privacy_checks}")

    oof_proba = {b: np.full(len(df), np.nan) for b in ["R", "S1", "S2"]}
    subgroup_defs = [("outlier", outlier_rule.apply)] + list(config.extra_subgroups)

    if args.privacy_checks:
        so_risk = {"S1": [], "S2": []}
        so_attacked_mask = {
            "S1": pd.Series(False, index=df.index),
            "S2": pd.Series(False, index=df.index),
        }

    for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
        print(f"Fold {fold_num + 1}/{n_splits} in progress.")
        X_train = X.iloc[train_index].copy()
        X_test = X.iloc[test_index].copy()
        y_train = (y.iloc[train_index] == positive_label).astype(int)
        y_test = (y.iloc[test_index] == positive_label).astype(int)

        _, proba_r, _ = mice_and_regression(
            X_train, y_train, X_test, y_test, seed=args.seed, return_proba=True, return_metrics=True
        )
        oof_proba["R"][test_index] = proba_r

        X_train_filled = simple_impute(X_train)

        shadow_cols = build_shadow_columns(X_train)
        synth_features_with_shadows, synth_label_s1 = synthesize(
            X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols, seed=args.seed
        )
        s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)
        _, proba_s1, _ = mice_and_regression(
            s1_features, synth_label_s1, X_test, y_test, seed=args.seed, return_proba=True, return_metrics=True
        )
        oof_proba["S1"][test_index] = proba_s1

        if args.privacy_checks:
            n_attacks_s1 = min(500, len(X_train))
            so_eval_s1 = SinglingOutEvaluator(ori=X_train, syn=s1_features, control=X_test, n_attacks=n_attacks_s1)
            so_eval_s1.evaluate(mode="multivariate")
            so_risk["S1"].append(so_eval_s1.risk().value)
            hits_s1 = attacked_rows(X_test, so_eval_s1.queries())
            if hits_s1:
                so_attacked_mask["S1"].loc[list(hits_s1)] = True

        mining_model = MissingnessModel().fit(X_train, min_support=min_support, min_any_confidence=min_any_confidence)
        s2_features, synth_label_s2 = run_s2_branch(
            X_train, X_train_filled, y_train, categorical_cols, mining_model, seed=args.seed
        )
        _, proba_s2, _ = mice_and_regression(
            s2_features, synth_label_s2, X_test, y_test, seed=args.seed, return_proba=True, return_metrics=True
        )
        oof_proba["S2"][test_index] = proba_s2

        if args.privacy_checks:
            n_attacks_s2 = min(500, len(X_train))
            so_eval_s2 = SinglingOutEvaluator(ori=X_train, syn=s2_features, control=X_test, n_attacks=n_attacks_s2)
            so_eval_s2.evaluate(mode="multivariate")
            so_risk["S2"].append(so_eval_s2.risk().value)
            hits_s2 = attacked_rows(X_test, so_eval_s2.queries())
            if hits_s2:
                so_attacked_mask["S2"].loc[list(hits_s2)] = True

    for branch, proba in oof_proba.items():
        assert not np.isnan(proba).any(), f"every row should get exactly one OOF prediction ({branch})"
    y_true = (y == positive_label).astype(int).to_numpy()

    subgroups = [("outlier", outlier_rule.apply(df))] + [
        (name, mask_fn(df)) for name, mask_fn in config.extra_subgroups
    ]

    subgroup_records, privacy_records = [], []
    for subgroup_name, mask in subgroups:
        n_neg_subgroup = int(((y_true == 0) & mask).sum())
        n_neg_non_subgroup = int(((y_true == 0) & ~mask).sum())
        print(f"\nSubgroup: {subgroup_name} (n={mask.sum()}/{len(df)}, n_neg_subgroup={n_neg_subgroup})")

        for branch, proba in oof_proba.items():
            y_pred = (proba >= 0.5).astype(int)
            tpr_out = group_tpr(y_true, y_pred, mask)
            tpr_non = group_tpr(y_true, y_pred, ~mask)
            tpr_gap = (tpr_non - tpr_out) if (tpr_out is not None and tpr_non is not None) else None
            tnr_out = group_tnr(y_true, y_pred, mask)
            tnr_non = group_tnr(y_true, y_pred, ~mask)
            spec_gap = (tnr_non - tnr_out) if (tnr_out is not None and tnr_non is not None) else None
            print(f"  {branch}: tpr_gap={tpr_gap} specificity_gap={spec_gap}")
            subgroup_records.append({
                "dataset": dataset_name, "subgroup": subgroup_name, "branch": branch, "seed": args.seed,
                "n_subgroup": int(mask.sum()), "total": int(len(df)),
                "tpr_gap": round(tpr_gap, 4) if tpr_gap is not None else "",
                "specificity_gap": round(spec_gap, 4) if spec_gap is not None else "",
                "n_neg_subgroup": n_neg_subgroup, "n_neg_non_subgroup": n_neg_non_subgroup,
            })

        if args.privacy_checks:
            for branch in ["S1", "S2"]:
                mean_risk = float(np.mean(so_risk[branch]))
                attacked_arr = so_attacked_mask[branch].to_numpy()
                out_rate = attacked_arr[mask].mean() if mask.sum() else float("nan")
                non_rate = attacked_arr[~mask].mean() if (~mask).sum() else float("nan")
                print(f"  privacy[{branch}]: mean_risk={mean_risk:.4f} subgroup_rate={out_rate:.3f} "
                      f"non_subgroup_rate={non_rate:.3f}")
                privacy_records.append({
                    "dataset": dataset_name, "subgroup": subgroup_name, "branch": branch, "seed": args.seed,
                    "mean_risk_across_folds": round(mean_risk, 4),
                    "subgroup_attack_rate": round(float(out_rate), 4) if not np.isnan(out_rate) else "",
                    "non_subgroup_attack_rate": round(float(non_rate), 4) if not np.isnan(non_rate) else "",
                })

    subgroup_path = os.path.join(args.output_dir, "subgroup_history.csv")
    append_csv(subgroup_records, SUBGROUP_FIELDS, subgroup_path)
    print(f"\nAppended {len(subgroup_records)} rows to {subgroup_path}")

    if args.privacy_checks:
        privacy_path = os.path.join(args.output_dir, "privacy_history.csv")
        append_csv(privacy_records, PRIVACY_FIELDS, privacy_path)
        print(f"Appended {len(privacy_records)} rows to {privacy_path}")


if __name__ == "__main__":
    main()
