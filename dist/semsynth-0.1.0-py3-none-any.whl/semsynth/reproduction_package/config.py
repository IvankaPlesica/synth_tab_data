"""Per-dataset configuration for the R/S1/S2 missingness-synthesis pipeline.

Everything that differs between CKD and hepatitis lives here: how to load the
raw data, how to cross-validate it, which column/value is the positive class,
which columns are categorical, the missingness-mining thresholds (see
missingness/mining.py), the hand-defined subgroups reported alongside the
clustering-derived outlier subgroup, and which post-hoc disease-staging
function applies (eGFR for CKD, ALBI for hepatitis).
"""

from dataclasses import dataclass, field
from typing import Callable, Optional

import pandas as pd

from data.loaders import load_ckd, load_hepatitis
from staging.egfr import add_egfr_columns
from staging.albi import add_albi_columns


@dataclass(frozen=True)
class DatasetConfig:
    name: str
    loader: Callable[[], pd.DataFrame]
    n_splits: int
    positive_label: object
    categorical_cols: list
    min_support: float
    min_any_confidence: float
    # (subgroup_name, mask_fn(df) -> np.ndarray[bool]) pairs reported alongside
    # the clustering-derived "outlier" subgroup.
    extra_subgroups: list
    # Post-hoc disease-staging function used by export_synthetic.py --with-staging,
    # and its column-name kwargs for this dataset's raw columns.
    staging_fn: Callable
    staging_kwargs: dict
    # Discovery (subgroups/discovery.py): whether the clustering that produced
    # this dataset's artifacts/outlier_rule_<name>.joblib was fit on the full
    # dataset (CKD) or restricted to one class first (hepatitis -- survivors
    # only, i.e. class != positive_label, to avoid trivially re-deriving the
    # mortality split; see subgroups/discovery.py). None means no restriction.
    discovery_restrict_to_label: Optional[object] = None


def _mp0_mask(df):
    return (df.drop(columns=["class"], errors="ignore").isnull().sum(axis=1) == 0).to_numpy()


DATASET_REGISTRY = {
    "ckd": DatasetConfig(
        name="ckd",
        loader=load_ckd,
        n_splits=5,
        positive_label="ckd",
        categorical_cols=["sg", "al", "su", "rbc", "pc", "pcc", "ba", "htn", "dm",
                           "cad", "appet", "pe", "ane"],
        min_support=0.1,
        min_any_confidence=0.7,
        extra_subgroups=[
            ("age>=65", lambda df: (df["age"] >= 65).to_numpy()),
            ("htn==yes", lambda df: (df["htn"] == "yes").to_numpy()),
            ("dm==yes", lambda df: (df["dm"] == "yes").to_numpy()),
            ("mp0", _mp0_mask),
        ],
        staging_fn=add_egfr_columns,
        staging_kwargs={"sc_col": "sc", "age_col": "age"},
        discovery_restrict_to_label=None,
    ),
    "hepatitis": DatasetConfig(
        name="hepatitis",
        loader=load_hepatitis,
        n_splits=3,
        positive_label=1,
        categorical_cols=["sex", "steroid", "antivirals", "fatigue",
                           "malaise", "anorexia", "liver_big", "liver_firm",
                           "spleen_palpable", "spiders", "ascites",
                           "varices", "histology"],
        min_support=0.06,
        min_any_confidence=0.6,
        extra_subgroups=[
            ("age>=50", lambda df: (df["age"] >= 50).to_numpy()),
            ("mp0", _mp0_mask),
        ],
        staging_fn=add_albi_columns,
        staging_kwargs={"bilirubin_col": "bilirubin", "albumin_col": "albumin", "age_col": "age"},
        # outlier_rule_hepatitis.joblib was fit on survivors only (class != 1);
        # discovery_restrict_to_label is the class VALUE to keep, i.e. "not the
        # positive_label" -- resolved at load time since the negative label's
        # literal value depends on what's present in the raw data.
        discovery_restrict_to_label="__not_positive__",
    ),
}
