#!/usr/bin/env python
"""Entry point 5: subgroup-broken-down privacy risk across repeated
synthesis draws, decoupled from downstream predictive evaluation.

multiseed_subgroups.py --privacy-checks runs the full R/S1/S2 MICE +
logistic-regression loop (needed for subgroup fairness gaps) and computes
privacy risk as a byproduct of that same per-fold loop. That MICE fitting
(fit(10, 20), three times per fold -- R, S1, S2) is almost certainly the
dominant cost and is not needed for privacy risk at all: a singling-out
attack only needs a synthetic draw, the real rows it was generated from, and
a held-out control population that draw never saw. This script drops MICE
and the R/S1/S2 predictive model entirely and keeps only what privacy risk
actually depends on: the per-fold train/control split (still needed -- a
singling-out attack requires a genuine held-out control set that the
synthesizer never saw, which is why this can't be done the cheap
full-dataset way multiseed_dmis.py does it) and the S1/S2 synthesis + attack
itself.

Usage:
    python multiseed_privacy.py --dataset hepatitis --seed 101
    python multiseed_privacy.py --dataset ckd --seed 101

Appends to outputs/multiseed/privacy_history.csv -- same schema, same file,
as multiseed_subgroups.py --privacy-checks, so seeds from either script
accumulate together.
"""

import argparse
import os
import warnings

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from statsmodels.genmod.generalized_linear_model import PerfectSeparationWarning

from config import DATASET_REGISTRY
from imputation import simple_impute
from missingness.mining import MissingnessModel
from synthesis.shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis.shadow_patterns import run_s2_branch
from synthesis.bayesian_network import synthesize
from subgroups.outlier_rule import OutlierRule
from subgroups.privacy import attacked_rows

warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=PerfectSeparationWarning)

OUTPUTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "multiseed")
PRIVACY_FIELDS = ["dataset", "subgroup", "branch", "seed",
                   "mean_risk_across_folds", "subgroup_attack_rate", "non_subgroup_attack_rate"]


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", required=True, choices=sorted(DATASET_REGISTRY))
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--output-dir", default=OUTPUTS_DIR)
    return p.parse_args()


def append_csv(records, fields, path):
    write_header = not os.path.exists(path)
    with open(path, "a") as f:
        if write_header:
            f.write(",".join(fields) + "\n")
        for r in records:
            f.write(",".join(str(r[k]) for k in fields) + "\n")


def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    dataset_name = args.dataset
    config = DATASET_REGISTRY[dataset_name]

    from anonymeter.evaluators import SinglingOutEvaluator

    outlier_rule = OutlierRule.load(dataset_name)
    df = config.loader()
    n_splits = config.n_splits
    positive_label = config.positive_label
    categorical_cols = config.categorical_cols
    min_support = config.min_support
    min_any_confidence = config.min_any_confidence

    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=args.seed)
    print(f"\nDataset: {dataset_name}  |  seed: {args.seed}  |  privacy-only (no MICE)")

    subgroup_defs = [("outlier", outlier_rule.apply)] + list(config.extra_subgroups)
    so_risk = {"S1": [], "S2": []}
    so_attacked_mask = {
        "S1": pd.Series(False, index=df.index),
        "S2": pd.Series(False, index=df.index),
    }

    for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
        print(f"Fold {fold_num + 1}/{n_splits} in progress.")
        X_train = X.iloc[train_index].copy()
        X_test = X.iloc[test_index].copy()
        y_train = (y.iloc[train_index] == positive_label).astype(int)

        X_train_filled = simple_impute(X_train)

        shadow_cols = build_shadow_columns(X_train)
        synth_features_with_shadows, _ = synthesize(
            X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols, seed=args.seed
        )
        s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)

        n_attacks_s1 = min(500, len(X_train))
        so_eval_s1 = SinglingOutEvaluator(ori=X_train, syn=s1_features, control=X_test, n_attacks=n_attacks_s1)
        so_eval_s1.evaluate(mode="multivariate")
        so_risk["S1"].append(so_eval_s1.risk().value)
        hits_s1 = attacked_rows(X_test, so_eval_s1.queries())
        if hits_s1:
            so_attacked_mask["S1"].loc[list(hits_s1)] = True

        mining_model = MissingnessModel().fit(X_train, min_support=min_support, min_any_confidence=min_any_confidence)
        s2_features, _ = run_s2_branch(X_train, X_train_filled, y_train, categorical_cols, mining_model, seed=args.seed)

        n_attacks_s2 = min(500, len(X_train))
        so_eval_s2 = SinglingOutEvaluator(ori=X_train, syn=s2_features, control=X_test, n_attacks=n_attacks_s2)
        so_eval_s2.evaluate(mode="multivariate")
        so_risk["S2"].append(so_eval_s2.risk().value)
        hits_s2 = attacked_rows(X_test, so_eval_s2.queries())
        if hits_s2:
            so_attacked_mask["S2"].loc[list(hits_s2)] = True

    subgroups = [("outlier", outlier_rule.apply(df))] + [
        (name, mask_fn(df)) for name, mask_fn in config.extra_subgroups
    ]

    privacy_records = []
    for subgroup_name, mask in subgroups:
        print(f"\nSubgroup: {subgroup_name} (n={mask.sum()}/{len(df)})")
        for branch in ["S1", "S2"]:
            mean_risk = float(np.mean(so_risk[branch]))
            attacked_arr = so_attacked_mask[branch].to_numpy()
            out_rate = attacked_arr[mask].mean() if mask.sum() else float("nan")
            non_rate = attacked_arr[~mask].mean() if (~mask).sum() else float("nan")
            print(f"  privacy[{branch}]: mean_risk={mean_risk:.4f} subgroup_rate={out_rate:.3f} "
                  f"non_subgroup_rate={non_rate:.3f}")
            privacy_records.append({
                "dataset": dataset_name, "subgroup": subgroup_name, "branch": branch, "seed": args.seed,
                "mean_risk_across_folds": round(mean_risk, 4),
                "subgroup_attack_rate": round(float(out_rate), 4) if not np.isnan(out_rate) else "",
                "non_subgroup_attack_rate": round(float(non_rate), 4) if not np.isnan(non_rate) else "",
            })

    privacy_path = os.path.join(args.output_dir, "privacy_history.csv")
    append_csv(privacy_records, PRIVACY_FIELDS, privacy_path)
    print(f"\nAppended {len(privacy_records)} rows to {privacy_path}")


if __name__ == "__main__":
    main()
