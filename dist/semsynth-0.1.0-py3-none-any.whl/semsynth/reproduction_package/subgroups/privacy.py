"""Row-level singling-out privacy check, built on top of anonymeter's
SinglingOutEvaluator.

API note (anonymeter 1.0.0, verified against the installed package's source
-- anonymeter/evaluators/singling_out_evaluator.py): SinglingOutEvaluator
does not expose which specific control rows were singled out. Internally,
evaluate() only computes a COUNT of control matches (self._n_control,
further rescaled by a size-correction factor when len(control) !=
len(ori)), never row identities -- and that count is computed from the full
candidate query list generated against `syn`, not filtered down to the
queries that actually succeeded against `ori`. The only public per-item
result is `.queries()`: the list of successful attack query strings that DID
single out a real training row.

attacked_rows() re-runs those same ori-successful queries against a control
set directly, using the same df.query(query, engine="python") mechanism the
library itself uses internally -- a control row counts as "attacked" if a
query that successfully singled out a real training row ALSO uniquely
matches that control row. This is a deliberately different (more meaningful)
signal than the library's own internal bulk count: it measures whether a
real successful attack generalizes to a held-out row, not how often the
attacker's query-generation process would work on held-out data by chance.
"""


def attacked_rows(control_df, successful_queries):
    """Re-run each ori-successful singling-out query against control_df,
    using the same matching rule the library uses (a query singles out iff
    it matches exactly 1 row). Returns the set of control_df index labels
    singled out by >=1 query."""
    attacked = set()
    for q in successful_queries:
        try:
            matched = control_df.query(q, engine="python")
        except Exception:
            continue
        if len(matched) == 1:
            attacked.add(matched.index[0])
    return attacked
