"""Subgroup discovery: KMeans clustering of real patient data into K
subgroups, plus a distance-to-centroid outlier rule and two depth-3 decision
trees that explain (never score) the clusters and the outlier flag.

Default behavior -- fit_default_subgroups() -- exactly reproduces the fixed
K=2 clustering that artifacts/outlier_rule_ckd.joblib and
artifacts/outlier_rule_hepatitis.joblib were built with, so a reader who
re-runs discovery gets byte-comparable results to what evaluate.py's default
--dataset run already ships as a frozen artifact. K is not re-selected by any
automated criterion here: it was chosen once, by hand, outside this pipeline
(a small silhouette/stability sweep across k=2/3, external to this repo).

CKD's clustering uses the full dataset; hepatitis's uses survivors only
(class != positive_label) to avoid trivially re-deriving the mortality split
-- see config.DATASET_REGISTRY[...].discovery_restrict_to_label. Both
decision trees are for human-readable reporting only; OutlierRule.apply()
(subgroups/outlier_rule.py) never uses outlier_tree to score anything, it
uses the exact kmeans-distance rule.

An opt-in, more rigorous alternative -- run_k_search_extension() -- is also
provided: silhouette-based K search over a range, seed/resample stability
checks, and (optionally) a distal-outcome association test. This is an
independent exploration/validation path, off by default, and does not
produce an artifact compatible with OutlierRule -- it answers "is K=2 a
reasonable choice", not "what does the frozen rule do".
"""

import itertools
from collections import Counter
from dataclasses import dataclass
from typing import List, Optional

import joblib
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, export_text

from categorical_encoder import CategoricalEncoder

RANDOM_STATE = 42
DEFAULT_K = 2
OUTLIER_STD = 2.0
TREE_DEPTH = 3


def _restrict(df, config):
    """Apply config.discovery_restrict_to_label, if any, resolving the
    "survivors only" sentinel against the data's actual negative-class
    value."""
    if config.discovery_restrict_to_label is None:
        return df
    if config.discovery_restrict_to_label == "__not_positive__":
        negative_label = next(v for v in df["class"].unique() if v != config.positive_label)
        return df[df["class"] == negative_label].reset_index(drop=True)
    return df[df["class"] == config.discovery_restrict_to_label].reset_index(drop=True)


def fit_default_subgroups(dataset_name, config, k=DEFAULT_K, random_state=RANDOM_STATE):
    """Reproduces the exact clustering + outlier-rule fitting procedure used
    to build artifacts/outlier_rule_<dataset_name>.joblib. Returns a dict
    with the same keys OutlierRule expects, ready to joblib.dump()."""
    df = config.loader()
    df = _restrict(df, config)

    cat_cols = config.categorical_cols
    real = df.drop(columns=["class"])
    real[cat_cols] = real[cat_cols].astype("object")
    num_cols = [c for c in real.columns if c not in cat_cols]

    medians = real[num_cols].median()
    modes = real[cat_cols].mode().iloc[0]

    def prep(x):
        out = x.copy()
        out[num_cols] = out[num_cols].fillna(medians)
        out[cat_cols] = out[cat_cols].fillna(modes)
        return out

    imputed = prep(real)
    encoder = CategoricalEncoder().fit(imputed)
    encoded = encoder.transform(imputed)
    scaler = StandardScaler().fit(encoded)
    scaled = scaler.transform(encoded)
    kmeans = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit(scaled)
    cluster_labels = kmeans.labels_

    print(f"[{dataset_name}] cluster sizes: "
          f"{pd.Series(cluster_labels).value_counts().sort_index().to_dict()}")
    print(f"[{dataset_name}] silhouette: {silhouette_score(scaled, cluster_labels):.3f} "
          "(reported only -- K is fixed above, not chosen by this score)")

    seed_runs = [KMeans(n_clusters=k, n_init=10, random_state=s).fit_predict(scaled) for s in range(10)]
    seed_aris = [adjusted_rand_score(a, b) for a, b in itertools.combinations(seed_runs, 2)]
    print(f"[{dataset_name}] seed stability (10 seeds): mean ARI="
          f"{sum(seed_aris) / len(seed_aris):.3f}")

    sparse_encoded = encoder.transform(real)  # NaNs preserved, for tree-fitting only

    cluster_tree = DecisionTreeClassifier(max_depth=TREE_DEPTH, random_state=random_state)
    cluster_tree.fit(sparse_encoded, cluster_labels)
    print(f"[{dataset_name}] cluster-explanation tree fidelity: "
          f"{cluster_tree.score(sparse_encoded, cluster_labels):.1%}")

    distances = np.linalg.norm(scaled - kmeans.cluster_centers_[cluster_labels], axis=1)
    outlier_mask = np.zeros(len(scaled), dtype=bool)
    cluster_cutoffs = {}
    for c in sorted(set(cluster_labels)):
        mask = cluster_labels == c
        d = distances[mask]
        cutoff = d.mean() + OUTLIER_STD * d.std()
        cluster_cutoffs[c] = cutoff
        outlier_mask[mask] = d > cutoff
    print(f"[{dataset_name}] flagged {outlier_mask.sum()} outliers out of {len(scaled)}")

    outlier_tree = DecisionTreeClassifier(max_depth=TREE_DEPTH, random_state=random_state)
    outlier_tree.fit(sparse_encoded, outlier_mask.astype(int))
    print(f"[{dataset_name}] outlier-rule tree fidelity: "
          f"{outlier_tree.score(sparse_encoded, outlier_mask.astype(int)):.1%}")

    return {
        "outlier_tree": outlier_tree,
        "encoder": encoder,
        "cat_cols": cat_cols,
        "kmeans": kmeans,
        "scaler": scaler,
        "medians": medians,
        "modes": modes,
        "num_cols": num_cols,
        "cluster_cutoffs": cluster_cutoffs,
        "cluster_tree": cluster_tree,
    }


def save_outlier_rule(dataset_name, config, out_path, k=DEFAULT_K):
    saved = fit_default_subgroups(dataset_name, config, k=k)
    joblib.dump(saved, out_path)
    print(f"Saved {out_path}")


# ---------------------------------------------------------------------------
# Opt-in extension: silhouette K search + stability/persistence checks.
# Independent of fit_default_subgroups()/OutlierRule; never runs unless
# explicitly requested (evaluate.py --with-k-search / a direct call here).
# ---------------------------------------------------------------------------

K_RANGE = range(2, 9)


def _make_ohe(**kwargs):
    from sklearn.preprocessing import OneHotEncoder
    try:
        return OneHotEncoder(**kwargs, sparse_output=False)
    except TypeError:
        return OneHotEncoder(**kwargs, sparse=False)


def _split_cols(df, categorical_cols):
    cat_cols = [c for c in categorical_cols if c in df.columns]
    num_cols = [c for c in df.columns if c not in cat_cols]
    return num_cols, cat_cols


def _fit_encoder(df, num_cols, cat_cols):
    transformers = []
    if num_cols:
        transformers.append(("num", Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("scl", StandardScaler()),
        ]), num_cols))
    if cat_cols:
        transformers.append(("cat", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")),
            ("ohe", _make_ohe(handle_unknown="ignore")),
        ]), cat_cols))
    return ColumnTransformer(transformers, remainder="drop").fit(df)


def _encode_for_tree(df, num_cols, cat_cols):
    """NaN-passthrough encoding: each categorical value becomes a 0/1
    indicator that stays NaN where the source value is missing, so the
    tree's native NaN routing decides where missing rows go at each split."""
    parts, names = [], []
    for c in num_cols:
        vals = pd.to_numeric(df[c], errors="coerce")
        parts.append(vals.to_numpy().reshape(-1, 1))
        names.append(c)
    for c in cat_cols:
        s = df[c]
        cats = sorted(s.dropna().astype(str).unique())
        for cat in cats:
            ind = np.where(s.isna(), np.nan, (s.astype(str) == cat).astype(float))
            parts.append(ind.reshape(-1, 1))
            names.append(f"{c}={cat}")
    X = np.hstack(parts) if parts else np.empty((len(df), 0))
    return X, names


def _pick_k(Z, k_range, random_state):
    best_k, best_score = None, -1.0
    for k in k_range:
        if k >= len(Z):
            break
        labels = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit_predict(Z)
        if len(set(labels)) < 2:
            continue
        score = silhouette_score(Z, labels)
        if score > best_score:
            best_k, best_score = k, score
    return best_k, best_score


@dataclass
class SubgroupModel:
    df: pd.DataFrame
    num_cols: List[str]
    cat_cols: List[str]
    encoder: ColumnTransformer
    kmeans: KMeans
    k: int
    silhouette: float
    cluster_labels: np.ndarray
    sizes: dict
    tree: DecisionTreeClassifier
    tree_feature_names: List[str]
    tree_train_accuracy: float
    rules_text: str
    random_state: int = RANDOM_STATE


def fit_subgroups(df, categorical_cols, exclude_cols=None, k=None, k_range=K_RANGE,
                   max_depth=4, random_state=RANDOM_STATE):
    """Cluster df's rows (k picked by silhouette over k_range unless given
    explicitly) and explain with a NaN-native decision tree fit on raw
    features."""
    work = df.copy()
    if exclude_cols:
        work = work.drop(columns=[c for c in exclude_cols if c in work.columns])
    num_cols, cat_cols = _split_cols(work, categorical_cols)
    for c in cat_cols:
        work[c] = work[c].astype("object")

    encoder = _fit_encoder(work, num_cols, cat_cols)
    Z = encoder.transform(work)

    if k is None:
        k, silhouette = _pick_k(Z, k_range, random_state)
        if k is None:
            raise ValueError("Could not find k >= 2 with more than one cluster")
    else:
        tmp_labels = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit_predict(Z)
        silhouette = silhouette_score(Z, tmp_labels) if len(set(tmp_labels)) > 1 else float("nan")

    kmeans = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit(Z)
    labels = kmeans.labels_
    sizes = {int(cid): int(n) for cid, n in pd.Series(labels).value_counts().sort_index().items()}

    Xn, names = _encode_for_tree(work, num_cols, cat_cols)
    tree = DecisionTreeClassifier(
        max_depth=max_depth, min_samples_leaf=max(5, len(work) // 40),
        class_weight="balanced", random_state=random_state,
    )
    tree.fit(Xn, labels)
    train_accuracy = float((tree.predict(Xn) == labels).mean())
    rules_text = export_text(tree, feature_names=names).replace("class:", "cluster:")

    return SubgroupModel(
        df=work.reset_index(drop=True), num_cols=num_cols, cat_cols=cat_cols, encoder=encoder,
        kmeans=kmeans, k=k, silhouette=silhouette, cluster_labels=labels, sizes=sizes, tree=tree,
        tree_feature_names=names, tree_train_accuracy=train_accuracy, rules_text=rules_text,
        random_state=random_state,
    )


def check_real_stability(df, categorical_cols, exclude_cols=None, k=None,
                          n_runs=20, subsample_frac=0.8, random_state=RANDOM_STATE):
    """Seed stability (fixed k, n_runs seeds, mean pairwise ARI) + resample
    stability (n_runs subsamples of subsample_frac rows, k re-picked each
    time). A low score here means the real clusters aren't a solid target to
    check synthetic persistence against."""
    if k is None:
        k = fit_subgroups(df, categorical_cols, exclude_cols, random_state=random_state).k

    seed_labels = []
    for seed in range(n_runs):
        m = fit_subgroups(df, categorical_cols, exclude_cols, k=k, random_state=seed)
        seed_labels.append(m.cluster_labels)
    seed_aris = [adjusted_rand_score(a, b) for a, b in itertools.combinations(seed_labels, 2)]

    resample_fits = []
    for i in range(n_runs):
        sub = df.sample(frac=subsample_frac, random_state=i)
        m = fit_subgroups(sub, categorical_cols, exclude_cols, k=None, random_state=random_state)
        resample_fits.append((sub.index, m.k, m.cluster_labels))

    k_agreement = Counter(k_i for _, k_i, _ in resample_fits)
    resample_aris = []
    for (idx_a, _, lab_a), (idx_b, _, lab_b) in itertools.combinations(resample_fits, 2):
        a = pd.Series(lab_a, index=idx_a)
        b = pd.Series(lab_b, index=idx_b)
        common = a.index.intersection(b.index)
        if len(common) < 10:
            continue
        resample_aris.append(adjusted_rand_score(a.loc[common], b.loc[common]))

    return {
        "k": k,
        "seed_ari_mean": float(np.mean(seed_aris)),
        "seed_ari_std": float(np.std(seed_aris)),
        "k_agreement": dict(k_agreement),
        "resample_ari_mean": float(np.mean(resample_aris)) if resample_aris else None,
        "resample_ari_std": float(np.std(resample_aris)) if resample_aris else None,
    }


def _match_clusters(centroids_a, centroids_b):
    n = max(len(centroids_a), len(centroids_b))
    cost = np.full((n, n), 1e6)
    for i in range(len(centroids_b)):
        for j in range(len(centroids_a)):
            cost[i, j] = np.linalg.norm(centroids_b[i] - centroids_a[j])
    row_ind, col_ind = linear_sum_assignment(cost)
    return {int(r): int(c) for r, c in zip(row_ind, col_ind) if r < len(centroids_b)}


def _transform_new(model, new_df):
    work = new_df.copy()
    for c in model.cat_cols:
        if c in work.columns:
            work[c] = work[c].astype("object")
    cols = model.num_cols + model.cat_cols
    return model.encoder.transform(work[cols])


def check_persistence(model, new_df, k_range=K_RANGE):
    """Does the cluster structure found on real data still hold in new_df
    (e.g. synthetic data)? Compares transfer-assignment (via the model's own
    fitted centroids) against an independent KMeans refit on new_df alone,
    matched back to the original clusters by nearest centroid (Hungarian
    matching), reported as an agreement fraction and Adjusted Rand Index."""
    Z_new = _transform_new(model, new_df)
    transfer_labels = model.kmeans.predict(Z_new)

    real_sizes = pd.Series(model.cluster_labels).value_counts().sort_index()
    new_sizes = pd.Series(transfer_labels).value_counts().sort_index()

    capped_range = range(2, min(max(k_range) + 1, len(Z_new)))
    k_new, sil_new = _pick_k(Z_new, capped_range, model.random_state)

    result = {
        "transfer_labels": transfer_labels,
        "real_sizes": real_sizes.to_dict(),
        "new_sizes": new_sizes.to_dict(),
        "independent_k": k_new,
        "independent_silhouette": sil_new,
        "agreement": None,
        "ari": None,
    }
    if k_new is not None:
        kmeans_new = KMeans(n_clusters=k_new, n_init=10, random_state=model.random_state).fit(Z_new)
        perm = _match_clusters(model.kmeans.cluster_centers_, kmeans_new.cluster_centers_)
        matched = np.array([perm.get(int(lbl), -1) for lbl in kmeans_new.labels_])
        result["agreement"] = round(float((matched == transfer_labels).mean()), 4)
        result["ari"] = round(float(adjusted_rand_score(transfer_labels, kmeans_new.labels_)), 4)
    return result


def run_k_search_extension(dataset_name, config, s1_df=None, s2_df=None):
    """Opt-in report: silhouette K search + stability on real data, plus
    persistence against S1/S2 synthetic data if provided. Prints a summary
    and returns the raw dicts; does not touch artifacts/outlier_rule_*.joblib
    or affect evaluate.py's default scoring in any way."""
    df = config.loader()
    df = _restrict(df, config)

    model = fit_subgroups(df, config.categorical_cols, exclude_cols=["class"])
    print(f"\n[{dataset_name}] k-search chose k={model.k} (silhouette={model.silhouette:.3f}), n={len(df)}")
    print("Cluster sizes:", model.sizes)
    print(model.rules_text)

    stability = check_real_stability(df, config.categorical_cols, exclude_cols=["class"], k=model.k)
    print(f"\n[{dataset_name}] seed stability (20 seeds, k={stability['k']}): "
          f"mean ARI={stability['seed_ari_mean']:.3f} (std={stability['seed_ari_std']:.3f})")
    print(f"[{dataset_name}] resample stability: k agreement={stability['k_agreement']}")

    persistence = {}
    for name, synth_df in [("S1", s1_df), ("S2", s2_df)]:
        if synth_df is None:
            continue
        result = check_persistence(model, synth_df)
        persistence[name] = result
        print(f"[{dataset_name}] {name} persistence: agreement={result['agreement']} ari={result['ari']} "
              f"independent_k={result['independent_k']}")

    return {"model": model, "stability": stability, "persistence": persistence}
