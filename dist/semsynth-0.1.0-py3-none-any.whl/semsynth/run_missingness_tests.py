import pandas as pd
from collections import Counter
from missingness_tests import mar_mnar_test


def mar_mnar_stability(df, n_runs=10):
    """Run mar_mnar_test multiple times and report mean/std AUC per column,
    plus how often each predictor appeared in the top-3 across runs, since
    no fixed random seed means each run gives slightly different results."""
    all_runs = []
    predictor_counts = {}

    for i in range(n_runs):
        results = mar_mnar_test(df)
        all_runs.append({col: r["auc"] for col, r in results.items()})

        for col, r in results.items():
            predictor_counts.setdefault(col, Counter())
            predictor_counts[col].update(r["top_predictors"])

    auc_df = pd.DataFrame(all_runs)
    summary = pd.DataFrame({
        "mean_auc": auc_df.mean(),
        "std_auc": auc_df.std(),
        "min_auc": auc_df.min(),
        "max_auc": auc_df.max(),
    }).round(4)

    # most frequent top-3 predictors across runs, per column
    summary["top_predictors_stable"] = [
        [p for p, _ in predictor_counts[col].most_common(3)] if col in predictor_counts else []
        for col in summary.index
    ]

    return summary.sort_values("mean_auc", ascending=False)

'''
if __name__ == "__main__":
    df = pd.read_csv("ckd_with_egfr.csv")
    exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
    df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

    summary = mar_mnar_stability(df_features, n_runs=10)
    print(summary)'''


import pandas as pd
from load_hepatitis import load_hepatitis
from hepatitis_albi_staging import add_albi_columns

df = load_hepatitis()
df = add_albi_columns(df, export_path="hepatitis_with_albi.csv")

exclude_cols = ["class", "albi_score", "albi_grade", "albi_grade_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

summary = mar_mnar_stability(df_features, n_runs=10)
print(summary)
