"""Standalone RQ2 skeleton for CKD: Branch R vs S1 (shadow columns, 1:1) vs S2 (known blocks exact 1:1 + independent columns 1:1).

The only thing borrowed from the semsynth package is the actual PyBNesian model
call (learn_bn + a handful of dtype-coercion helpers). No pipeline.py, no TOML
config, no other backend is touched.

S2 approach: known clinical blocks (urinalysis, CBC), as originally mined in
RQ1, are transplanted 1:1 by row index from the real training data -- but
ONLY when a real row's mask EXACTLY matches the block (all member columns
missing together), not just partial overlap. Everything outside the known
blocks (independent columns) is transplanted 1:1 per column, same mechanism
as S1. No synthesizer-generated pattern label is used anywhere in S2.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer

from load_ckd import load_ckd
from egfr_staging import add_egfr_columns

from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    infer_types,
    coerce_discrete_to_category,
    coerce_continuous_to_float,
    rename_categorical_categories_to_str,
)

# ============================================================
# 1. LOAD DATA
# ============================================================
df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
df["class"] = df["class"].str.strip()

exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

# ============================================================
# 2. SPLIT
# ============================================================
y_all = (df["class"] == "ckd").astype(int)
train_idx, test_idx = train_test_split(
    df.index, test_size=0.2, random_state=42, stratify=y_all
)

train_df = df.loc[train_idx].reset_index(drop=True)
test_df = df.loc[test_idx].reset_index(drop=True)

train_features = train_df[df_features.columns]
test_features = test_df[df_features.columns]
train_y = (train_df["class"] == "ckd").astype(int)
test_y = (test_df["class"] == "ckd").astype(int)

# ============================================================
# 3. SHARED SCORING FUNCTION
# ============================================================
def score_branch(X_train, y_train, X_test, y_test):
    cat_cols = X_train.select_dtypes(include=["object", "category"]).columns.tolist()
    X_train_enc = pd.get_dummies(X_train, columns=cat_cols, dummy_na=False)
    X_test_enc = pd.get_dummies(X_test, columns=cat_cols, dummy_na=False)
    X_test_enc = X_test_enc.reindex(columns=X_train_enc.columns, fill_value=0)

    imputer = IterativeImputer(max_iter=10, random_state=42)
    X_train_imp = imputer.fit_transform(X_train_enc)
    X_test_imp = imputer.transform(X_test_enc)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_imp)
    X_test_scaled = scaler.transform(X_test_imp)

    model = LogisticRegression(max_iter=5000, random_state=42)
    model.fit(X_train_scaled, y_train)
    proba = model.predict_proba(X_test_scaled)[:, 1]
    return round(roc_auc_score(y_test, proba), 4)

# ============================================================
# 4. BRANCH R -- baseline
# ============================================================
score_r = score_branch(train_features, train_y, test_features, test_y)
print(f"Score R (baseline): {score_r}")

# ============================================================
# 5. SYNTHESIZE -- PyBNesian
# (no missingness_pattern column needed -- only class + real features go in)
# ============================================================
bn_input_cols = [
    c for c in train_df.columns
    if c not in ("egfr_star", "ckd_stage", "ckd_stage_cat")
]
train_bn_input = train_df[bn_input_cols]

train_bn_filled = train_bn_input.fillna(train_bn_input.median(numeric_only=True))
for col in train_bn_filled.select_dtypes(include="object").columns:
    mode_vals = train_bn_filled[col].mode()
    if not mode_vals.empty:
        train_bn_filled[col] = train_bn_filled[col].fillna(mode_vals.iloc[0])

working = train_bn_filled.copy()
disc_cols, cont_cols = infer_types(working)
working = coerce_discrete_to_category(working, disc_cols)
working = rename_categorical_categories_to_str(working, disc_cols)
working = coerce_continuous_to_float(working, cont_cols)

bn_art = learn_bn(working, bn_type="clg", random_state=42, arc_blacklist=[])
synth = bn_art.model.sample(len(working), seed=42)
synth_df = synth.to_pandas().reindex(columns=working.columns)
for c in disc_cols:
    if c in synth_df.columns:
        synth_df[c] = synth_df[c].astype("category")

synth_label = (synth_df["class"].astype(str) == "ckd").astype(int)
synth_features = synth_df.drop(columns=["class"])

synth_df.to_csv("rq2_synthetic_raw.csv", index=False)

# ============================================================
# 6. BRANCH S1 -- shadow COLUMNS, 1:1 transplant (no resampling)
# ============================================================
def reinsert_shadow_columns_1to1(synth_features, real_train_features):
    out = synth_features.copy().reset_index(drop=True)
    real_reset = real_train_features.reset_index(drop=True)

    n = min(len(out), len(real_reset))
    for col in real_reset.columns:
        if col not in out.columns:
            continue
        mask = real_reset[col].isnull().iloc[:n]
        out.loc[mask[mask].index, col] = np.nan

    return out

s1_features = reinsert_shadow_columns_1to1(synth_features, train_features)
score_s1 = score_branch(s1_features, synth_label, test_features, test_y)
print(f"\nScore S1 (shadow columns, 1:1): {score_s1}")

# ============================================================
# 7. BRANCH S2 -- known blocks (EXACT match, 1:1) + independent columns (1:1)
# ============================================================
KNOWN_BLOCKS = [
    ["al", "pc", "rbc", "sg", "su"],
    ["hemo", "pcv", "rbcc", "wbcc"],
]

block_member_cols = set()
for block in KNOWN_BLOCKS:
    block_member_cols.update(block)
independent_cols = [c for c in train_features.columns if c not in block_member_cols]

def reinsert_known_blocks_1to1(synth_features, real_train_features, known_blocks):
    """
    For each known block, only transplant the block-blank onto a synthetic
    row if the corresponding real row's mask EXACTLY matches that block
    (all member columns missing together) -- not partial/any overlap.
    """
    out = synth_features.copy().reset_index(drop=True)
    real_reset = real_train_features.reset_index(drop=True)
    n = min(len(out), len(real_reset))

    for block in known_blocks:
        block = [c for c in block if c in out.columns]
        if not block:
            continue
        exact_block_mask = real_reset[block].isnull().all(axis=1).iloc[:n]
        rows_to_blank = exact_block_mask[exact_block_mask].index
        for col in block:
            out.loc[rows_to_blank, col] = np.nan

    return out

def reinsert_independent_1to1(synth_features, real_train_features, independent_cols):
    """
    1:1 transplant per independent column, by row index -- same mechanism
    as S1, restricted to columns outside the known blocks.
    """
    out = synth_features.copy().reset_index(drop=True)
    real_reset = real_train_features.reset_index(drop=True)
    n = min(len(out), len(real_reset))

    for col in independent_cols:
        if col not in out.columns:
            continue
        mask = real_reset[col].isnull().iloc[:n]
        out.loc[mask[mask].index, col] = np.nan

    return out

s2_features = reinsert_known_blocks_1to1(synth_features, train_features, KNOWN_BLOCKS)
s2_features = reinsert_independent_1to1(s2_features, train_features, independent_cols)

score_s2 = score_branch(s2_features, synth_label, test_features, test_y)
print(f"Score S2 (known blocks exact 1:1 + independent 1:1): {score_s2}")

# ============================================================
# SAVE OUTPUTS
# ============================================================
s1_with_label = s1_features.copy()
s1_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s1_with_label.to_csv("rq2_synthetic_s1.csv", index=False)

s2_with_label = s2_features.copy()
s2_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s2_with_label.to_csv("rq2_synthetic_s2.csv", index=False)

# ============================================================
# 8. RESULTS
# ============================================================
print("\n--- RQ2 skeleton results (known blocks exact 1:1 + independent 1:1) ---")
print(f"Score R : {score_r}")
print(f"Score S1: {score_s1}")
print(f"Score S2: {score_s2}")