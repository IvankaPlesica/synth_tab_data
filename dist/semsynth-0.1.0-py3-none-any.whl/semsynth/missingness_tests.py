from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import roc_auc_score
import pandas as pd


def mar_mnar_test(df):

    # Separate numerical and categorical predictors
    num_df = df.select_dtypes(include="number")
    obj_df = df.select_dtypes(include="object")

    # One-hot encode categorical variables only if they exist
    if not obj_df.empty:
        cat_df = pd.get_dummies(
            obj_df,
            drop_first=False,
            dummy_na=True
        )
    else:
        cat_df = pd.DataFrame(index=df.index)

    # Missingness indicators for numerical variables
    miss_indicators = num_df.isnull().astype(int).add_suffix("_NA")

    # Combine all predictors
    # Numerical missing values are median-imputed.
    # Categorical missingness is represented through dummy_na=True.
    full_df = pd.concat(
        [
            num_df.fillna(num_df.median()),
            miss_indicators,
            cat_df
        ],
        axis=1
    )

    results = {}

    # Test each variable containing missing values
    for col in [c for c in df.columns if df[c].isnull().any()]:

        # Target: whether this variable is missing
        y = df[col].isnull().astype(int)

        missing_rate = y.mean()

        # Exclude extremely imbalanced variables
        # because 5-fold CV needs examples of both classes
        if y.sum() < 5 or y.sum() > len(y) - 5:
            continue

        # Remove the target variable and its own missingness indicator
        # to avoid leakage
        drop_cols = (
            [col, f"{col}_NA"]
            + [c for c in full_df.columns if c.startswith(f"{col}_")]
        )

        X = full_df.drop(
            columns=drop_cols,
            errors="ignore"
        )

        clf = RandomForestClassifier(
            n_estimators=100
        )

        # Cross-validated missingness prediction
        proba = cross_val_predict(
            clf,
            X,
            y,
            cv=5,
            method="predict_proba"
        )[:, 1]

        auc = roc_auc_score(
            y,
            proba
        )

        # Fit on full data to obtain feature importance
        clf.fit(X, y)

        top_predictors = (
            pd.Series(
                clf.feature_importances_,
                index=X.columns
            )
            .sort_values(
                ascending=False
            )
            .head(3)
            .index
            .tolist()
        )

        results[col] = {
            "auc": round(float(auc), 4),
            "missing_rate": round(float(missing_rate), 4),
            "top_predictors": top_predictors,
        }

    return results


import pandas as pd
import numpy as np
from collections import Counter
from missingness_tests import mar_mnar_test

def run_repeated(df, n_runs=10):
    all_runs = [mar_mnar_test(df) for _ in range(n_runs)]

    # only keep columns present in every run (handles edge cases where
    # a column's missing count crosses the y.sum()<5 threshold on some runs)
    common_cols = set(all_runs[0].keys())
    for run in all_runs[1:]:
        common_cols &= set(run.keys())

    summary = {}
    for col in sorted(common_cols):
        aucs = [run[col]["auc"] for run in all_runs]
        preds = []
        for run in all_runs:
            preds.extend(run[col]["top_predictors"])

        aucs = np.array(aucs)
        top_freq = [p for p, _ in Counter(preds).most_common(3)]

        summary[col] = {
            "mean_auc": round(float(aucs.mean()), 4),
            "std_auc":  round(float(aucs.std(ddof=1)), 4),
            "min_auc":  round(float(aucs.min()), 4),
            "max_auc":  round(float(aucs.max()), 4),
            "top_predictors": top_freq,
        }

    return summary


if __name__ == "__main__":
    df = pd.read_csv("ckd_with_egfr.csv")
    exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
    df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

    summary = run_repeated(df_features, n_runs=10)

    for col, info in sorted(summary.items(), key=lambda x: -x[1]["mean_auc"]):
        print(f"{col:8} mean_auc={info['mean_auc']:.4f}  "
              f"std={info['std_auc']:.4f}  "
              f"range={info['min_auc']:.4f}-{info['max_auc']:.4f}  "
              f"top_predictors={info['top_predictors']}")