import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from categorical_encoder import CategoricalEncoder
import statsmodels.api as sm
from sklearn.metrics import (
    roc_auc_score, f1_score, recall_score, precision_score,
    brier_score_loss, confusion_matrix,
)
from statsmodels.imputation.mice import MICE, MICEData


def simple_impute(data):
    ''' 
    Simple imputation
    numerical: median
    categorical: most frequent
    '''
    imputed = data.copy()
    num_cols = imputed.select_dtypes(include="number").columns
    cat_cols = imputed.select_dtypes(include=["object", "category"]).columns
    if len(num_cols) > 0:
        num_imputer = SimpleImputer(strategy="median").set_output(transform="pandas")
        imputed[num_cols] = num_imputer.fit_transform(imputed[num_cols])
    if len(cat_cols) > 0:
        cat_imputer = SimpleImputer(strategy="most_frequent").set_output(transform="pandas")
        imputed[cat_cols] = cat_imputer.fit_transform(imputed[cat_cols])
    return imputed


def mice_impute(data, seed=42):
    '''
    Conditional (MAR-consistent) imputation via a single MICEData-completed
    draw, unconditionally -- no MCAR test, always the "mechanism-aware"
    branch. Encoded categorical columns are rounded/clipped back to their
    nearest valid code and decoded to their original labels.
    '''
    np.random.seed(seed)
    encoder = CategoricalEncoder()
    encoded = encoder.fit_transform(data)
    imp = MICEData(encoded)
    imp.update_all()
    completed = imp.data
    completed.index = data.index  # MICEData resets to a fresh RangeIndex internally;
    # realign by position (row order is preserved) so downstream column
    # assignment doesn't silently NaN-fill on label mismatch

    out = pd.DataFrame(index=data.index)
    for col in data.columns:
        info = encoder.columns_.get(col)
        if info is not None and info["type"] == "categorical":
            inverse = {code: category for category, code in info["mapping"].items()}
            n_categories = len(info["mapping"])
            codes = completed[col].round().clip(0, n_categories - 1).astype(int)
            out[col] = codes.map(inverse)
        else:
            out[col] = completed[col]
    return out


def mechanism_impute(data, mcar_alpha=0.05, seed=42):
    '''
    Simplest mechanism-aware imputation: a single global PKLM test
    (Spohn et al. 2025) decides the whole fold's strategy.

    MCAR not rejected (mean p >= mcar_alpha): fall back to simple_impute --
    no mechanism to model, median/mode is unbiased under MCAR.
    MCAR rejected: single MICE-completed draw, see mice_impute().

    Does not attempt an MAR-vs-MNAR distinction -- that split isn't testable
    from observed data alone, so this only ever branches on MCAR vs not.
    '''
    from MCAR_missingness_PKLM import pklm_test  # lazy: needs rpy2 + R PKLMtest

    result = pklm_test(data)
    print(f"  PKLM MCAR test: mean_p={result['mean_p']}, std_p={result['std_p']}")

    if result["mean_p"] >= mcar_alpha:
        print("  -> MCAR not rejected, using simple imputation")
        return simple_impute(data)

    print("  -> MCAR rejected, using MICE imputation")
    return mice_impute(data, seed=seed)


def mice_and_regression(X_train, y_train, X_test, y_test, seed=42, return_proba=False, return_metrics=False):
    np.random.seed(seed)

    fml = "y ~ " + " + ".join(c for c in X_train.columns)
    encoder = CategoricalEncoder()

    train_data = encoder.fit_transform(X_train)
    test_data = encoder.transform(X_test)

    y_train = pd.Categorical(y_train).codes.astype(float)
    train_data["y"] = y_train

    imp = MICEData(train_data)
    mice_model = MICE(fml, sm.GLM, imp, init_kwds={"family": sm.families.Binomial()})
    results = mice_model.fit(10, 20)

    test_imp = MICEData(test_data)
    test_imp.update_all()

    design_test = sm.GLM.from_formula(
        fml.replace("y ~", "y_dummy ~"),
        data=test_imp.data.assign(y_dummy=0)
    ).exog

    linear_predictor = design_test @ results.params
    proba = 1 / (1 + np.exp(-linear_predictor))

    auc = round(roc_auc_score(y_test, proba), 4)

    metrics = None
    if return_metrics:
        y_pred = (proba >= 0.5).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_test, y_pred, labels=[0, 1]).ravel()
        specificity = tn / (tn + fp) if (tn + fp) > 0 else float("nan")
        metrics = {
            "auc": auc,
            "f1": round(f1_score(y_test, y_pred, zero_division=0), 4),
            "sensitivity": round(recall_score(y_test, y_pred, zero_division=0), 4),
            "specificity": round(specificity, 4),
            "precision": round(precision_score(y_test, y_pred, zero_division=0), 4),
            "brier": round(brier_score_loss(y_test, proba), 4),
        }

    if return_proba and return_metrics:
        return auc, proba, metrics
    if return_metrics:
        return auc, metrics
    if return_proba:
        return auc, proba
    return auc