"""Anonymeter singling-out privacy test on the real R/S1/S2 fold loop,
using the same data prep and synthesis as evaluate_ckd_missingness_strategies_full.py.
No repeats, no subgroups -- just risk, attack_rate, baseline_rate, control_rate
per fold, straight from anonymeter's own PrivacyRisk/EvaluationResults objects.

Fixed output format (always, every run): a per-fold table, a pooled
mean/std/min/max table per branch, and a CSV (privacy_test_fold_results_
<dataset_name>.csv) with the same per-fold rows for later re-slicing.
"""

import csv

import numpy as np
from sklearn.model_selection import StratifiedKFold
from anonymeter.evaluators import SinglingOutEvaluator

from dataset_registry import DATASET_REGISTRY
from imputation import simple_impute
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
from Missingness_Model import MissingnessModel

# ----------------------------------------------------------------------
# 1. Load the dataset
# ----------------------------------------------------------------------
dataset_name = "ckd"
config = DATASET_REGISTRY[dataset_name]
df = config["loader"]()
n_splits = config["n_splits"]
positive_label = config["positive_label"]
categorical_cols = config["categorical_cols"]
min_support = config["min_support"]
min_any_confidence = config["min_any_confidence"]

X = df.drop(columns=["class"])
y = df["class"]

for c in categorical_cols:
    if c in X.columns:
        X[c] = X[c].astype("object")

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
print(f"\nNumber of folds: {skf.get_n_splits()}")

# ----------------------------------------------------------------------
# 2. Fold loop
# ----------------------------------------------------------------------
METRIC_NAMES = ["risk", "attack_rate", "baseline_rate", "control_rate"]
fold_records = []  # one row per (fold, branch) -- the table this script always reports
example_queries = {"S1": [], "S2": []}

for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
    print(f"\nFold {fold_num + 1} in progress.")
    X_train = X.iloc[train_index].copy()
    X_test = X.iloc[test_index].copy()

    y_train = (y.iloc[train_index] == positive_label).astype(int)
    y_test = (y.iloc[test_index] == positive_label).astype(int)

    X_train_filled = simple_impute(X_train)

    # Branch S1
    shadow_cols = build_shadow_columns(X_train)
    synth_features_with_shadows, synth_label_s1 = synthesize(
        X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols
    )
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)

    # Branch S2
    mining_model = MissingnessModel().fit(X_train, min_support=min_support, min_any_confidence=min_any_confidence)
    s2_features, synth_label_s2 = run_s2_branch(X_train, X_train_filled, y_train, categorical_cols, mining_model)

    for branch, syn_features in [("S1", s1_features), ("S2", s2_features)]:
        n_attacks = min(500, len(X_train))
        evaluator = SinglingOutEvaluator(ori=X_train, syn=syn_features, control=X_test, n_attacks=n_attacks)
        try:
            evaluator.evaluate(mode="multivariate")
        except RuntimeError as ex:
            print(f"  {branch}: failed ({ex}), skipping this fold")
            continue

        risk = evaluator.risk()
        res = evaluator.results()
        fold_records.append({
            "fold": fold_num + 1, "branch": branch,
            "risk": risk.value, "ci_low": risk.ci[0], "ci_high": risk.ci[1],
            "attack_rate": res.attack_rate.value, "attack_err": res.attack_rate.error,
            "baseline_rate": res.baseline_rate.value, "baseline_err": res.baseline_rate.error,
            "control_rate": res.control_rate.value, "control_err": res.control_rate.error,
        })
        print(f"  {branch}: risk={risk.value:.4f}, "
              f"attack_rate={res.attack_rate.value:.3f}, "
              f"baseline_rate={res.baseline_rate.value:.3f}, "
              f"control_rate={res.control_rate.value:.3f}")
        if fold_num == 0:
            example_queries[branch] = evaluator.queries()[:5]

# ----------------------------------------------------------------------
# 3. Reporting -- this is the fixed output format: a per-fold table (risk +
# its CI, attack/baseline/control rates + their error bounds, straight from
# anonymeter's own PrivacyRisk/EvaluationResults objects, nothing derived),
# a pooled mean/std/min/max table per branch, and a CSV with the same rows
# for anything that needs re-plotting/re-slicing later without re-running.
# NOTE: anonymeter's rng is unseeded -- rerunning this script will NOT
# reproduce these exact numbers, only the same qualitative pattern.
# ----------------------------------------------------------------------
CSV_PATH = f"privacy_test_fold_results_{dataset_name}.csv"
with open(CSV_PATH, "w", newline="") as f:
    fieldnames = ["fold", "branch", "risk", "ci_low", "ci_high",
                  "attack_rate", "attack_err", "baseline_rate", "baseline_err",
                  "control_rate", "control_err"]
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(fold_records)
print(f"\n(per-fold results written to {CSV_PATH})")

print(f"\n{'Fold':<5}{'Branch':<7}{'risk':>8}  {'CI':>17}  {'attack_rate':>15}  {'baseline_rate':>17}  {'control_rate':>16}")
for r in fold_records:
    ci = f"({r['ci_low']:.4f}, {r['ci_high']:.4f})"
    attack = f"{r['attack_rate']:.3f} ± {r['attack_err']:.3f}"
    baseline = f"{r['baseline_rate']:.3f} ± {r['baseline_err']:.3f}"
    control = f"{r['control_rate']:.3f} ± {r['control_err']:.3f}"
    print(f"{r['fold']:<5}{r['branch']:<7}{r['risk']:>8.4f}  {ci:>17}  {attack:>15}  {baseline:>17}  {control:>16}")

print(f"\n{'Branch':<7}{'Metric':<15}{'mean':>8}{'std':>9}{'min':>9}{'max':>9}")
for branch in ["S1", "S2"]:
    branch_rows = [r for r in fold_records if r["branch"] == branch]
    for m in METRIC_NAMES:
        vals = np.array([r[m] for r in branch_rows])
        print(f"{branch:<7}{m:<15}{vals.mean():>8.4f}{vals.std():>9.4f}{vals.min():>9.4f}{vals.max():>9.4f}")