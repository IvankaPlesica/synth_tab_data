from itertools import combinations

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, export_text
import joblib


from categorical_encoder import CategoricalEncoder
from dataset_registry import DATASET_REGISTRY

K = 2  # fixed cluster count

config = DATASET_REGISTRY["hepatitis"]
cat_cols = config["categorical_cols"]

real_df = config["loader"]()
#real_df = real_df[real_df["class"] == "ckd"].reset_index(drop=True) # restrict to CKD-positive only, so clusters reflect severity/phenotype 
                                                                    # within the disease instead of just re-deriving the diagnosis boundary
real = real_df.drop(columns=["class"])
real[cat_cols] = real[cat_cols].astype("object")  # mark these as categorical per dataset_registry.py's labeling
num_cols = [c for c in real.columns if c not in cat_cols]

medians = real[num_cols].median()  # fill values learned from REAL data only, reused below for synthetic too
modes = real[cat_cols].mode().iloc[0]


def prep(df):  # impute using real-data stats only -- keeps real and synthetic in the same reference frame
    out = df.copy()
    out[num_cols] = out[num_cols].fillna(medians)
    out[cat_cols] = out[cat_cols].fillna(modes)
    return out


# Step 1: cluster real patient data into subgroups.
imputed = prep(real)
encoder = CategoricalEncoder().fit(imputed)          # turn category columns into integer codes
encoded = encoder.transform(imputed)
scaler = StandardScaler().fit(encoded)               # put every feature on a comparable scale for KMeans
scaled = scaler.transform(encoded)
kmeans = KMeans(n_clusters=K, n_init=10, random_state=42).fit(scaled)
cluster_labels = kmeans.labels_
print(f"Cluster sizes: {pd.Series(cluster_labels).value_counts().sort_index().to_dict()}")
print(f"Silhouette score: {silhouette_score(scaled, cluster_labels):.3f}")  # cluster separation/cohesion,
# reported as a quality descriptor only -- K is fixed above, not chosen by this score

# Step 1b: check this isn't just an artifact of one random seed -- refit with 10 different
# seeds and see how often they agree (Adjusted Rand Index: 1.0 = identical, 0.0 = random chance).
seed_runs = [KMeans(n_clusters=K, n_init=10, random_state=s).fit_predict(scaled) for s in range(10)]
seed_aris = [adjusted_rand_score(a, b) for a, b in combinations(seed_runs, 2)]
print(f"Seed stability (10 seeds): mean ARI={sum(seed_aris) / len(seed_aris):.3f}")

# Step 1c: describe each cluster -- mean +/- SD for numeric columns, most-common value (and its
# share) for categorical columns. Computed on RAW (non-imputed) values so missing data isn't
# silently counted as an observed value.
summary = {}
for c in sorted(set(cluster_labels)):
    mask = cluster_labels == c
    col_stats = {}
    for col in num_cols:
        vals = real.loc[mask, col]
        col_stats[col] = f"{vals.mean():.2f} +/- {vals.std():.2f}"
    for col in cat_cols:
        vals = real.loc[mask, col].dropna()
        if len(vals):
            mode = vals.mode().iloc[0]
            col_stats[col] = f"{mode} ({(vals == mode).mean():.0%})"
    summary[f"cluster {c} (n={int(mask.sum())})"] = col_stats
print("\nCluster characterization:")
print(pd.DataFrame(summary).to_string())

# Step 2: explain the clusters with a small decision tree. Clustering above needed the IMPUTED data
# (KMeans can't handle NaN), but the tree doesn't -- fit it on the RAW (non-imputed) data instead, so
# sklearn's native NaN-routing can use missingness itself as a split signal, not just filled-in values.
sparse_encoded = encoder.transform(real)  # same encoder as above, but on real (unfilled) data -- NaNs stay NaN
tree = DecisionTreeClassifier(max_depth=3, random_state=42).fit(sparse_encoded, cluster_labels)
print("\nCluster explanation (decision tree rules):")
print(export_text(tree, feature_names=list(sparse_encoded.columns)))
print(f"Decision tree reproduces {tree.score(sparse_encoded, cluster_labels):.1%} of cluster assignments")



# Step 1d: find outliers -- patients who don't fit cleanly into either
# side of the CKD/notCKD split found above. Distance to own cluster's
# centroid, threshold set per cluster (not globally), since the two
# clusters can have different typical spreads.
import numpy as np

distances = np.linalg.norm(scaled - kmeans.cluster_centers_[cluster_labels], axis=1)
threshold_std = 2.0

outlier_mask = np.zeros(len(scaled), dtype=bool)
cluster_cutoffs = {}
for c in sorted(set(cluster_labels)):
    mask = cluster_labels == c
    d = distances[mask]
    cutoff = d.mean() + threshold_std * d.std()
    cluster_cutoffs[c] = cutoff
    outlier_mask[mask] = d > cutoff

print(f"\nFlagged {outlier_mask.sum()} outliers out of {len(scaled)}")
print("Outliers by original cluster:")
print(pd.Series(cluster_labels[outlier_mask]).value_counts().sort_index())

# if class is still available in real_df (dropped from `real` for clustering,
# but real_df still has it), check what the outliers actually are diagnosis-wise --
# this directly tests whether they're the "ambiguous/borderline" patients
if "class" in real_df.columns:
    print("\nOutliers by actual class label:")
    print(real_df.loc[outlier_mask, "class"].value_counts())

outlier_summary = {}
for col in num_cols:
    vals = real.loc[outlier_mask, col]
    outlier_summary[col] = f"{vals.mean():.2f} +/- {vals.std():.2f}"
for col in cat_cols:
    vals = real.loc[outlier_mask, col].dropna()
    if len(vals):
        mode = vals.mode().iloc[0]
        outlier_summary[col] = f"{mode} ({(vals == mode).mean():.0%})"
print("\nOutlier characterization:")
print(pd.Series(outlier_summary))


# Step: define the outlier subgroup as an explicit rule (fit on real data),
# then apply that SAME rule to filter S1 and S2 directly -- no re-clustering.



# fit a tree that predicts "is this row an outlier" using the raw (unimputed) features
outlier_tree = DecisionTreeClassifier(max_depth=3, random_state=42)
outlier_tree.fit(sparse_encoded, outlier_mask.astype(int))
print("\nOutlier-defining rule (fit on real data):")
print(export_text(outlier_tree, feature_names=list(sparse_encoded.columns)))
print(f"Rule reproduces {outlier_tree.score(sparse_encoded, outlier_mask.astype(int)):.1%} of the outlier flags")

joblib.dump(
    {
        "outlier_tree": outlier_tree,   # portable approximation (97.2% fidelity) -- for scoring
        "encoder": encoder,             # rows that were never clustered, e.g. synthetic S1/S2 data
        "cat_cols": cat_cols,
        "kmeans": kmeans,               # exact distance-based rule -- for scoring real data,
        "scaler": scaler,               # which can go through the same encoder/scaler/kmeans
        "medians": medians,             # pipeline it was fit with (no approximation loss)
        "modes": modes,
        "num_cols": num_cols,
        "cluster_cutoffs": cluster_cutoffs,
    },
    "outlier_rule.joblib",
)
print("Saved outlier_rule.joblib")


def apply_outlier_rule(df):
    df = df.drop(columns=["class"], errors="ignore").copy()
    df[cat_cols] = df[cat_cols].astype("object")
    encoded = encoder.transform(df)  # <-- df still has NaNs here, was never imputed
    predicted = outlier_tree.predict(encoded)
    return predicted.astype(bool)


for variant in ["s1", "s2"]:
    synth_df = pd.read_csv(f"ckd_synthetic_{variant}.csv")
    synth_outlier_mask = apply_outlier_rule(synth_df)
    print(f"\n{variant.upper()}: {synth_outlier_mask.sum()} rows match the real-defined outlier rule "
          f"out of {len(synth_df)}")
    if "class" in synth_df.columns:
        print(synth_df.loc[synth_outlier_mask, "class"].value_counts())

'''
# Step 3: do the same subgroups show up in synthetic data?
# (a) Transfer: route synthetic rows through the SAME imputer/encoder/scaler/KMeans fit on real data
#     above (never refit), then compare cluster proportions to real.
# (b) Independent refit: cluster synthetic data completely from scratch (its own imputation values,
#     its own encoder, its own scaler, its own KMeans fit -- as if real data was never seen), then
#     compare to (a) via Adjusted Rand Index. ARI doesn't care which cluster is numbered 0 vs. 1, so
#     no label-matching step is needed. High ARI means the same subgroups re-emerge from synthetic
#     data on their own, not just because they were forced through real's cluster centroids.
real_prop = pd.Series(cluster_labels).value_counts(normalize=True).sort_index()
print(f"\nReal cluster proportions:      {real_prop.round(3).to_dict()}")
for variant in ["s1", "s2"]:
    synth_df = pd.read_csv(f"ckd_synthetic_{variant}.csv")
    synth_df = synth_df[synth_df["class"] == "ckd"].reset_index(drop=True)
    synth = synth_df.drop(columns=["class"])
    synth[cat_cols] = synth[cat_cols].astype("object")

    transfer_scaled = scaler.transform(encoder.transform(prep(synth)))
    transfer_labels = kmeans.predict(transfer_scaled)
    transfer_prop = pd.Series(transfer_labels).value_counts(normalize=True).sort_index()

    synth_imputed = synth.copy()
    synth_imputed[num_cols] = synth[num_cols].fillna(synth[num_cols].median())
    synth_imputed[cat_cols] = synth[cat_cols].fillna(synth[cat_cols].mode().iloc[0])
    synth_encoded = CategoricalEncoder().fit_transform(synth_imputed)
    synth_scaled = StandardScaler().fit_transform(synth_encoded)
    independent_labels = KMeans(n_clusters=K, n_init=10, random_state=42).fit_predict(synth_scaled)
    ari = adjusted_rand_score(transfer_labels, independent_labels)

    print(f"{variant.upper()} cluster proportions (n={len(synth)}): {transfer_prop.round(3).to_dict()}"
          f"  |  independent-refit ARI={ari:.3f}")
'''