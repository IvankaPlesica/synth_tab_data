"""RQ2 skeleton, S2 blocks now MINED fresh from training data instead of hard-coded."""

import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.imputation.mice import MICEData, MICE
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

from load_ckd import load_ckd
from egfr_staging import add_egfr_columns
from Missingness_Model import MissingnessModel

from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    infer_types,
    coerce_discrete_to_category,
    coerce_continuous_to_float,
    rename_categorical_categories_to_str,
)

# ============================================================
# 1. LOAD DATA
# ============================================================
df = load_ckd() 
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
df["class"] = df["class"].str.strip()

exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

# ============================================================
# 2. SPLIT (stratified)
# ============================================================
y_all = (df["class"] == "ckd").astype(int)
train_idx, test_idx = train_test_split(
    df.index, test_size=0.2, random_state=42, stratify=y_all
)

train_df = df.loc[train_idx].reset_index(drop=True)
test_df = df.loc[test_idx].reset_index(drop=True)

train_features = train_df[df_features.columns]
test_features = test_df[df_features.columns]
train_y = (train_df["class"] == "ckd").astype(int)
test_y = (test_df["class"] == "ckd").astype(int)


# ============================================================
# 3. MINE BLOCKS FROM TRAINING DATA (not hard-coded)
# ============================================================
MIN_SUPPORT = 0.1
MIN_ANY_CONFIDENCE = 0.7

mining_model = MissingnessModel().fit(
    train_features, min_support=MIN_SUPPORT, min_any_confidence=MIN_ANY_CONFIDENCE
)

def extract_blocks_from_model(model):
    for attr in ["relevant_blocks", "blocks", "found_blocks", "rules"]:
        if hasattr(model, attr):
            val = getattr(model, attr)
            if val:
                blocks = []
                for item in val:
                    if isinstance(item, dict) and "itemset" in item:
                        blocks.append(list(item["itemset"]))
                    elif hasattr(item, "itemset"):
                        blocks.append(list(item.itemset))
                    elif isinstance(item, (list, tuple, set)):
                        blocks.append(list(item))
                if blocks:
                    return blocks

    print("\n!!! Could not auto-find blocks. Available attributes:")
    for attr in dir(model):
        if not attr.startswith("_"):
            print(f"  {attr}")
    raise AttributeError("Update extract_blocks_from_model().")

KNOWN_BLOCKS = extract_blocks_from_model(mining_model)

print(f"\nMined {len(KNOWN_BLOCKS)} blocks at min_support={MIN_SUPPORT}, "
      f"min_any_confidence={MIN_ANY_CONFIDENCE}:")
for block in KNOWN_BLOCKS:
    print(f"  {block}")

# ============================================================
# 4. SHARED SCORING FUNCTION -- MICE-pooled (statsmodels)
# ============================================================
def score_branch_mice(X_train, y_train, X_test, y_test, n_imputations=20):
    train_full = X_train.copy()
    train_full["y"] = y_train.values

    cat_cols = train_full.select_dtypes(include=["object", "category"]).columns.tolist()
    for c in cat_cols:
        train_full[c] = train_full[c].astype("category")
        train_full[c] = train_full[c].cat.codes.replace(-1, np.nan)

    imp_data = MICEData(train_full)

    feature_cols = [c for c in train_full.columns if c != "y"]
    formula_terms = [f"C({c})" if c in cat_cols else c for c in feature_cols]
    formula = "y ~ " + " + ".join(formula_terms)

    mice_model = MICE(formula, sm.GLM, imp_data,
                       init_kwds={"family": sm.families.Binomial()})
    mice_result = mice_model.fit(n_imputations=n_imputations)

    test_full = X_test.copy()
    for c in cat_cols:
        if c in test_full.columns:
            test_full[c] = test_full[c].astype("category")
            test_full[c] = test_full[c].cat.codes.replace(-1, np.nan)

    test_imp_data = MICEData(test_full)
    test_imp_data.update_all()
    test_completed = test_imp_data.data

    design_test = sm.GLM.from_formula(formula.replace("y ~", "y_dummy ~"),
                                       data=test_completed.assign(y_dummy=0)).exog
    proba = 1 / (1 + np.exp(-design_test @ mice_result.params))

    return round(roc_auc_score(y_test, proba), 4)

# ============================================================
# 5. BRANCH R -- baseline
# ============================================================
score_r = score_branch_mice(train_features, train_y, test_features, test_y)
print(f"\nScore R (baseline, MICE-pooled): {score_r}")

# ============================================================
# 6. SHADOW PATTERNS: deterministic core (from MINED blocks) + conditional residual
# ============================================================
def assign_block_only_patterns(df_features, known_blocks):
    def pattern_name(row):
        present_blocks = []
        for block in known_blocks:
            if row[block].all():
                present_blocks.append("+".join(block))
        return " & ".join(present_blocks) if present_blocks else "mp0"
    missing_mask = df_features.isnull()
    return missing_mask.apply(pattern_name, axis=1)

def derive_pattern_definitions_and_conditional_rates(
    real_train_features, real_patterns, deterministic_threshold=0.9
):
    pattern_definitions = {}
    conditional_rates = {}
    for label in real_patterns.unique():
        rows_with_label = real_train_features[real_patterns == label]
        miss_rate = rows_with_label.isnull().mean()
        deterministic_cols = miss_rate[miss_rate > deterministic_threshold].index.tolist()
        pattern_definitions[label] = deterministic_cols
        conditional_rates[label] = miss_rate.drop(index=deterministic_cols).to_dict()
    return pattern_definitions, conditional_rates

train_df["missingness_pattern"] = assign_block_only_patterns(train_features, KNOWN_BLOCKS)

pattern_definitions, conditional_rates = derive_pattern_definitions_and_conditional_rates(
    train_features, train_df["missingness_pattern"], deterministic_threshold=0.9
)

print("\nPattern definitions (deterministic core):")
for label, cols in pattern_definitions.items():
    print(f"  {label}: {cols}")

# ============================================================
# 7. SYNTHESIZE -- PyBNesian (simple median/mode pre-fill)
# ============================================================
bn_input_cols = [
    c for c in train_df.columns
    if c not in ("egfr_star", "ckd_stage", "ckd_stage_cat")
]
train_bn_input = train_df[bn_input_cols]

train_bn_filled = train_bn_input.fillna(train_bn_input.median(numeric_only=True))
for col in train_bn_filled.select_dtypes(include="object").columns:
    mode_vals = train_bn_filled[col].mode()
    if not mode_vals.empty:
        train_bn_filled[col] = train_bn_filled[col].fillna(mode_vals.iloc[0])

working = train_bn_filled.copy()
disc_cols, cont_cols = infer_types(working)
working = coerce_discrete_to_category(working, disc_cols)
working = rename_categorical_categories_to_str(working, disc_cols)
working = coerce_continuous_to_float(working, cont_cols)

bn_art = learn_bn(working, bn_type="clg", random_state=42, arc_blacklist=[])
synth = bn_art.model.sample(len(working), seed=42)
synth_df = synth.to_pandas().reindex(columns=working.columns)
for c in disc_cols:
    if c in synth_df.columns:
        synth_df[c] = synth_df[c].astype("category")

synth_label = (synth_df["class"].astype(str) == "ckd").astype(int)
synth_pattern_labels = synth_df["missingness_pattern"].astype(str)
synth_features = synth_df.drop(columns=["class", "missingness_pattern"])

synth_df.to_csv("rq2_synthetic_raw.csv", index=False)

# ============================================================
# 8. BRANCH S1 -- shadow COLUMNS, 1:1 transplant
# ============================================================
def reinsert_shadow_columns_1to1(synth_features, real_train_features):
    out = synth_features.copy().reset_index(drop=True)
    real_reset = real_train_features.reset_index(drop=True)
    n = min(len(out), len(real_reset))
    for col in real_reset.columns:
        if col not in out.columns:
            continue
        mask = real_reset[col].isnull().iloc[:n]
        out.loc[mask[mask].index, col] = np.nan
    return out

s1_features = reinsert_shadow_columns_1to1(synth_features, train_features)
score_s1 = score_branch_mice(s1_features, synth_label, test_features, test_y)
print(f"Score S1 (shadow columns, 1:1, MICE-pooled): {score_s1}")

# ============================================================
# 9. BRANCH S2 -- deterministic core (mined blocks) + conditional residual
# ============================================================
def reinsert_with_residual_resampling(
    synth_features, synth_pattern_labels, pattern_definitions,
    conditional_rates, seed=42
):
    rng = np.random.default_rng(seed)
    out = synth_features.copy()
    for i, label in enumerate(synth_pattern_labels):
        core_cols = pattern_definitions.get(label, [])
        for col in core_cols:
            if col in out.columns:
                out.iloc[i, out.columns.get_loc(col)] = np.nan
        residual = conditional_rates.get(label, {})
        for col, rate in residual.items():
            if col not in out.columns or rate <= 0:
                continue
            if rng.random() < rate:
                out.iloc[i, out.columns.get_loc(col)] = np.nan
    return out

s2_features = reinsert_with_residual_resampling(
    synth_features, synth_pattern_labels, pattern_definitions,
    conditional_rates, seed=42
)
score_s2 = score_branch_mice(s2_features, synth_label, test_features, test_y)
print(f"Score S2 (mined-block patterns, deterministic + residual): {score_s2}")

# ============================================================
# SAVE
# ============================================================
s1_with_label = s1_features.copy()
s1_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s1_with_label.to_csv("rq2_synthetic_s1.csv", index=False)

s2_with_label = s2_features.copy()
s2_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s2_with_label.to_csv("rq2_synthetic_s2.csv", index=False)

print("\n--- RQ2 results (mined blocks, MICE-pooled) ---")
print(f"Score R : {score_r}")
print(f"Score S1: {score_s1}")
print(f"Score S2: {score_s2}")