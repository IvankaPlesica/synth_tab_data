"""Subgroup fairness metric following Ling et al. (PLOS One 2024, PMC10843030):
compare the TPR gap between two groups for models trained on real (R) vs.
synthetic (S1/S2) data, instead of raw TSTR degradation (which failed earlier
for CKD-only subgroups since `class` was constant within them).

Mapping to this project:
- protected attribute -> outlier flag (the rule fit on real data in
  simple_subgroups.py: outlier_tree/encoder/apply_outlier_rule, reused as-is,
  not refit here).
- class (varies within both groups) -> our `class` (ckd vs notckd), using the
  FULL population -- NOT the CKD-positive-only restriction used elsewhere,
  since class must vary for TPR to be defined.
- privileged/minority TPR gap -> non-outlier vs. outlier TPR gap for
  predicting class.

Outlier flagging only ever happens on real X_test: the rule was fit on real
data, and this tests real-world generalization of R/S1/S2 models, not
synthetic self-consistency.

Reuses mice_and_regression/simple_impute (imputation.py), build_shadow_columns/
reinsert_from_shadow_columns (shadow_columns.py), synthesize (synthesis.py),
run_s2_branch (pattern_missingness.py), MissingnessModel (Missingness_Model.py),
and outlier_tree/encoder/apply_outlier_rule (simple_subgroups.py) unmodified.
Importing simple_subgroups re-runs its (unguarded) top-level script body as a
side effect -- its prints will show up here too.
"""

import warnings

import numpy as np
from sklearn.model_selection import StratifiedKFold
from statsmodels.genmod.generalized_linear_model import PerfectSeparationWarning

from Missingness_Model import MissingnessModel
from dataset_registry import DATASET_REGISTRY
from imputation import mice_and_regression, simple_impute
from pattern_missingness import run_s2_branch
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from simple_subgroups import apply_outlier_rule
from synthesis import synthesize

warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=PerfectSeparationWarning)


def group_tpr(y_true, y_pred, group_mask, positive_label=1):
    """TPR for `class` restricted to rows where group_mask is True.
    None if there are zero actual positives in that subset (TPR undefined)."""
    y_true_g = np.asarray(y_true)[group_mask]
    y_pred_g = np.asarray(y_pred)[group_mask]
    actual_positive = y_true_g == positive_label
    n_pos = int(actual_positive.sum())
    if n_pos == 0:
        return None
    tp = int(((y_pred_g == positive_label) & actual_positive).sum())
    return tp / n_pos


def tpr_gap(y_true, y_pred, outlier_mask):
    """(tpr_outlier, tpr_non_outlier, gap, reason). gap/either TPR can be
    None if undefined; reason explains which and why."""
    tpr_outlier = group_tpr(y_true, y_pred, outlier_mask)
    tpr_non_outlier = group_tpr(y_true, y_pred, ~outlier_mask)
    if tpr_outlier is None or tpr_non_outlier is None:
        missing = []
        if tpr_outlier is None:
            missing.append("no actual positives among outliers")
        if tpr_non_outlier is None:
            missing.append("no actual positives among non-outliers")
        return tpr_outlier, tpr_non_outlier, None, "; ".join(missing)
    return tpr_outlier, tpr_non_outlier, tpr_non_outlier - tpr_outlier, None


if __name__ == "__main__":
    config = DATASET_REGISTRY["ckd"]
    categorical_cols = config["categorical_cols"]
    min_support = config["min_support"]
    min_any_confidence = config["min_any_confidence"]
    positive_label = config["positive_label"]

    df = config["loader"]()
    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    skf = StratifiedKFold(n_splits=config["n_splits"], shuffle=True, random_state=42)
    train_index, test_index = next(skf.split(X, y))  # single fold, first pass

    X_train = X.iloc[train_index].copy()
    X_test = X.iloc[test_index].copy()
    y_train = (y.iloc[train_index] == positive_label).astype(int)
    y_test = (y.iloc[test_index] == positive_label).astype(int)

    outlier_mask_test = apply_outlier_rule(X_test)
    n_outliers = int(outlier_mask_test.sum())
    print(f"\nReal test fold: {len(X_test)} rows, {n_outliers} flagged outliers, "
          f"{len(X_test) - n_outliers} non-outliers")
    if n_outliers < 10:
        print(f"WARNING: only {n_outliers} outliers in this test fold -- "
              "TPR estimates for the outlier group are small-n and may be noisy.")

    branches = {}

    # Branch R: baseline
    auc_r, proba_r = mice_and_regression(X_train, y_train, X_test, y_test, return_proba=True)
    branches["R"] = (proba_r >= 0.5).astype(int)

    # Shared: simple-impute train, reused by both S1 and S2
    X_train_filled = simple_impute(X_train)

    # Branch S1: shadow-column synthesis, evaluated against real X_test
    shadow_cols = build_shadow_columns(X_train)
    synth_features_with_shadows, synth_label_s1 = synthesize(
        X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols
    )
    s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)
    auc_s1, proba_s1 = mice_and_regression(
        s1_features, synth_label_s1, X_test, y_test, return_proba=True
    )
    branches["S1"] = (proba_s1 >= 0.5).astype(int)

    # Branch S2: mined missingness-block synthesis, evaluated against real X_test.
    # Commented out for now -- on this fold, PyBNesian's native CLG fitting segfaults
    # (uncatchable in Python) because several class=0 x missingness-pattern cells are
    # near-empty (e.g. one pattern has only 2 class=0 rows, three multi-block patterns
    # have 0), producing a rank-deficient/ill-conditioned conditional Gaussian factor.
    # mining_model = MissingnessModel().fit(
    #     X_train, min_support=min_support, min_any_confidence=min_any_confidence
    # )
    # s2_features, synth_label_s2 = run_s2_branch(
    #     X_train, X_train_filled, y_train, categorical_cols, mining_model
    # )
    # auc_s2, proba_s2 = mice_and_regression(
    #     s2_features, synth_label_s2, X_test, y_test, return_proba=True
    # )
    # branches["S2"] = (proba_s2 >= 0.5).astype(int)

    print(f"\n{'branch':<8}{'tpr_outlier':<14}{'tpr_non_outlier':<18}{'gap':<10}{'gap - R gap':<14}note")
    r_gap = None
    for name, y_pred in branches.items():
        tpr_out, tpr_non, gap, reason = tpr_gap(y_test, y_pred, outlier_mask_test)
        if name == "R":
            r_gap = gap
        delta = f"{gap - r_gap:+.3f}" if (gap is not None and r_gap is not None) else "n/a"
        note = reason or ""
        fmt = lambda v: f"{v:.3f}" if v is not None else "None"
        print(f"{name:<8}{fmt(tpr_out):<14}{fmt(tpr_non):<18}{fmt(gap):<10}{delta:<14}{note}")
        if name != "R" and gap is not None and r_gap is not None:
            direction = "widens" if gap > r_gap else "narrows" if gap < r_gap else "matches"
            print(f"  {name} {direction} the real-data disparity "
                  f"({name} gap - R gap = {gap - r_gap:+.3f})")
