"""Cluster tabular data into subgroups and explain them with a missing-value-
aware decision tree. Single reusable module -- import these functions from
elsewhere in the pipeline instead of hunting through the other analysis
scripts in this directory.

Public API:
    fit_subgroups(df, categorical_cols, ...) -> SubgroupModel
        Cluster df's rows (KMeans, k picked by silhouette unless given) and
        fit a NaN-native decision tree that explains the clusters straight
        from df's RAW (unimputed) features -- no shadow columns needed,
        scikit-learn's tree splitters route missing values natively (this
        needs sklearn >= 1.3; confirmed working on sklearn 1.8 in this repo).
    assign_subgroups(model, new_df) -> np.ndarray
        Assign new_df's rows (e.g. synthetic data) to the nearest fitted
        cluster centroid, using the same imputer/scaler/encoder fit on the
        original data.
    check_persistence(model, new_df) -> dict
        Does the cluster structure found in df still hold in new_df? Compares
        transfer-assignment against an independent KMeans refit on new_df
        (clusters matched back to the original via Hungarian centroid
        matching). High agreement means the same subgroups re-emerge from
        new_df on their own, not just as an artifact of forced projection.
    test_cluster_outcome(model, outcome) -> dict
        Clusters are found without looking at any outcome. This answers the
        separate question of whether the resulting clusters differ on a
        distal outcome they never saw -- an omnibus test (ANOVA or
        chi-square) plus an effect size, following the validation logic in
        Gloster et al. (2024, Cognitive Therapy and Research): cluster
        first, test against the outcome second, and report an effect size
        rather than leaning on p-values alone since subgroup sizes here are
        often small and underpowered.
    test_cluster_outcomes_report(model, df, dataset_name) -> dict
        Runs test_cluster_outcome for the outcome columns this repo already
        considers clinically relevant for a given dataset (CKD stage + class
        for CKD, ALBI grade + class for hepatitis).

Example:
    model = fit_subgroups(real_df, categorical_cols, exclude_cols=["class"])
    print(model.rules_text)
    persistence = check_persistence(model, synth_df)
"""

import itertools
from collections import Counter
from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, export_text

RANDOM_STATE = 42
K_RANGE = range(2, 9)


# ---------------------------------------------------------------------------
# Encoding
# ---------------------------------------------------------------------------

def _make_ohe(**kwargs):
    from sklearn.preprocessing import OneHotEncoder
    try:
        return OneHotEncoder(**kwargs, sparse_output=False)
    except TypeError:
        return OneHotEncoder(**kwargs, sparse=False)


def _split_cols(df, categorical_cols):
    cat_cols = [c for c in categorical_cols if c in df.columns]
    num_cols = [c for c in df.columns if c not in cat_cols]
    return num_cols, cat_cols


def _fit_encoder(df, num_cols, cat_cols):
    """Median/mode-imputed, scaled/one-hot encoder for the CLUSTERING step
    only -- KMeans itself can't take NaNs. The explanation tree below uses
    the raw, unimputed data instead."""
    transformers = []
    if num_cols:
        transformers.append(("num", Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("scl", StandardScaler()),
        ]), num_cols))
    if cat_cols:
        transformers.append(("cat", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")),
            ("ohe", _make_ohe(handle_unknown="ignore")),
        ]), cat_cols))
    return ColumnTransformer(transformers, remainder="drop").fit(df)


def _encode_for_tree(df, num_cols, cat_cols):
    """NaN-passthrough encoding for the explanation tree: numeric columns
    pass through as-is; each categorical value becomes a 0/1 indicator
    column that stays NaN for rows where the source value is missing (not a
    separate 'missing' category), so the tree's native NaN routing decides
    where missing rows go at each split -- exactly like a numeric column."""
    parts, names = [], []
    for c in num_cols:
        vals = pd.to_numeric(df[c], errors="coerce")
        parts.append(vals.to_numpy().reshape(-1, 1))
        names.append(c)
    for c in cat_cols:
        s = df[c]
        cats = sorted(s.dropna().astype(str).unique())
        for cat in cats:
            ind = np.where(s.isna(), np.nan, (s.astype(str) == cat).astype(float))
            parts.append(ind.reshape(-1, 1))
            names.append(f"{c}={cat}")
    X = np.hstack(parts) if parts else np.empty((len(df), 0))
    return X, names


def _pick_k(Z, k_range, random_state):
    best_k, best_score = None, -1.0
    for k in k_range:
        if k >= len(Z):
            break
        labels = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit_predict(Z)
        if len(set(labels)) < 2:
            continue
        score = silhouette_score(Z, labels)
        if score > best_score:
            best_k, best_score = k, score
    return best_k, best_score


def _match_clusters(centroids_a, centroids_b):
    """Hungarian-match cluster b -> cluster a by centroid distance. Returns
    {b_cluster_id: a_cluster_id}."""
    n = max(len(centroids_a), len(centroids_b))
    cost = np.full((n, n), 1e6)
    for i in range(len(centroids_b)):
        for j in range(len(centroids_a)):
            cost[i, j] = np.linalg.norm(centroids_b[i] - centroids_a[j])
    row_ind, col_ind = linear_sum_assignment(cost)
    return {int(r): int(c) for r, c in zip(row_ind, col_ind) if r < len(centroids_b)}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

@dataclass
class SubgroupModel:
    """Fitted clustering + explanation model. Reuse via assign_subgroups /
    check_persistence to test whether the same subgroups hold in other data
    (e.g. synthetic vs. real)."""

    df: pd.DataFrame
    num_cols: List[str]
    cat_cols: List[str]
    encoder: ColumnTransformer
    kmeans: KMeans
    k: int
    silhouette: float
    cluster_labels: np.ndarray
    sizes: dict
    tree: DecisionTreeClassifier
    tree_feature_names: List[str]
    tree_train_accuracy: float
    rules_text: str
    random_state: int = RANDOM_STATE


def fit_subgroups(
    df: pd.DataFrame,
    categorical_cols: List[str],
    exclude_cols: Optional[List[str]] = None,
    k: Optional[int] = None,
    k_range=K_RANGE,
    max_depth: int = 4,
    random_state: int = RANDOM_STATE,
) -> SubgroupModel:
    """Cluster df's rows into subgroups and explain them with a NaN-native
    decision tree.

    Args:
        df: Rows to cluster. May contain NaNs.
        categorical_cols: Names of categorical columns; everything else in
            df is treated as numeric.
        exclude_cols: Columns to drop before clustering/explaining (e.g. an
            outcome/label column you don't want driving the subgroups).
        k: Fixed number of clusters. If None, picked by silhouette score
            over k_range.
        k_range: Candidate k values to try when k is None.
        max_depth: Max depth of the explanation tree.
        random_state: Seed for KMeans and the tree.

    Returns:
        A fitted SubgroupModel.
    """
    work = df.copy()
    if exclude_cols:
        work = work.drop(columns=[c for c in exclude_cols if c in work.columns])
    num_cols, cat_cols = _split_cols(work, categorical_cols)
    for c in cat_cols:
        work[c] = work[c].astype("object")

    encoder = _fit_encoder(work, num_cols, cat_cols)
    Z = encoder.transform(work)

    if k is None:
        k, silhouette = _pick_k(Z, k_range, random_state)
        if k is None:
            raise ValueError(
                "Could not find k >= 2 with more than one cluster; "
                "check dataset size or pass k explicitly"
            )
    else:
        tmp_labels = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit_predict(Z)
        silhouette = silhouette_score(Z, tmp_labels) if len(set(tmp_labels)) > 1 else float("nan")

    kmeans = KMeans(n_clusters=k, n_init=10, random_state=random_state).fit(Z)
    labels = kmeans.labels_
    sizes = {int(cid): int(n) for cid, n in pd.Series(labels).value_counts().sort_index().items()}

    Xn, names = _encode_for_tree(work, num_cols, cat_cols)
    tree = DecisionTreeClassifier(
        max_depth=max_depth,
        min_samples_leaf=max(5, len(work) // 40),
        class_weight="balanced",
        random_state=random_state,
    )
    tree.fit(Xn, labels)
    train_accuracy = float((tree.predict(Xn) == labels).mean())
    rules_text = export_text(tree, feature_names=names).replace("class:", "cluster:")

    return SubgroupModel(
        df=work.reset_index(drop=True),
        num_cols=num_cols,
        cat_cols=cat_cols,
        encoder=encoder,
        kmeans=kmeans,
        k=k,
        silhouette=silhouette,
        cluster_labels=labels,
        sizes=sizes,
        tree=tree,
        tree_feature_names=names,
        tree_train_accuracy=train_accuracy,
        rules_text=rules_text,
        random_state=random_state,
    )


def _transform_new(model: SubgroupModel, new_df: pd.DataFrame) -> np.ndarray:
    work = new_df.copy()
    for c in model.cat_cols:
        if c in work.columns:
            work[c] = work[c].astype("object")
    cols = model.num_cols + model.cat_cols
    return model.encoder.transform(work[cols])


def assign_subgroups(model: SubgroupModel, new_df: pd.DataFrame) -> np.ndarray:
    """Assign new_df's rows to the nearest fitted cluster centroid, using the
    same imputer/scaler/encoder fit in fit_subgroups. Useful for checking
    whether synthetic (or any new) data falls into the same subgroups."""
    Z_new = _transform_new(model, new_df)
    return model.kmeans.predict(Z_new)


def feature_deviation(
    model: SubgroupModel, cluster_id: int, new_df: pd.DataFrame, new_labels: np.ndarray,
    top_n: int = 5,
):
    """For one cluster, compare feature means/rates between the original
    fitting data and new_df's rows assigned to that same cluster -- surfaces
    which features drift most if a subgroup 'holds' in proportion only."""
    real_c = model.df[model.cluster_labels == cluster_id]
    new_c = new_df[new_labels == cluster_id]
    deviations = {}
    for c in model.num_cols:
        r = pd.to_numeric(real_c[c], errors="coerce").dropna()
        s = pd.to_numeric(new_c[c], errors="coerce").dropna()
        if r.empty or s.empty:
            continue
        r_std = float(r.std())
        if r_std < 1e-6:
            # Near-constant within this cluster (e.g. a binary missingness
            # indicator that defines the cluster) -- a std this small makes
            # the usual z-score denominator blow up to a meaningless
            # magnitude. Report the raw mean difference instead.
            diff = abs(s.mean() - r.mean())
            deviations[c] = (
                diff,
                f"orig_mean={r.mean():.3g} new_mean={s.mean():.3g} (near-constant in real; raw diff shown, not a z-score)",
            )
            continue
        z = abs(s.mean() - r.mean()) / r_std
        deviations[c] = (z, f"orig_mean={r.mean():.3g} new_mean={s.mean():.3g}")
    for c in model.cat_cols:
        r = real_c[c].dropna().astype(str)
        s = new_c[c].dropna().astype(str)
        if r.empty or s.empty:
            continue
        mode = r.mode().iloc[0]
        r_rate = (r == mode).mean()
        s_rate = (s == mode).mean()
        deviations[c] = (abs(r_rate - s_rate), f"orig_rate({mode})={r_rate:.2f} new_rate={s_rate:.2f}")
    return sorted(deviations.items(), key=lambda kv: kv[1][0], reverse=True)[:top_n]


def check_persistence(model: SubgroupModel, new_df: pd.DataFrame, k_range=K_RANGE) -> dict:
    """Do the subgroups found in the original data still hold in new_df (e.g.
    synthetic data)? Compares (a) transfer-assigning new_df to the original
    centroids against (b) an independent KMeans refit on new_df alone
    (clusters matched back to the original by nearest centroid).

    Returns a dict with per-cluster size/proportion comparisons and top
    deviating features, plus an overall agreement fraction and ARI score
    (None if new_df is too small/uniform to support an independent refit).
    """
    Z_new = _transform_new(model, new_df)
    transfer_labels = model.kmeans.predict(Z_new)

    real_sizes = pd.Series(model.cluster_labels).value_counts().sort_index()
    new_sizes = pd.Series(transfer_labels).value_counts().sort_index()
    real_prop = real_sizes / real_sizes.sum()
    new_prop = new_sizes / new_sizes.sum()

    per_cluster = {}
    for cid in sorted(real_sizes.index):
        per_cluster[int(cid)] = {
            "real_n": int(real_sizes.get(cid, 0)),
            "new_n": int(new_sizes.get(cid, 0)),
            "real_prop": round(float(real_prop.get(cid, 0.0)), 4),
            "new_prop": round(float(new_prop.get(cid, 0.0)), 4),
            "top_deviations": feature_deviation(model, cid, new_df, transfer_labels),
        }

    capped_range = range(2, min(max(k_range) + 1, len(Z_new)))
    k_new, sil_new = _pick_k(Z_new, capped_range, model.random_state)

    result = {
        "transfer_labels": transfer_labels,
        "per_cluster": per_cluster,
        "independent_k": k_new,
        "independent_silhouette": sil_new,
        "agreement": None,
        "ari": None,
    }
    if k_new is not None:
        kmeans_new = KMeans(n_clusters=k_new, n_init=10, random_state=model.random_state).fit(Z_new)
        perm = _match_clusters(model.kmeans.cluster_centers_, kmeans_new.cluster_centers_)
        matched = np.array([perm.get(int(lbl), -1) for lbl in kmeans_new.labels_])
        result["agreement"] = round(float((matched == transfer_labels).mean()), 4)
        result["ari"] = round(float(adjusted_rand_score(transfer_labels, kmeans_new.labels_)), 4)
    return result


def check_real_stability(
    df: pd.DataFrame,
    categorical_cols: List[str],
    exclude_cols: Optional[List[str]] = None,
    k: Optional[int] = None,
    n_runs: int = 20,
    subsample_frac: float = 0.8,
    random_state: int = RANDOM_STATE,
) -> dict:
    """Is fit_subgroups' clustering on df reproducible on its own, before you
    ever compare it to synthetic data? Two checks:

      1. Seed stability: refit KMeans at a FIXED k with n_runs different
         random seeds on the full data. Mean pairwise ARI between runs --
         low values mean the "clusters" depend on which random centroids
         happened to be seeded where, not on real structure.
      2. Resample stability: refit the whole pipeline (including re-picking
         k via silhouette) on n_runs random subsamples of subsample_frac of
         the rows. Reports how often the chosen k agrees across subsamples,
         plus mean pairwise ARI restricted to the rows any two subsamples
         have in common -- tests sensitivity to which patients happen to be
         in the sample, the actual risk at small n.

    A low score here means the real clusters aren't a solid target to check
    synthetic persistence against in the first place -- fix this before
    trusting check_persistence's results.
    """
    if k is None:
        k = fit_subgroups(df, categorical_cols, exclude_cols, random_state=random_state).k

    seed_labels = []
    for seed in range(n_runs):
        m = fit_subgroups(df, categorical_cols, exclude_cols, k=k, random_state=seed)
        seed_labels.append(m.cluster_labels)
    seed_aris = [
        adjusted_rand_score(a, b) for a, b in itertools.combinations(seed_labels, 2)
    ]

    resample_fits = []
    for i in range(n_runs):
        sub = df.sample(frac=subsample_frac, random_state=i)
        m = fit_subgroups(sub, categorical_cols, exclude_cols, k=None, random_state=random_state)
        resample_fits.append((sub.index, m.k, m.cluster_labels))

    k_agreement = Counter(k_i for _, k_i, _ in resample_fits)
    resample_aris = []
    for (idx_a, _, lab_a), (idx_b, _, lab_b) in itertools.combinations(resample_fits, 2):
        a = pd.Series(lab_a, index=idx_a)
        b = pd.Series(lab_b, index=idx_b)
        common = a.index.intersection(b.index)
        if len(common) < 10:
            continue
        resample_aris.append(adjusted_rand_score(a.loc[common], b.loc[common]))

    return {
        "k": k,
        "seed_ari_mean": float(np.mean(seed_aris)),
        "seed_ari_std": float(np.std(seed_aris)),
        "k_agreement": dict(k_agreement),
        "resample_ari_mean": float(np.mean(resample_aris)) if resample_aris else None,
        "resample_ari_std": float(np.std(resample_aris)) if resample_aris else None,
    }


# ---------------------------------------------------------------------------
# Distal outcome validation (Gloster et al. 2024 style)
# ---------------------------------------------------------------------------

# Dataset -> (staging function, kwargs, staged column to test, plain columns to test).
# The staging functions live in egfr_staging.py / hepatitis_albi_staging.py and are
# only called here, never reimplemented -- this module just consumes their output.
_OUTCOME_SPECS = {
    "ckd": {
        "staging_fn": "add_egfr_columns",
        "staging_kwargs": {"sc_col": "sc", "age_col": "age"},
        "staged_outcome_col": "ckd_stage",
        "plain_outcome_cols": ["class"],
    },
    "hepatitis": {
        "staging_fn": "add_albi_columns",
        "staging_kwargs": {"bilirubin_col": "bilirubin", "albumin_col": "albumin", "age_col": "age"},
        "staged_outcome_col": "albi_grade",
        "plain_outcome_cols": ["class"],
    },
}


def test_cluster_outcome(
    model: SubgroupModel,
    outcome: pd.Series,
    outcome_type: str = "auto",
    cluster_labels: Optional[np.ndarray] = None,
) -> dict:
    """Do the clusters in `model` (fit WITHOUT this outcome) actually differ
    on it? This is the second half of Gloster et al.'s (2024, Cognitive
    Therapy and Research) two-step validation: cluster first on structure
    alone, then separately test the resulting groups against a distal
    outcome they never saw. A cluster solution that is stable
    (check_real_stability) and persists in synthetic data (check_persistence)
    but shows no relationship to any clinically meaningful outcome is a much
    weaker finding than one that does -- this is what closes that gap.

    An effect size is always reported alongside the p-value (Cohen's f for
    continuous outcomes, Cramer's V for categorical ones) because the
    subgroups produced by this module are often small (tens of rows), where
    a non-significant p-value can just mean underpowered rather than "no
    effect" -- Gloster et al. make the same choice for the same reason.

    Args:
        model: A SubgroupModel from fit_subgroups. Its clusters must not
            have been formed using `outcome` -- that's what makes this a
            distal-outcome test rather than circular.
        outcome: A pandas Series with the SAME length and row order as
            whatever labels this call is testing against (see
            `cluster_labels`) -- positional alignment, not a pandas index
            join.
        outcome_type: "continuous", "categorical", or "auto" (infer from
            dtype: numeric -> continuous, else -> categorical). Pass this
            explicitly for outcomes like a 1/2-coded class label that are
            numeric dtype but semantically categorical -- "auto" would
            misclassify those as continuous.
        cluster_labels: Which cluster labels to test `outcome` against.
            Defaults to model.cluster_labels (the real fitting data). Pass
            an explicit array -- e.g. the `transfer_labels` a
            check_persistence() call returned for some synthetic df -- to
            ask the follow-up question: does the outcome relationship found
            on real data still hold once rows are cluster-assigned via
            transfer from synthetic data? `outcome` must then be aligned to
            that same synthetic df, not to model.df.

    Returns:
        A dict with the test used, statistic, p_value, an effect size, a
        per-cluster summary of the outcome, and NaN-drop bookkeeping
        (n_total/n_used/n_dropped_nan) -- eGFR stage and ALBI grade are
        undefined (pediatric/unstageable/unscorable) for some patients, so
        those rows are dropped from the test rather than guessed at.
    """
    labels_arr = np.asarray(model.cluster_labels if cluster_labels is None else cluster_labels)
    labels = pd.Series(labels_arr, index=range(len(labels_arr)))
    outcome = pd.Series(np.asarray(outcome), index=range(len(outcome)), name=getattr(outcome, "name", "outcome"))
    if len(outcome) != len(labels):
        raise ValueError(
            f"outcome has {len(outcome)} rows but there are {len(labels)} cluster labels; "
            "outcome must be aligned to the same rows (same length/row order) as cluster_labels"
        )

    if outcome_type == "auto":
        outcome_type = "continuous" if pd.api.types.is_numeric_dtype(pd.array(outcome.dropna())) else "categorical"

    n_total = len(outcome)
    valid = outcome.notna()
    n_dropped = int((~valid).sum())
    outcome_valid = outcome[valid]
    labels_valid = labels[valid]
    cluster_ids = sorted(pd.unique(labels_valid))

    result = {
        "outcome_name": outcome.name,
        "outcome_type": outcome_type,
        "n_total": n_total,
        "n_used": int(valid.sum()),
        "n_dropped_nan": n_dropped,
        "note": (
            f"dropped {n_dropped} of {n_total} rows with NaN/undefined outcome"
            if n_dropped else None
        ),
    }

    if outcome_type == "continuous":
        outcome_valid = pd.to_numeric(outcome_valid, errors="coerce")
        groups = [outcome_valid[labels_valid == cid].dropna() for cid in cluster_ids]
        f_stat, p_value = stats.f_oneway(*groups)

        grand_mean = outcome_valid.mean()
        ss_between = sum(len(g) * (g.mean() - grand_mean) ** 2 for g in groups)
        ss_total = float(((outcome_valid - grand_mean) ** 2).sum())
        eta_sq = ss_between / ss_total if ss_total > 0 else float("nan")
        cohens_f = float(np.sqrt(eta_sq / (1 - eta_sq))) if eta_sq is not None and eta_sq < 1 else float("nan")

        result.update({
            "test": "one-way ANOVA",
            "statistic": float(f_stat),
            "p_value": float(p_value),
            "eta_squared": float(eta_sq),
            "cohens_f": cohens_f,
            "per_cluster_summary": {
                int(cid): {"n": int(len(g)), "mean": float(g.mean()), "std": float(g.std())}
                for cid, g in zip(cluster_ids, groups)
            },
        })
    else:
        outcome_str = outcome_valid.astype(str)
        table = pd.crosstab(labels_valid, outcome_str)
        chi2, p_value, dof, _ = stats.chi2_contingency(table)
        n = int(table.values.sum())
        r, k = table.shape
        denom = min(r - 1, k - 1)
        cramers_v = float(np.sqrt((chi2 / n) / denom)) if denom > 0 else float("nan")

        result.update({
            "test": "chi-square test of independence",
            "statistic": float(chi2),
            "p_value": float(p_value),
            "dof": int(dof),
            "cramers_v": cramers_v,
            "per_cluster_summary": table.div(table.sum(axis=1), axis=0).round(4).to_dict(orient="index"),
            "contingency_table": table.to_dict(orient="index"),
        })
    return result


def test_cluster_outcomes_report(model: SubgroupModel, df: pd.DataFrame, dataset_name: str) -> dict:
    """Run test_cluster_outcome for the distal outcomes this repo already
    treats as clinically meaningful for `dataset_name` -- CKD stage + class
    for CKD, ALBI grade + class for hepatitis. Staging is computed by
    calling egfr_staging.add_egfr_columns / hepatitis_albi_staging.add_albi_columns
    (imported, not reimplemented) so this stays consistent with the staging
    logic used everywhere else in the project.

    Args:
        model: A SubgroupModel fit on df (or a row-order-compatible subset,
            e.g. the CKD-positive-only or hepatitis-survivors-only slice) via
            fit_subgroups.
        df: The dataframe in the SAME row order as what was passed to
            fit_subgroups to build model (positional alignment -- see
            test_cluster_outcome). Must contain the raw columns the relevant
            staging function needs (sc/age for CKD; bilirubin/albumin/age
            for hepatitis) plus a "class" column.
        dataset_name: "ckd" or "hepatitis".

    Returns:
        A dict keyed by outcome name ("ckd_stage"/"albi_grade" and "class"),
        each value the dict returned by test_cluster_outcome.
    """
    if dataset_name not in _OUTCOME_SPECS:
        raise ValueError(f"No outcome mapping for dataset_name={dataset_name!r}")
    spec = _OUTCOME_SPECS[dataset_name]
    df = df.reset_index(drop=True)

    if spec["staging_fn"] == "add_egfr_columns":
        from egfr_staging import add_egfr_columns
        staged = add_egfr_columns(df, **spec["staging_kwargs"])
    else:
        from hepatitis_albi_staging import add_albi_columns
        staged = add_albi_columns(df, **spec["staging_kwargs"])

    results = {}
    staged_col = spec["staged_outcome_col"]
    results[staged_col] = test_cluster_outcome(model, staged[staged_col], outcome_type="categorical")
    for col in spec["plain_outcome_cols"]:
        results[col] = test_cluster_outcome(model, df[col], outcome_type="categorical")
    return results


def print_outcome_result(outcome_name: str, res: dict) -> None:
    """Print one test_cluster_outcome result in the report's standard format
    -- shared by the CLI block below and any script that calls
    test_cluster_outcome directly (e.g. on a class-restricted population
    where a repo-wide outcome like `class` is constant by construction and
    test_cluster_outcomes_report's blanket class test doesn't apply)."""
    print(f"  [{outcome_name}] {res['test']} "
          f"(n_used={res['n_used']}/{res['n_total']}, dropped={res['n_dropped_nan']})")
    if res["outcome_type"] == "continuous":
        print(f"    F={res['statistic']:.3f}  p={res['p_value']:.4g}  "
              f"eta^2={res['eta_squared']:.3f}  Cohen's f={res['cohens_f']:.3f}")
        for cid, s in res["per_cluster_summary"].items():
            print(f"    cluster {cid}: n={s['n']} mean={s['mean']:.3g} std={s['std']:.3g}")
    else:
        print(f"    chi2={res['statistic']:.3f}  dof={res['dof']}  p={res['p_value']:.4g}  "
              f"Cramer's V={res['cramers_v']:.3f}")
        for cid, props in res["per_cluster_summary"].items():
            prop_str = ", ".join(f"{cat}={p:.2f}" for cat, p in props.items())
            print(f"    cluster {cid}: {prop_str}")


# ---------------------------------------------------------------------------
# CLI: reruns the CKD / hepatitis real-vs-synthetic persistence report
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from dataset_registry import DATASET_REGISTRY

    for dataset_name in ["ckd", "hepatitis"]:
        print(f"\n{'=' * 70}\n{dataset_name.upper()}\n{'=' * 70}")
        config = DATASET_REGISTRY[dataset_name]
        real_df = pd.read_csv(f"{dataset_name}_synthetic_b.csv")

        model = fit_subgroups(real_df, config["categorical_cols"], exclude_cols=["class"])
        print(f"\nChosen k={model.k} (silhouette={model.silhouette:.3f}), n={len(real_df)}")
        print("Cluster sizes:", model.sizes)
        if "class" in real_df.columns:
            print("Cluster vs class crosstab:")
            print(pd.crosstab(model.cluster_labels, real_df["class"]))
        print(f"\nExplain-tree train accuracy: {model.tree_train_accuracy:.3f} "
              f"({len(model.tree_feature_names)} encoded features)")
        print(model.rules_text)

        print("\n--- Real-data cluster stability (before trusting it as a target) ---")
        stability = check_real_stability(real_df, config["categorical_cols"], exclude_cols=["class"], k=model.k)
        print(f"  k={stability['k']}")
        print(f"  Seed stability (20 seeds, fixed k): mean ARI={stability['seed_ari_mean']:.3f} "
              f"(std={stability['seed_ari_std']:.3f})")
        print(f"  Resample stability (20x 80% subsamples, k re-picked): "
              f"k agreement={stability['k_agreement']}")
        if stability["resample_ari_mean"] is not None:
            print(f"  Resample mean ARI (on overlapping rows)={stability['resample_ari_mean']:.3f} "
                  f"(std={stability['resample_ari_std']:.3f})")
        else:
            print("  Resample ARI: not enough overlapping rows across subsamples to compute")

        print("\n--- Cluster vs distal outcome (real data) ---")
        outcome_results = test_cluster_outcomes_report(model, real_df, dataset_name)
        for outcome_name, res in outcome_results.items():
            print_outcome_result(outcome_name, res)

        for variant in ["s1", "s2"]:
            print(f"\n--- {variant.upper()} persistence ---")
            synth_df = pd.read_csv(f"{dataset_name}_synthetic_{variant}.csv")
            result = check_persistence(model, synth_df)
            for cid, info in result["per_cluster"].items():
                dev = ", ".join(f"{c}(z={z:.2f})" for c, (z, _) in info["top_deviations"])
                print(f"  cluster {cid}: real_prop={info['real_prop']:.3f} "
                      f"synth_prop={info['new_prop']:.3f}  top deviations: {dev}")
            if result["independent_k"] is not None:
                print(f"  independent k={result['independent_k']} "
                      f"(silhouette={result['independent_silhouette']:.3f})")
            print(f"  Persistence agreement={result['agreement']}  ARI={result['ari']}")
