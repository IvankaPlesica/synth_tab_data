"""RQ2: missingness-mechanism-aware synthetic data experiment.

Three branches share an 80/20 stratified split of the real data and the same
MICE + logistic regression scorer.  Only the training data going into the scorer
differs across branches:

  Branch R  – real training data (with missingness) → MICE → predict on test
  Branch S1 – simple-impute train → synthesize → shadow-column reinsertion
               → MICE → predict on test
  Branch S2 – simple-impute train → synthesize → shadow-pattern reinsertion
               → MICE → predict on test

All three branches predict on the same real held-out test set so AUC scores
are directly comparable.

Mechanism-aware imputation and Rubin's-rules pooling are intentionally deferred;
this module implements the structural skeleton.
"""

from __future__ import annotations

import json
import logging
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Dict, Optional

import numpy as np
import pandas as pd
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import IterativeImputer, SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

from .missingness import DataFrameMissingnessModel

log = logging.getLogger(__name__)

# Shared hyperparameters — keep identical across all branches and Score R.
_MICE_TREES = 50
_MICE_ITERS = 10
_LR_MAX_ITER = 1000


@dataclass
class RQ2Scores:
    """Scores and diagnostics from one RQ2 experimental run."""

    outcome_col: str
    n_train: int
    n_test: int
    score_r: Optional[float] = None    # Branch R: real data baseline
    score_s1: Optional[float] = None   # Branch S1: shadow columns
    score_s2: Optional[float] = None   # Branch S2: shadow patterns
    error_r: Optional[str] = None
    error_s1: Optional[str] = None
    error_s2: Optional[str] = None


# ─── Preprocessing helpers ────────────────────────────────────────────────────

def _simple_impute(df: pd.DataFrame) -> pd.DataFrame:
    """Mean for numerics, mode for categoricals. Returns a complete-case copy."""
    out = df.copy()
    num_cols = df.select_dtypes(include="number").columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    if num_cols:
        out[num_cols] = SimpleImputer(strategy="mean").fit_transform(out[num_cols])
    if cat_cols:
        out[cat_cols] = SimpleImputer(strategy="most_frequent").fit_transform(out[cat_cols])
    return out


def _encode_features(df: pd.DataFrame) -> pd.DataFrame:
    """One-hot encode categoricals and pass numerics through. All-numeric output."""
    num_cols = df.select_dtypes(include="number").columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    parts: list[pd.DataFrame] = [df[num_cols].reset_index(drop=True)]
    if cat_cols:
        parts.append(
            pd.get_dummies(
                df[cat_cols].reset_index(drop=True),
                drop_first=False,
                dummy_na=False,
            )
        )
    return pd.concat(parts, axis=1)


# ─── Shared MICE + logistic scorer ───────────────────────────────────────────

def _score_branch(
    train_features: pd.DataFrame,
    train_outcome: pd.Series,
    test_features: pd.DataFrame,
    test_outcome: pd.Series,
    *,
    seed: int,
) -> float:
    """MICE-impute (fit on train, transform both), fit logistic, return AUC on test.

    This is the single scorer used by all three branches — only ``train_features``
    differs between them, so any AUC difference is attributable to the data alone.
    """
    train_enc = _encode_features(train_features)
    # Align test columns to train; dummy columns unseen at test time get 0.
    test_enc = _encode_features(test_features).reindex(
        columns=train_enc.columns, fill_value=0
    )

    imp = IterativeImputer(
        estimator=RandomForestRegressor(n_estimators=_MICE_TREES, random_state=seed),
        max_iter=_MICE_ITERS,
        random_state=seed,
    )
    train_imp = pd.DataFrame(imp.fit_transform(train_enc), columns=train_enc.columns)
    test_imp = pd.DataFrame(imp.transform(test_enc), columns=test_enc.columns)

    le = LabelEncoder()
    y_train = le.fit_transform(train_outcome.reset_index(drop=True))
    y_test = le.transform(test_outcome.reset_index(drop=True))

    clf = LogisticRegression(max_iter=_LR_MAX_ITER, random_state=seed)
    clf.fit(train_imp, y_train)

    probs = clf.predict_proba(test_imp)
    if probs.shape[1] == 2:
        return float(roc_auc_score(y_test, probs[:, 1]))
    return float(roc_auc_score(y_test, probs, multi_class="ovr", average="macro"))


# ─── Missingness reinsertion strategies ──────────────────────────────────────

def _reinsert_shadow_columns(
    synth_features: pd.DataFrame,
    real_train_features: pd.DataFrame,
    *,
    seed: int,
) -> pd.DataFrame:
    """Reinsert per-variable missingness using DataFrameMissingnessModel.

    Fits the per-column logistic missingness model on the real training features
    (which preserves conditional structure: P(col_j missing | other columns))
    and applies it to the synthetic features.
    """
    model = DataFrameMissingnessModel(random_state=seed).fit(real_train_features)
    feature_cols = [c for c in real_train_features.columns if c in synth_features.columns]
    out = synth_features.copy()
    out[feature_cols] = model.apply(synth_features[feature_cols])
    return out


def _reinsert_shadow_patterns(
    synth_features: pd.DataFrame,
    real_train_features: pd.DataFrame,
    *,
    seed: int,
    min_support: float = 0.2,
    min_any_confidence: float = 0.7,
) -> pd.DataFrame:
    """Reinsert block-level co-missingness using RQ1 pattern labels.

    Fits a MissingnessModel on the real training features to discover co-missing
    blocks, assigns pattern labels to every real training row via assign_patterns(),
    builds per-label missingness templates (which columns are null in >50% of rows
    carrying that label), samples labels from the empirical distribution, and
    applies templates to synthetic rows.

    Falls back to shadow-column reinsertion if efficient_apriori or block_analysis
    are not importable (e.g. the optional dependency is not installed).
    """
    try:
        # These modules use implicit absolute imports (legacy script style).
        # Insert the package directory so Python can find detect_relevant_blocks.
        _pkg_dir = str(Path(__file__).parent)
        if _pkg_dir not in sys.path:
            sys.path.insert(0, _pkg_dir)
        from Missingness_Model import MissingnessModel  # type: ignore[import]
        from block_analysis import assign_patterns  # type: ignore[import]
    except ImportError as exc:
        log.warning(
            "Shadow-pattern reinsertion unavailable (%s); falling back to shadow columns",
            exc,
        )
        return _reinsert_shadow_columns(synth_features, real_train_features, seed=seed)

    block_model = MissingnessModel().fit(
        real_train_features,
        min_support=min_support,
        min_any_confidence=min_any_confidence,
    )

    # assign_patterns returns a same-length Series of label strings per row.
    real_labels: pd.Series = assign_patterns(real_train_features, block_model)

    # Build a missingness template per label: a column is in the template when
    # more than half of the real rows carrying that label have it missing.
    missing_real = real_train_features.isnull()
    templates: Dict[str, set] = {}
    for lbl in real_labels.unique():
        idx = real_labels[real_labels == lbl].index
        col_miss_rate = missing_real.loc[idx].mean()
        templates[lbl] = set(col_miss_rate[col_miss_rate > 0.5].index)

    label_dist = real_labels.value_counts(normalize=True)
    rng = np.random.default_rng(seed)
    sampled_labels = pd.Series(
        rng.choice(label_dist.index.tolist(), size=len(synth_features), p=label_dist.values),
        index=synth_features.index,
    )

    feature_cols = [c for c in real_train_features.columns if c in synth_features.columns]
    out = synth_features.copy()
    for lbl in label_dist.index:
        rows = sampled_labels[sampled_labels == lbl].index
        cols_to_null = [c for c in feature_cols if c in templates.get(lbl, set())]
        if rows.empty or not cols_to_null:
            continue
        out.loc[rows, cols_to_null] = np.nan

    return out


# ─── Main entry point ─────────────────────────────────────────────────────────

def run_rq2(
    df: pd.DataFrame,
    synthesize_fn: Callable[[pd.DataFrame], pd.DataFrame],
    *,
    outcome_col: str,
    outdir: Path,
    seed: int = 42,
    test_size: float = 0.2,
    shadow_pattern_params: Optional[Dict] = None,
) -> RQ2Scores:
    """Run the three-branch RQ2 experiment and write ``rq2_results.json``.

    Args:
        df: Full real dataset, may contain missing values.
        synthesize_fn: Callable that receives a complete-case training DataFrame
            (simple-imputed, outcome column included) and returns a synthetic
            DataFrame of the same schema.  Called once; result is reused for S1
            and S2 so the two branches differ only in reinsertion strategy.
        outcome_col: Target column present in ``df``.
        outdir: Directory where ``rq2_results.json`` is written.
        seed: Random seed shared by the split, MICE imputer, and missingness models.
        test_size: Fraction of rows held out as the real evaluation test set.
        shadow_pattern_params: Optional overrides forwarded to
            ``_reinsert_shadow_patterns`` (keys: ``min_support``,
            ``min_any_confidence``).

    Returns:
        :class:`RQ2Scores` with AUC scores and any per-branch error messages.
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    if outcome_col not in df.columns:
        raise ValueError(f"outcome_col {outcome_col!r} not found in df columns")

    # ── Shared 80/20 split ────────────────────────────────────────────────────
    try:
        train_df, test_df = train_test_split(
            df, test_size=test_size, random_state=seed, stratify=df[outcome_col]
        )
    except ValueError:
        # Fall back to non-stratified if classes are too rare to stratify.
        train_df, test_df = train_test_split(df, test_size=test_size, random_state=seed)

    train_features = train_df.drop(columns=[outcome_col])
    train_outcome = train_df[outcome_col]
    test_features = test_df.drop(columns=[outcome_col])
    test_outcome = test_df[outcome_col]

    scores = RQ2Scores(
        outcome_col=outcome_col,
        n_train=len(train_df),
        n_test=len(test_df),
    )

    # ── Branch R: real data baseline ─────────────────────────────────────────
    try:
        scores.score_r = _score_branch(
            train_features, train_outcome, test_features, test_outcome, seed=seed
        )
        log.info("Branch R (real): AUC = %.4f", scores.score_r)
    except Exception as exc:
        scores.error_r = str(exc)
        log.exception("Branch R failed")

    # ── Shared synthesis step (used by both S1 and S2) ────────────────────────
    train_complete = _simple_impute(train_df)
    try:
        synth_df = synthesize_fn(train_complete)
    except Exception as exc:
        msg = f"synthesize_fn failed: {exc}"
        log.exception(msg)
        scores.error_s1 = msg
        scores.error_s2 = msg
        _write_results(outdir, scores)
        return scores

    # The outcome column should be in synth_df; fall back to real train outcomes
    # if the synthesizer dropped it (e.g. features-only synthesizer).
    synth_features = synth_df.drop(columns=[outcome_col], errors="ignore")
    synth_outcome = (
        synth_df[outcome_col] if outcome_col in synth_df.columns else train_outcome
    )

    # ── Branch S1: shadow columns ─────────────────────────────────────────────
    try:
        s1_features = _reinsert_shadow_columns(
            synth_features, real_train_features=train_features, seed=seed
        )
        scores.score_s1 = _score_branch(
            s1_features, synth_outcome, test_features, test_outcome, seed=seed
        )
        log.info("Branch S1 (shadow columns): AUC = %.4f", scores.score_s1)
    except Exception as exc:
        scores.error_s1 = str(exc)
        log.exception("Branch S1 failed")

    # ── Branch S2: shadow patterns ────────────────────────────────────────────
    try:
        s2_features = _reinsert_shadow_patterns(
            synth_features,
            real_train_features=train_features,
            seed=seed,
            **(shadow_pattern_params or {}),
        )
        scores.score_s2 = _score_branch(
            s2_features, synth_outcome, test_features, test_outcome, seed=seed
        )
        log.info("Branch S2 (shadow patterns): AUC = %.4f", scores.score_s2)
    except Exception as exc:
        scores.error_s2 = str(exc)
        log.exception("Branch S2 failed")

    _write_results(outdir, scores)
    return scores


def _write_results(outdir: Path, scores: RQ2Scores) -> None:
    path = outdir / "rq2_results.json"
    path.write_text(json.dumps(asdict(scores), indent=2), encoding="utf-8")
    log.info("RQ2 results written to %s", path)
