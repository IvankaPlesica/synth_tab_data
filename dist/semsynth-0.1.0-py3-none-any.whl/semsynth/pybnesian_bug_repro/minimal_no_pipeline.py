"""Absolute minimal reproducer: load the exact dataframe that crashed inside
the pipeline, then call ONLY learn_bn() + .sample() -- no mining, no
imputation, no evaluate script, nothing else from semsynth's pipeline code.
"""
import faulthandler
faulthandler.enable()

import os
import sys
import pandas as pd
from semsynth.backends.pybnesian import learn_bn

df = pd.read_pickle(os.path.join(os.path.dirname(__file__), "crashing_df.pkl"))
print("loaded df:", df.shape, flush=True)

mode = sys.argv[1] if len(sys.argv) > 1 else "matched"
if mode == "matched":
    # exactly the params the pipeline actually used
    bn_art = learn_bn(df, bn_type="clg", random_state=42, arc_blacklist=[], max_indegree=2)
else:
    # literal `learn_bn(df)` -- pure library defaults, no overrides at all
    bn_art = learn_bn(df)

print("learn_bn() OK, fitted.", flush=True)
sample = bn_art.model.sample(100, seed=42)
print("sample(100) OK:", sample.num_rows, flush=True)
