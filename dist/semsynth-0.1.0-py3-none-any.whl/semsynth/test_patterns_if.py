"""Standalone check: hybrid labeling -- irregular patterns with enough
support get their own label (learned jointly by the BN); rare/singleton
patterns fall back to a shared bucket handled by mask resampling."""

import pandas as pd
from dataset_registry import DATASET_REGISTRY
from Missingness_Model import MissingnessModel

MIN_IRREGULAR_SUPPORT = 5   # tune this

dataset_name = "ckd"
config = DATASET_REGISTRY[dataset_name]
df = config["loader"]()
X = df.drop(columns=["class"])
min_support = config["min_support"]
min_any_confidence = config["min_any_confidence"]

mining_model = MissingnessModel().fit(
    X, min_support=min_support, min_any_confidence=min_any_confidence
)


def assign_pattern_hybrid(row_isna, blocks, common_irregular):
    active = ["+".join(b["itemset"]) for b in blocks if row_isna[b["itemset"]].all()]
    if not active:
        if not row_isna.any():
            return "mp0"
        missing_cols = tuple(sorted(row_isna.index[row_isna]))
        if missing_cols in common_irregular:
            return "irr:" + "+".join(missing_cols)
        return "mp_other"                                          # rare -- still lumped, still resampled
    return " & ".join(active)


# first pass: find which irregular combos clear the support threshold
def raw_missing_combo(row_isna, blocks):
    active_cols = set()
    for b in blocks:
        if row_isna[b["itemset"]].all():
            active_cols.update(b["itemset"])
    if active_cols or not row_isna.any():
        return None
    return tuple(sorted(row_isna.index[row_isna]))

combos = X.apply(lambda row: raw_missing_combo(row.isna(), mining_model.blocks), axis=1)
combo_counts = combos.value_counts()
common_irregular = set(combo_counts[combo_counts >= MIN_IRREGULAR_SUPPORT].index)

labels = X.apply(
    lambda row: assign_pattern_hybrid(row.isna(), mining_model.blocks, common_irregular),
    axis=1
)

print(f"Common irregular patterns (support >= {MIN_IRREGULAR_SUPPORT}): {len(common_irregular)}")
for c in sorted(common_irregular, key=lambda c: -combo_counts[c]):
    print(f"  irr:{'+'.join(c)}  (n={combo_counts[c]})")

print(f"\nTotal distinct labels: {labels.nunique()}")
print(f"Remaining mp_other rate: {(labels == 'mp_other').mean():.3f}")
print(labels.value_counts())