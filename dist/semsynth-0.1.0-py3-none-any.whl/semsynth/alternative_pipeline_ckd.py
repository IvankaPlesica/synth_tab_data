"""
CKD missingness mining pipeline: loads the dataset, computes eGFR
staging, mines association rules on the missingness matrix via Apriori,
filters/prunes them using data-grounded thresholds, and summarizes the
result as interpretable rule families -- for the full dataset and,
separately, stratified by class (ckd vs notckd).
"""
import pandas as pd
from efficient_apriori import apriori

from load_ckd import load_ckd
from egfr_staging import add_egfr_columns
from rule_mining import missing_matrix, filter_rules, prune_redundant_rules
from rule_families import group_into_families, print_families


def mine_and_summarize(df_subset, min_support=0.1, min_confidence=0.9):
    """
    Runs the full mining pipeline (Apriori -> filter -> prune -> rule
    families) on a given dataframe subset, and returns the families.
    Reused for both the full dataset and each class stratum.
    """
    M = missing_matrix(df_subset)
    if M.shape[1] == 0:
        return None, None

    transactions = [tuple(c for c in M.columns if row[c]) for _, row in M.iterrows()]
    itemsets, rules = apriori(
        transactions, output_transaction_ids=True,
        min_support=min_support, min_confidence=min_confidence,
    )

    reshaped = [{
        "if_missing": sorted(r.lhs),
        "then_missing": list(r.rhs)[0],
        "support": round(float(r.support), 4),
        "confidence": round(float(r.confidence), 4),
        "lift": round(float(r.lift), 4),
        "source": "apriori",
    } for r in rules if len(r.rhs) == 1]

    pruned = prune_redundant_rules(filter_rules(reshaped, M))
    families = group_into_families(pruned)
    return pruned, families


# --- load + eGFR staging ---
df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")

exclude_cols = ["egfr_star", "ckd_stage", "ckd_stage_cat"]
df_mining = df.drop(columns=[c for c in exclude_cols if c in df.columns])
df_features = df_mining.drop(columns=["class"])

# --- full dataset ---
print("=== Full dataset ===")
pruned, families = mine_and_summarize(df_features)
print(f"{len(df_features)} rows -> {len(pruned)} rules after filtering and pruning\n")
print_families(families)

# --- stratified by class ---
for cls in df_mining["class"].unique():
    subset = df_mining[df_mining["class"] == cls].drop(columns=["class"])

    pruned_sub, families_sub = mine_and_summarize(subset)

    print(f"\n\n=== class={cls} ({len(subset)} rows) ===")
    if families_sub is None:
        print("No missing columns, skipping")
        continue

    print(f"{len(pruned_sub)} rules after filtering and pruning -> {len(families_sub)} families\n")
    print_families(families_sub)