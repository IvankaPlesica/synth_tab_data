import numpy as np


def build_shadow_columns(X_train):
    return X_train.isnull().astype(int).add_suffix("_NA")


def reinsert_from_shadow_columns(synth_features_with_shadows, original_cols):
    out = synth_features_with_shadows.copy()
    for col in original_cols:
        na_col = f"{col}_NA"
        if na_col in out.columns:
            mask = out[na_col].astype(str) == "1"
            out.loc[mask, col] = np.nan
    out = out.drop(columns=[c for c in out.columns if c.endswith("_NA")])
    return out
