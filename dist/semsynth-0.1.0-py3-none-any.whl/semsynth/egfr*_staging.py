"""
ckd_egfr_staging.py

Computes the sex-agnostic eGFR* approximation and assigns a CKD severity
stage, adding both as columns on the full dataframe.

Usage:
    from ckd_egfr_staging import add_egfr_columns
    df = add_egfr_columns(df)
    # df now has "egfr_star" and "ckd_stage" columns
"""

import pandas as pd
import numpy as np

KAPPA = 0.8
ALPHA = -0.27
MIN_ADULT_AGE = 18

STAGE_BINS = [0, 15, 60, 999]
STAGE_LABELS = ["late", "mid", "early"]


def compute_egfr_star(sc, age):
    """
    Compute the sex-agnostic eGFR* approximation for a single patient.
    Returns NaN if sc or age is missing, or if age is below the validated
    adult threshold (CKD-EPI is not valid for pediatric patients).
    """
    sc = pd.to_numeric(sc, errors="coerce")
    age = pd.to_numeric(age, errors="coerce")

    if pd.isna(sc) or pd.isna(age) or sc <= 0 or age < MIN_ADULT_AGE:
        return np.nan

    ratio = sc / KAPPA
    if ratio < 1:
        value = 142 * (ratio ** ALPHA) * (0.9938 ** age)
    else:
        value = 142 * (ratio ** -1.200) * (0.9938 ** age)

    return round(value, 1)


def add_egfr_columns(df, sc_col="sc", age_col="age"):
    """
    Add 'egfr_star' and 'ckd_stage' columns to the dataframe in place
    (returns the same dataframe with new columns).

    Both columns are computed for every row, not just CKD patients --
    eGFR* is a property of any adult patient with sc and age available,
    regardless of class label. Filter by class downstream if needed.
    """
    df = df.copy()

    df["egfr_star"] = [
        compute_egfr_star(sc, age)
        for sc, age in zip(df[sc_col], df[age_col])
    ]

    df["ckd_stage"] = pd.cut(
        df["egfr_star"], bins=STAGE_BINS, labels=STAGE_LABELS
    )

    return df

df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")