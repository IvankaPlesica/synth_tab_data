import rpy2.robjects as ro
import numpy as np

ro.r('library(PKLMtest)')
ro.r('options(ranger.num.threads = 8)')  # increase from default 2


def _run_pklm_once(num_df):
    nrow, ncol = num_df.shape

    ro.globalenv['mat_data'] = ro.FloatVector(
        num_df.values.astype(float).flatten(order="F")
    )
    ro.globalenv['mat_nrow'] = ro.IntVector([nrow])
    ro.globalenv['mat_ncol'] = ro.IntVector([ncol])
    ro.globalenv['mat_cols'] = ro.StrVector(num_df.columns.tolist())

    ro.r('''
        X <- matrix(mat_data, nrow=mat_nrow, ncol=mat_ncol)
        colnames(X) <- mat_cols
    ''')
    # no set.seed(): each call uses fresh randomness
    # using the original paper's recommended hyperparameters (Spohn et al.),
    # which are faster than the package's own defaults (num.proj=300,
    # nrep=500): num.proj=100, nrep=30, num.trees.per.proj=200
    result = ro.r['PKLMtest'](ro.r['X'], num_proj=100, nrep=30,
                               num_trees_per_proj=200)
    return float(result.rx2("all")[0])


def pklm_test(df, n_runs=5):
    """
    PKLM test for MCAR (Spohn et al. 2025).
    Non-parametric, classification-based alternative to Little's test.
    H0: data is MCAR. Low p-value rejects MCAR.
    Outcome variable excluded via select_dtypes (object columns dropped).

    Run n_runs times with no fixed seed and report mean/std p-value,
    to check the conclusion is stable rather than dependent on one run.
    """
    num_df = df.select_dtypes(include="number").dropna(how="all", axis=1)

    p_values = [round(_run_pklm_once(num_df), 4) for _ in range(n_runs)]

    return {
        "p_values": p_values,
        "mean_p": round(float(np.mean(p_values)), 4),
        "std_p": round(float(np.std(p_values)), 4),
    }