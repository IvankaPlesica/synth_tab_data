from missingness_patterns_ckd import assign_patterns
import gzip
import pandas as pd



with gzip.open("../downloads-cache/uciml/336.csv.gz") as f:
    df = pd.read_csv(f)


df["missingness_pattern"] = assign_patterns(df)
print(df["missingness_pattern"].value_counts())

df.to_csv("ckd_with_patterns.csv", index=False)
print("Saved ckd_with_patterns.csv")