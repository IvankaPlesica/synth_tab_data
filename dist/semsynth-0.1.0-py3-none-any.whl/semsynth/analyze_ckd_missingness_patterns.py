"""Post-hoc missingness-block analysis for a generated CKD CSV.

Not a synthesis pipeline (despite the old filename this replaces,
pipeline_ckd.py, which collided in name with the real orchestrator in
semsynth/pipeline.py). This script does no synthesis at all -- it loads
one already-generated CSV (by default ckd_synthetic_s2.csv, written by
export_ckd_synthetic_datasets.py), adds eGFR staging columns, mines
missingness blocks with MissingnessModel, and prints rate/co-occurrence
breakdowns of those blocks by class and CKD stage.

To point this at real data instead of a synthetic CSV, swap the two
lines below for `df = load_ckd()` + `add_egfr_columns(df,
export_path="ckd_with_egfr.csv")`.
"""

import pandas as pd
from egfr_staging import add_egfr_columns
from Missingness_Model import MissingnessModel
from block_analysis import (
    assign_patterns,
    block_rate_table, block_missing_flags,
    block_cooccurrence, blocks_missing_per_row,
    itemset_rate_table,
)

df = pd.read_csv("ckd_synthetic_s2.csv")
df = add_egfr_columns(df, export_path="ckd_synthetic_s2_egfr.csv")

print(df.head())
print(df.shape)
print("Missing values per column:\n", df.isnull().sum())


exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])


model = MissingnessModel().fit(df_features, min_support=0.1, min_any_confidence=0.7)
model.summary()


df["missingness_pattern"] = assign_patterns(df_features, model)

counts = df["missingness_pattern"].value_counts()
pcts = df["missingness_pattern"].value_counts(normalize=True).round(3) * 100
print(pd.concat([counts, pcts], axis=1, keys=["count", "pct"]))

# --- Optional: breakdowns by class / stage / stage category ---
block_rate_table(df, df_features, model, "class",
                  ["ckd", "notckd"],
                  restrict_mask=df["class"].notna())

block_rate_table(df, df_features, model, "ckd_stage",
                  ["G5", "G4", "G3b", "G3a", "G2", "G1"],
                  restrict_mask=(df["class"] == "ckd") & df["ckd_stage"].notna())

block_rate_table(df, df_features, model, "ckd_stage_cat",
                  ["Failure", "Disease", "Early", "Normal"],
                  restrict_mask=(df["class"] == "ckd") & df["ckd_stage_cat"].notna())

# --- Optional: block co-occurrence and missingness burden ---
missing_flags = block_missing_flags(df_features, model)
print("\nP(block B missing | block A missing):")
print(block_cooccurrence(missing_flags))

df["n_blocks_missing"] = blocks_missing_per_row(missing_flags)
print("\nDistribution of number of blocks missing per patient:")
print(df["n_blocks_missing"].value_counts().sort_index())

print("\nMean number of blocks missing, by class:")
print(df.groupby("class")["n_blocks_missing"].mean().round(3))

severity_order = ["Failure", "Disease", "Early", "Normal"]
staged = df[(df["class"] == "ckd") & df["ckd_stage_cat"].isin(severity_order)]
print("\nMean number of blocks missing, by ckd_stage_cat (severity-ordered only):")
print(staged.groupby("ckd_stage_cat")["n_blocks_missing"].mean().reindex(severity_order).round(3))

# --- Optional: check a specific subset of a block (e.g. its tighter core) ---
core = ["al", "sg", "su"]
itemset_rate_table(df, df_features, core, "class",
                    ["ckd", "notckd"], restrict_mask=df["class"].notna())
itemset_rate_table(df, df_features, core, "ckd_stage",
                    ["G5", "G4", "G3b", "G3a", "G2", "G1"],
                    restrict_mask=(df["class"] == "ckd") & df["ckd_stage"].notna())
itemset_rate_table(df, df_features, core, "ckd_stage_cat",
                    ["Failure", "Disease", "Early", "Normal"],
                    restrict_mask=(df["class"] == "ckd") & df["ckd_stage_cat"].notna())