
import pandas as pd
from rule_mining import missing_matrix, mine_apriori, filter_rules, prune_redundant_rules, compressiveness

url = "https://archive.ics.uci.edu/ml/machine-learning-databases/thyroid-disease/allhyper.data"

cols = [
    "age", "sex", "on_thyroxine", "query_on_thyroxine", "on_antithyroid_medication",
    "sick", "pregnant", "thyroid_surgery", "I131_treatment", "query_hypothyroid",
    "query_hyperthyroid", "lithium", "goitre", "tumor", "hypopituitary", "psych",
    "TSH_measured", "TSH", "T3_measured", "T3", "TT4_measured", "TT4",
    "T4U_measured", "T4U", "FTI_measured", "FTI", "TBG_measured", "TBG", "referral_source", "target"
]

df = pd.read_csv(url, header=None, names=cols, na_values="?")
df = df.drop(columns=["TBG", "TBG_measured"])

M = missing_matrix(df.drop(columns=["target"]))
rules = mine_apriori(M)
rules = filter_rules(rules, M)
rules = prune_redundant_rules(rules)
cover = compressiveness(rules, M)

print(f"Shape: {df.shape}")
print(df.isnull().sum()[df.isnull().sum() > 0].sort_values(ascending=False))
print(f"\nRules: {len(rules)}, compressiveness: {cover}")
for r in rules:
    print(r)

