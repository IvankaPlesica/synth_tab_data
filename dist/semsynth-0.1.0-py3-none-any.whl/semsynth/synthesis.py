import pandas as pd
from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    coerce_continuous_to_float,
    coerce_discrete_to_category,
    rename_categorical_categories_to_str,
)


def synthesize(X_train_filled, y_train, categorical_cols, shadow_cols=None,
                pattern_labels=None, seed=42):
    working = X_train_filled.copy()
    working["class"] = y_train.values
    extra_disc_cols = []
    if shadow_cols is not None:
        working = pd.concat([working, shadow_cols], axis=1)
        extra_disc_cols += list(shadow_cols.columns)
    if pattern_labels is not None:
        working["missingness_pattern"] = pattern_labels
        extra_disc_cols.append("missingness_pattern")
    disc_cols = [c for c in categorical_cols if c in working.columns] + ["class"] + extra_disc_cols
    cont_cols = [c for c in working.columns if c not in disc_cols]
    working = coerce_discrete_to_category(working, disc_cols)
    working = rename_categorical_categories_to_str(working, disc_cols)
    working = coerce_continuous_to_float(working, cont_cols)
    bn_art = learn_bn(
        working, bn_type="semiparametric", random_state=seed, arc_blacklist=[], max_indegree=2
    )
    synth = bn_art.model.sample(len(working), seed=seed)
    synth_df = synth.to_pandas().reindex(columns=working.columns)
    for c in disc_cols:
        if c in synth_df.columns:
            synth_df[c] = synth_df[c].astype("category")
    synth_label = synth_df["class"]
    synth_features_with_shadows = synth_df.drop(columns=["class"])
    return synth_features_with_shadows, synth_label


def extract_synth_pattern_labels(synth_features_with_pattern):
    out = synth_features_with_pattern.copy()
    pattern_labels = out["missingness_pattern"].astype(str)
    out = out.drop(columns=["missingness_pattern"])
    return out, pattern_labels
