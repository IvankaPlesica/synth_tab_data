"""TSTR degradation by subgroup: how much does a model's AUC drop when
scored on just one cluster, compared to the whole test set?

Builds on mice_and_regression (imputation.py) and SubgroupModel /
assign_subgroups (subgroup_clustering.py) -- neither is modified beyond the
small return_proba addition to mice_and_regression.
"""

import numpy as np
from sklearn.metrics import roc_auc_score


def tstr_degradation(y_test, proba, cluster_labels_test, overall_auc, min_subgroup_n=10) -> dict:
    """Per-cluster AUC and its gap from the overall AUC.

    Args:
        y_test: real ground-truth labels for the test set.
        proba: predicted probabilities for y_test, from an already-fitted
            model (e.g. mice_and_regression(..., return_proba=True)).
        cluster_labels_test: cluster id per row of y_test/proba, same length
            and order (e.g. from assign_subgroups(model, X_test)).
        overall_auc: whole-population AUC to compare each subgroup against.
        min_subgroup_n: clusters with fewer test rows than this are skipped,
            not silently omitted -- too few rows for a stable roc_auc_score.

    Returns:
        Dict keyed by cluster id -> {n, auc, degradation, skipped}. auc and
        degradation are None when skipped is not False.
    """
    y_test = np.asarray(y_test)
    proba = np.asarray(proba)
    cluster_labels_test = np.asarray(cluster_labels_test)

    results = {}
    for c in sorted(set(cluster_labels_test)):
        mask = cluster_labels_test == c
        n = int(mask.sum())
        if n < min_subgroup_n:
            results[c] = {"n": n, "auc": None, "degradation": None,
                          "skipped": f"n={n} < min_subgroup_n={min_subgroup_n}"}
            continue
        if len(set(y_test[mask])) < 2:
            results[c] = {"n": n, "auc": None, "degradation": None,
                          "skipped": "only one class present in y_test for this cluster"}
            continue
        auc = roc_auc_score(y_test[mask], proba[mask])
        results[c] = {"n": n, "auc": auc, "degradation": overall_auc - auc, "skipped": False}
    return results


if __name__ == "__main__":
    from sklearn.model_selection import train_test_split

    from dataset_registry import DATASET_REGISTRY
    from imputation import mice_and_regression
    from subgroup_clustering import assign_subgroups, fit_subgroups

    config = DATASET_REGISTRY["ckd"]
    df = config["loader"]()
    categorical_cols = config["categorical_cols"]

    X = df.drop(columns=["class"])
    y = (df["class"] == config["positive_label"]).astype(int)
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=42
    )

    overall_auc, proba = mice_and_regression(X_train, y_train, X_test, y_test, return_proba=True)
    print(f"Overall AUC: {overall_auc}")

    subgroup_model = fit_subgroups(X_train, categorical_cols=categorical_cols, k=2)
    cluster_labels_test = assign_subgroups(subgroup_model, X_test)

    degradation = tstr_degradation(y_test.to_numpy(), proba, cluster_labels_test, overall_auc)
    print("\nTSTR degradation by subgroup:")
    for cluster_id, res in degradation.items():
        if res["skipped"]:
            print(f"  cluster {cluster_id}: n={res['n']}, skipped ({res['skipped']})")
        else:
            print(f"  cluster {cluster_id}: n={res['n']}, auc={res['auc']:.4f}, "
                  f"degradation={res['degradation']:+.4f}")
