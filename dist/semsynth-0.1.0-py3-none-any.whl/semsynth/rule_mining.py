import pandas as pd
import numpy as np
from collections import Counter
from mlxtend.frequent_patterns import apriori, association_rules
from aerial import model as aerial_model, rule_extraction
import warnings
warnings.filterwarnings("ignore")


def missing_matrix(df):
    cols = [c for c in df.columns if df[c].isnull().any()]
    return df[cols].isnull()

'''
def mine_aerial(M, epochs=50, runs=10, min_stability=0.6):
    rule_counts = Counter()
    rule_stats  = {}
    marginal    = M.mean()

    for _ in range(runs):
        idx    = np.random.choice(len(M), size=len(M), replace=True)
        M_boot = M.iloc[idx].reset_index(drop=True)

        trained = aerial_model.train(M_boot.astype(str), epochs=epochs)
        result  = rule_extraction.generate_rules(trained)

        for r in result["rules"]:
            if not (all(a["value"] == "True" for a in r["antecedents"])
                    and r["consequent"]["value"] == "True"):
                continue

            ant_cols = [a["feature"] for a in r["antecedents"]]
            cons_col = r["consequent"]["feature"]
            key      = (tuple(sorted(ant_cols)), cons_col)

            rule_counts[key] += 1
            if key not in rule_stats:
                rule_stats[key] = {"confidence": [], "lift": [], "zhangs": []}

            rule_stats[key]["confidence"].append(float(r["confidence"]))
            rule_stats[key]["zhangs"].append(float(r["zhangs_metric"]))

            ant_sup   = M[list(ant_cols)].all(axis=1).mean() if len(ant_cols) > 1 else float(marginal[ant_cols[0]])
            cons_sup  = float(marginal[cons_col])
            joint_sup = float(r["support"])
            denom     = ant_sup * cons_sup
            if denom > 0:
                rule_stats[key]["lift"].append(joint_sup / denom)

    out = []
    for key, count in rule_counts.items():
        stability = count / runs
        if stability < min_stability:
            continue

        ant_cols = list(key[0])
        cons_col = key[1]
        stats    = rule_stats[key]

        out.append({
            "if_missing":    ant_cols,
            "then_missing":  cons_col,
            "support":       round(float(M[ant_cols + [cons_col]].all(axis=1).mean()), 4),
            "confidence":    round(float(np.mean(stats["confidence"])), 4),
            "lift":          round(float(np.mean(stats["lift"])), 3) if stats["lift"] else None,
            "zhangs_metric": round(float(np.mean(stats["zhangs"])), 4),
            "stability":     round(stability, 3),
            "source":        "aerial",
        })

    return sorted(out, key=lambda x: (-x["confidence"], -x["support"]))


def filter_rules(rules, M, min_support=0.02, min_lift=3.0, min_gain=0.25):
    base_missing = M.mean()
    out = []
    for r in rules:
        gain = r["confidence"] - base_missing[r["then_missing"]]
        if r["support"] >= min_support and r["lift"] >= min_lift and gain >= min_gain:
            out.append({**r, "gain": round(float(gain), 4)})
    return out
'''

def prune_redundant_rules(rules):
    pruned = []
    for r in rules:
        redundant = any(
            kept["then_missing"] == r["then_missing"]
            and set(kept["if_missing"]).issubset(set(r["if_missing"]))
            and abs(kept["confidence"] - r["confidence"]) < 0.05
            for kept in rules
            if kept is not r
        )
        if not redundant:
            pruned.append(r)
    return pruned

''''
def compressiveness(rules, M, top_singletons=0):
    incomplete = M.any(axis=1)
    covered    = pd.Series(False, index=M.index)

    for rule in rules:
        cols     = rule["if_missing"] + [rule["then_missing"]]
        covered |= M[cols].all(axis=1)

    if top_singletons > 0:
        singleton_cols = M.sum().sort_values(ascending=False).head(top_singletons).index
        for col in singleton_cols:
            covered |= M[col]

    return round(float((covered & incomplete).sum() / incomplete.sum()), 4)


def stratified_mining(df, strata_col, min_support=0.03, min_confidence=0.75,
                       max_len=4, use_aerial=True, verbose=True):
    df = df.copy()
    df[strata_col] = df[strata_col].str.strip()

    results = {}

    for stratum, group in df.groupby(strata_col):
        if verbose:
            print(f"\nStratum: {strata_col}={stratum} ({len(group)} rows)")

        M = missing_matrix(group)

        if M.shape[1] == 0:
            if verbose:
                print(f"  No missing columns, skipping")
            continue

        rules_apriori = filter_rules(
            mine_apriori(M, min_support=min_support,
                         min_confidence=min_confidence, max_len=max_len),
            M
        )

        if use_aerial:
            rules_aerial = filter_rules(mine_aerial(M), M)
        else:
            rules_aerial = []

        # combine, deduplicate, then prune once -- same logic as the
        # top-level combined mining step in the main pipeline
        seen, rules_combined = set(), []
        for r in rules_apriori + rules_aerial:
            key = (tuple(r["if_missing"]), r["then_missing"])
            if key not in seen:
                seen.add(key)
                rules_combined.append(r)

        rules = prune_redundant_rules(rules_combined)
        cover = compressiveness(rules, M)

        if verbose:
            print(f"  Apriori: {len(rules_apriori)} rules, "
                  f"Aerial: {len(rules_aerial)} rules, "
                  f"Combined (after pruning): {len(rules)}, "
                  f"compressiveness={cover}")
            for r in sorted(rules, key=lambda r: -r["confidence"])[:10]:
                extras = f" zhang={r['zhangs_metric']}" if "zhangs_metric" in r else ""
                print(f"    {r['if_missing']} → {r['then_missing']}  "
                      f"sup={r['support']} conf={r['confidence']} lift={r['lift']}{extras}")

        results[str(stratum)] = {
            "n_rows":          len(group),
            "rules":           rules,
            "compressiveness": cover,
        }

    return results
'''