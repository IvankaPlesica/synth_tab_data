import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


df = pd.read_csv('ckd_patterns.csv')
df_ckd = df[(df["class"] == "ckd") & (df["age"] >= 18)].copy()
df_ckd["ckd_stage"] = pd.cut(df_ckd["egfr"], bins=[0, 15, 60, 999],
                               labels=["late", "mid", "early"])
ct = pd.crosstab(df_ckd["missingness_pattern"], df_ckd["ckd_stage"], normalize="index")
counts = df_ckd["missingness_pattern"].value_counts()



fig, ax = plt.subplots(figsize=(7, 4.5))

x = np.arange(len(patterns))
width = 0.6

ax.bar(x, late, width, label="Late (eGFR* < 15)", color="#E24B4A")
ax.bar(x, mid, width, bottom=late, label="Mid (15-59)", color="#EF9F27")
bottom_early = [l + m for l, m in zip(late, mid)]
ax.bar(x, early, width, bottom=bottom_early, label="Early (>= 60)", color="#1D9E75")

ax.set_xticks(x)
ax.set_xticklabels(patterns)
ax.set_ylabel("Proportion of patients")
ax.set_ylim(0, 1.15)
ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_yticklabels(["0%", "25%", "50%", "75%", "100%"])

# annotate sample size above each bar
for i, n in enumerate(counts):
    ax.text(i, 1.03, f"n={n}", ha="center", fontsize=9, color="gray")

ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=3, frameon=False, fontsize=9)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.set_title("eGFR* stage distribution by missingness pattern\n(adult CKD patients, n=215)", fontsize=11)

plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/egfr_stage_by_pattern.png", dpi=200, bbox_inches="tight")
print("Saved to /mnt/user-data/outputs/egfr_stage_by_pattern.png")