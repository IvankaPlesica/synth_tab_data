"""
Fidelity report for imputed vs synthetic CKD data using existing project utilities:
  - per_variable_distances / summarize_distance_metrics  (metrics.py)
  - build_umap / transform_with_umap / plot_umap         (umap_utils.py)
  - infer_types                                          (utils.py)

Outputs:
  fidelity_per_variable.csv   — KS / W1 / JSD per column
  fidelity_umap.png           — real vs synthetic UMAP overlay
"""

import logging
import numpy as np
import pandas as pd

from semsynth.metrics import per_variable_distances, summarize_distance_metrics
from semsynth.umap_utils import build_umap, transform_with_umap, plot_umap
from semsynth.utils import infer_types

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")

REAL_CSV  = "imputed_ckd_with_patterns.csv"
SYNTH_CSV = "synthetic_ckd.csv"


def main() -> None:
    real  = pd.read_csv(REAL_CSV)
    synth = pd.read_csv(SYNTH_CSV)

    # drop metadata column if present
    for df in (real, synth):
        if "missingness_pattern" in df.columns:
            df.drop(columns=["missingness_pattern"], inplace=True)

    disc_cols, cont_cols = infer_types(real)
    logging.info("Discrete cols: %d  Continuous cols: %d", len(disc_cols), len(cont_cols))

    # --- per-variable distances ---
    dist_df = per_variable_distances(real, synth, disc_cols, cont_cols)
    dist_df.to_csv("fidelity_per_variable.csv", index=False)

    summary = summarize_distance_metrics(dist_df)
    print("\n=== Summary ===")
    for k, v in summary.items():
        print(f"  {k}: {v:.4f}")

    print("\n=== Per-variable distances (sorted by worst) ===")
    # show KS for continuous, JSD for discrete in one column for easy scanning
    dist_df["score"] = dist_df["KS"].fillna(dist_df["JSD"])
    print(dist_df.sort_values("score", ascending=False).to_string(index=False))

    # --- UMAP overlay: fit on real, project synthetic ---
    logging.info("Fitting UMAP on real data …")
    rng = np.random.default_rng(42)
    art = build_umap(real, disc_cols, cont_cols, color_series=None, rng=rng, random_state=42)

    real_emb  = art.embedding                          # already embedded sample
    synth_emb = transform_with_umap(art, synth)        # project all synthetic rows

    # sample synthetic to the same size as the real embedding for a balanced plot
    n = len(real_emb)
    idx = rng.choice(len(synth_emb), size=min(n, len(synth_emb)), replace=False)
    synth_emb_sample = synth_emb[idx]

    combined_emb    = np.vstack([real_emb, synth_emb_sample])
    combined_labels = np.array([0] * n + [1] * len(synth_emb_sample), dtype=float)

    lims = plot_umap(
        combined_emb,
        outfile="fidelity_umap.png",
        title="Real (dark) vs Synthetic (light) — UMAP",
        color_labels=combined_labels,
    )
    logging.info("Saved → fidelity_umap.png  (axis limits: x=%s y=%s)", lims[0], lims[1])
    logging.info("Saved → fidelity_per_variable.csv")


if __name__ == "__main__":
    main()
