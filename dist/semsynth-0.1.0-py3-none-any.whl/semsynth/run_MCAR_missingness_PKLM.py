import pandas as pd
from load_ckd import load_ckd
from egfr_staging import add_egfr_columns
from Missingness_Model import MissingnessModel
from MCAR_missingness_PKLM import pklm_test

df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")

exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

model = MissingnessModel().fit(df_features, min_support=0.1, min_any_confidence=0.7)

# --- label each patient by which relevant block(s) are fully missing ---
def assign_pattern(row_isna, blocks):
    active = ["+".join(b["itemset"]) for b in blocks if row_isna[b["itemset"]].all()]
    if not active:
        return "mp0" if not row_isna.any() else "mp_other"
    return " & ".join(active)

df["missingness_pattern"] = df_features.apply(
    lambda row: assign_pattern(row.isna(), model.blocks), axis=1
)

# --- full dataset ---
print(f"Full dataset: {len(df)} rows")
print("PKLM MCAR test on full dataset:")
print(pklm_test(df_features, n_runs=5))

# --- residual rows not matched by any relevant block ---
mp_other = df_features[df["missingness_pattern"] == "mp_other"]
print(f"\nmp_other rows: {len(mp_other)}")
print("PKLM MCAR test on mp_other rows:")
print(pklm_test(mp_other, n_runs=5))