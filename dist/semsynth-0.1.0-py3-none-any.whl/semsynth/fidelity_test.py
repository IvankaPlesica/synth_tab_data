"""Three-backend marginal + joint fidelity comparison: PyBNesian vs MetaSyn vs SynthCity.
No S1/S2, no missingness reinsertion -- just raw synthesis, compared directly to real data.
"""

import pandas as pd
import numpy as np
from scipy.stats import ks_2samp, chi2_contingency
from sklearn.model_selection import train_test_split

from load_ckd import load_ckd
from egfr_staging import add_egfr_columns

from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    infer_types, coerce_discrete_to_category,
    coerce_continuous_to_float, rename_categorical_categories_to_str,
)
from metasyn.metaframe import MetaFrame

from synthcity.plugins import Plugins
from synthcity.plugins.core.dataloader import GenericDataLoader

# ============================================================
# 1. LOAD & SPLIT (same as your main pipeline)
# ============================================================
df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
df["class"] = df["class"].str.strip()

exclude_cols = ["egfr_star", "ckd_stage", "ckd_stage_cat"]
df_clean = df.drop(columns=[c for c in exclude_cols if c in df.columns])

y_all = (df_clean["class"] == "ckd").astype(int)
train_idx, _ = train_test_split(df_clean.index, test_size=0.2, random_state=42, stratify=y_all)
train_df = df_clean.loc[train_idx].reset_index(drop=True)

# simple median/mode fill for pre-synthesis (kept identical across all 3, per your
# "keep pre-synthesis simple for now" decision)
train_filled = train_df.fillna(train_df.median(numeric_only=True))
for col in train_filled.select_dtypes(include="object").columns:
    mode_vals = train_filled[col].mode()
    if not mode_vals.empty:
        train_filled[col] = train_filled[col].fillna(mode_vals.iloc[0])

N = len(train_filled)

# ============================================================
# 2a. SYNTHESIZE -- PyBNesian
# ============================================================
working = train_filled.copy()
disc_cols, cont_cols = infer_types(working)
working = coerce_discrete_to_category(working, disc_cols)
working = rename_categorical_categories_to_str(working, disc_cols)
working = coerce_continuous_to_float(working, cont_cols)

bn_art = learn_bn(working, bn_type="clg", random_state=42, arc_blacklist=[])
pybnesian_synth = bn_art.model.sample(N, seed=42).to_pandas().reindex(columns=working.columns)

# ============================================================
# 2b. SYNTHESIZE -- MetaSyn
# ============================================================
metasyn_working = train_filled.copy()
mf = MetaFrame.fit_dataframe(metasyn_working)
metasyn_result = mf.synthesize(n=N)
metasyn_synth = (
    metasyn_result.to_pandas() if hasattr(metasyn_result, "to_pandas")
    else pd.DataFrame(metasyn_result)
)
metasyn_synth = metasyn_synth.reindex(columns=metasyn_working.columns)

# ============================================================
# 2c. SYNTHESIZE -- SynthCity (CTGAN, a GAN-based plugin --
#     structurally different from PyBNesian's CLG assumptions)
# ============================================================
loader = GenericDataLoader(train_filled, target_column="class")
synthcity_model = Plugins().get("ctgan")
synthcity_model.fit(loader)
synthcity_synth_loader = synthcity_model.generate(count=N)
synthcity_synth = synthcity_synth_loader.dataframe()

print(f"\nGenerated {N} synthetic rows from each of 3 backends.")
print(f"PyBNesian shape: {pybnesian_synth.shape}")
print(f"MetaSyn shape:   {metasyn_synth.shape}")
print(f"SynthCity shape: {synthcity_synth.shape}")

# ============================================================
# 3. MARGINAL + JOINT FIDELITY, computed per backend
# ============================================================
def marginal_fidelity(real_df, synth_df, cols):
    results = {}
    for col in cols:
        if col not in synth_df.columns:
            continue
        real_vals = real_df[col].dropna()
        synth_vals = synth_df[col].dropna()
        if len(real_vals) == 0 or len(synth_vals) == 0:
            continue
        if real_df[col].dtype.kind in "if":
            stat, p = ks_2samp(real_vals, synth_vals)
            results[col] = {
                "test": "KS", "stat": round(stat, 4), "p": round(p, 4),
                "real_mean": round(real_vals.mean(), 3),
                "synth_mean": round(synth_vals.mean(), 3),
            }
        else:
            real_counts = real_vals.value_counts()
            synth_counts = synth_vals.value_counts().reindex(real_counts.index, fill_value=0)
            try:
                contingency = pd.DataFrame({"real": real_counts, "synth": synth_counts})
                stat, p, _, _ = chi2_contingency(contingency.T)
                results[col] = {"test": "chi2", "stat": round(stat, 4), "p": round(p, 4)}
            except ValueError:
                pass
    return pd.DataFrame(results).T

def joint_fidelity(real_df, synth_df, numeric_cols):
    common = [c for c in numeric_cols if c in synth_df.columns]
    real_corr = real_df[common].corr()
    synth_corr = synth_df[common].corr()
    diff = (real_corr - synth_corr).abs()
    return {
        "mean_abs_corr_diff": round(np.nanmean(diff.values), 4),
        "max_abs_corr_diff": round(np.nanmax(diff.values), 4),
    }

numeric_cols = [c for c in train_filled.columns if train_filled[c].dtype.kind in "if"]

print("\n=== MARGINAL FIDELITY: al column specifically (the known weak point) ===")
for name, synth in [("PyBNesian", pybnesian_synth), ("MetaSyn", metasyn_synth),
                     ("SynthCity", synthcity_synth)]:
    mf_result = marginal_fidelity(train_filled, synth, ["al"])
    print(f"\n{name}:")
    print(mf_result)

print("\n=== JOINT FIDELITY (correlation structure) ===")
for name, synth in [("PyBNesian", pybnesian_synth), ("MetaSyn", metasyn_synth),
                     ("SynthCity", synthcity_synth)]:
    jf_result = joint_fidelity(train_filled, synth, numeric_cols)
    print(f"{name}: mean_abs_corr_diff={jf_result['mean_abs_corr_diff']}, "
          f"max_abs_corr_diff={jf_result['max_abs_corr_diff']}")

print("\n=== FULL MARGINAL FIDELITY TABLE, per backend ===")
for name, synth in [("PyBNesian", pybnesian_synth), ("MetaSyn", metasyn_synth),
                     ("SynthCity", synthcity_synth)]:
    print(f"\n--- {name} ---")
    full_result = marginal_fidelity(train_filled, synth, train_filled.columns)
    print(full_result.sort_values("p", ascending=True) if "p" in full_result.columns else full_result)

# save raw outputs for later use
pybnesian_synth.to_csv("compare_pybnesian_raw.csv", index=False)
metasyn_synth.to_csv("compare_metasyn_raw.csv", index=False)
synthcity_synth.to_csv("compare_synthcity_raw.csv", index=False)
