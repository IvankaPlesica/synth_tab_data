import gzip
import json
import pandas as pd
from rule_mining import missing_matrix, mine_apriori, mine_aerial, filter_rules, prune_redundant_rules, compressiveness

with gzip.open("../downloads-cache/uciml/336.csv.gz") as f:
    df = pd.read_csv(f)
M = missing_matrix(df)
print(f"Dataset: {df.shape[0]} rows, {M.shape[1]} columns with missing values")


'''
# mine and filter separately
rules_apriori = filter_rules(mine_apriori(M), M)
rules_aerial  = filter_rules(mine_aerial(M),  M)

print(f"\nApriori (before pruning): {len(rules_apriori)} rules")
print(f"Aerial  (before pruning): {len(rules_aerial)} rules")

# combine, deduplicate, then prune once across both
seen, rules_combined = set(), []
for r in rules_apriori + rules_aerial:
    key = (tuple(r["if_missing"]), r["then_missing"])
    if key not in seen:
        seen.add(key)
        rules_combined.append(r)

rules_combined = prune_redundant_rules(rules_combined)
print(f"Combined (after pruning): {len(rules_combined)} rules, compressiveness={compressiveness(rules_combined, M)}")

# show by source
for source in ("apriori", "aerial"):
    subset = [r for r in rules_combined if r["source"] == source]
    print(f"\n{source.title()}: {len(subset)} rules")
    for r in subset[:10]:
        extras = f" zhang={r['zhangs_metric']}" if "zhangs_metric" in r else ""
        print(f"  {r['if_missing']} → {r['then_missing']}  "
              f"sup={r['support']} conf={r['confidence']} lift={r['lift']}{extras}")

# uncovered rows
incomplete = M.any(axis=1)
covered    = pd.Series(False, index=M.index)
for r in rules_combined:
    covered |= M[r["if_missing"] + [r["then_missing"]]].all(axis=1)
for col in M.sum().sort_values(ascending=False).head(5).index:
    covered |= M[col]

uncovered = df[incomplete & ~covered]
print(f"\nUncovered incomplete rows: {len(uncovered)}")
if len(uncovered) > 0:
    print(M[incomplete & ~covered].sum().sort_values(ascending=False).head(10))

# save
with open("rules_combined.json", "w") as f:
    json.dump(rules_combined, f, indent=2)
print("\nSaved rules_combined.json")



import json
from rule_mining import stratified_mining

print("\nStratified mining by class:")
strat = stratified_mining(df, strata_col="class")
for stratum, res in strat.items():
    print(f"  {stratum}: {res['n_rows']} rows, "
          f"{len(res['rules'])} rules, "
          f"compressiveness={res['compressiveness']}")

with open("stratified_mining.json", "w") as f:
    json.dump(strat, f, indent=2)
print("Saved stratified_mining.json")
'''