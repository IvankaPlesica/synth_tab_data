import pandas as pd
import gzip
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PATH = os.path.join(SCRIPT_DIR, "..", "downloads-cache", "uciml", "46.csv.gz")

def load_hepatitis(path=DEFAULT_PATH):
    with gzip.open(path) as f:
        df = pd.read_csv(f)
    
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    
    return df