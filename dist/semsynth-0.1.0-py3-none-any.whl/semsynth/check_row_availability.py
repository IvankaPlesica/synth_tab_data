import pandas as pd
import numpy as np
from itertools import combinations

def check_row_availability(df, max_cov_size=5, n_samples=50):
    """Diagnostic: for random subsets of columns (simulating PKLM's random
    covariate projections), check how many rows have zero missing values
    in that column subset. If this is consistently very low, PKLM's
    internal sampling will have almost no usable rows per projection,
    which can degrade the test regardless of hyperparameters."""
    n_rows, n_cols = df.shape
    cols = df.columns.tolist()
    rng = np.random.default_rng()

    print(f"Subset: {n_rows} rows, {n_cols} columns")
    print(f"Fully complete rows overall (no missing at all): "
          f"{(df.notna().all(axis=1)).sum()} / {n_rows}")
    print()

    for cov_size in range(1, min(max_cov_size, n_cols) + 1):
        counts = []
        for _ in range(n_samples):
            chosen = rng.choice(cols, size=cov_size, replace=False)
            complete_rows = df[chosen].notna().all(axis=1).sum()
            counts.append(complete_rows)
        print(f"covariate set size {cov_size}: "
              f"mean complete rows = {np.mean(counts):.1f}, "
              f"min = {min(counts)}, max = {max(counts)} "
              f"(out of {n_rows} total)")


# --- usage ---
if __name__ == "__main__":
    # explained, mp_other should already exist from your pipeline
    print("=== explained ===")
    check_row_availability(explained)
    print("\n=== mp_other ===")
    check_row_availability(mp_other)