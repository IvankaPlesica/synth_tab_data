#!/usr/bin/env python3
import sys
import json
import nbformat
from nbformat import validate, ValidationError


def extract_notebook_metadata(path):
    nb = nbformat.read(path, as_version=4)

    summary = {
        "format": f"{nb.nbformat}.{nb.nbformat_minor}",
        "kernel": nb.metadata.get("kernelspec", {}),
        "language": nb.metadata.get("language_info", {}),
        "authors": nb.metadata.get("authors", []),
        "cell_count": len(nb.cells),
        "code_cells": 0,
        "markdown_cells": 0,
        "max_execution_count": 0,
        "all_tags": set(),
        "custom_metadata_keys": [],
    }

    known_keys = {"kernelspec", "language_info", "authors"}
    custom = set(nb.metadata.keys()) - known_keys
    summary["custom_metadata_keys"] = list(custom)

    for cell in nb.cells:
        if cell.cell_type == "code":
            summary["code_cells"] += 1
            ec = cell.get("execution_count") or 0
            summary["max_execution_count"] = max(
                summary["max_execution_count"], ec
            )
        elif cell.cell_type == "markdown":
            summary["markdown_cells"] += 1

        tags = cell.metadata.get("tags", [])
        summary["all_tags"].update(tags)

    summary["all_tags"] = list(summary["all_tags"])
    return nb, summary


def main():
    if len(sys.argv) != 2:
        print("Usage: python notebook_info.py <notebook.ipynb>")
        sys.exit(1)

    path = sys.argv[1]

    nb, summary = extract_notebook_metadata(path)

    try:
        validate(nb)
        print("✅ Notebook is valid\n")
    except ValidationError as e:
        print(f"❌ Validation failed: {e.message}\n")

    print(json.dumps(summary, indent=2, default=list))


if __name__ == "__main__":
    main()