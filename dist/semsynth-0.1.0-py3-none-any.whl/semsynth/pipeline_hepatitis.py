from load_hepatitis import load_hepatitis
from hepatitis_albi_staging import add_albi_columns
from Missingness_Model import MissingnessModel
from block_analysis import (
    block_rate_table
)


df = load_hepatitis()
df = add_albi_columns(df, export_path="hepatitis_with_albi.csv")

exclude_cols = ["class", "albi_score", "albi_grade", "albi_grade_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

rates = df_features.isnull().mean().sort_values(ascending=False)
print(rates)

model = MissingnessModel()
model.fit(df_features, min_support=0.06, min_any_confidence=0.6)

model.summary()


'''
# --- By class (Die / Live) ---
block_rate_table(df, df_features, model, "class",
                  [1, 2],
                  restrict_mask=df["class"].notna())
 
# --- By ALBI grade (1, 2, 3) ---
block_rate_table(df, df_features, model, "albi_grade",
                  [1, 2, 3],
                  restrict_mask=df["albi_grade"].notna())
 
# --- By ALBI grade category, including Pediatric/Unscorable ---
block_rate_table(df, df_features, model, "albi_grade_cat",
                  ["1", "2", "3", "Pediatric", "Unscorable"],
                  restrict_mask=df["albi_grade_cat"].notna())

print(df[["class"]].drop_duplicates())
# or check against the original UCI documentation / your load_hepatitis() function
print(df["class"].value_counts())



print("\nUnscorable patients by class:")
print(df[df["albi_grade_cat"] == "Unscorable"]["class"].value_counts())'''