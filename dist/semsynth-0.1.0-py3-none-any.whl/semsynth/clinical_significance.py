import pandas as pd
import numpy as np

# load data with patterns
df = pd.read_csv('/Users/goran/semsynth/semsynth/ckd_with_patterns.csv')
df = df.apply(lambda x: x.str.strip() if x.dtype == 'object' else x)
df["dm"] = df["dm"].replace("\tno", "no")
df["class"] = df["class"].replace("ckd\t", "ckd")

# compute egfr
def compute_egfr(row):
    sc  = pd.to_numeric(row["sc"],  errors="coerce")
    age = pd.to_numeric(row["age"], errors="coerce")
    if pd.isna(sc) or pd.isna(age) or sc <= 0:
        return float("nan")
    kappa = 0.8
    alpha = -0.27
    ratio = sc / kappa
    if ratio < 1:
        return round(142 * (ratio ** alpha) * (0.9938 ** age), 1)
    else:
        return round(142 * (ratio ** -1.200) * (0.9938 ** age), 1)

df["egfr"] = df.apply(compute_egfr, axis=1)

# assign ckd stage only for ckd patients
# df_ckd = df[df["class"] == "ckd"].copy()
df_ckd = df[(df["class"] == "ckd") & (df["age"] >= 18)].copy()
df_ckd["ckd_stage"] = pd.cut(
    df_ckd["egfr"],
    bins=[0, 15, 60, 999],
    labels=["late", "mid", "early"]
)

# triple comorbidity flag for all patients
df["triple"] = (
    (df["htn"] == "yes") &
    (df["dm"]  == "yes") &
    (df["cad"] == "yes")
)

# cross-tabulation: pattern vs ckd stage
print("Pattern distribution by CKD stage:")
print(pd.crosstab(
    df_ckd["missingness_pattern"],
    df_ckd["ckd_stage"],
    margins=True
))

print("\nPattern distribution by class (ckd vs notckd):")
print(pd.crosstab(
    df["missingness_pattern"],
    df["class"],
    margins=True
))

print("\nPattern distribution for triple comorbidity:")
print(pd.crosstab(
    df["missingness_pattern"],
    df["triple"],
    margins=True
))

print("\nMissingness rate per pattern:")
for pat in ['mp0', 'mp1', 'mp2', 'mp3', 'mp_other']:
    subset = df[df["missingness_pattern"] == pat]
    print(f"\n{pat} (n={len(subset)}):")
    miss = subset.isnull().mean()
    miss = miss[miss > 0].sort_values(ascending=False)
    miss = subset.drop(columns=["egfr"], errors="ignore").isnull().mean()
    print(miss.round(3).to_string())


    print("\neGFR calculation status for adult CKD patients:")
    df_ckd_adult = df[(df["class"] == "ckd") & (df["age"] >= 18)].copy()
    print(f"Adult CKD patients: {len(df_ckd_adult)}")
    print(f"eGFR calculable: {df_ckd_adult['egfr'].notna().sum()}")
    print(f"eGFR not calculable (missing sc or age): {df_ckd_adult['egfr'].isna().sum()}")
    print(f"\nOf those not calculable:")
    print(f"  Missing sc: {df_ckd_adult['sc'].isna().sum()}")
    print(f"  Missing age: {df_ckd_adult['age'].isna().sum()}")