"""Per-variable fidelity of the S1/S2 synthetic CKD datasets against the real data.

Compares ckd_synthetic_s1.csv and ckd_synthetic_s2.csv (both produced by
export_ckd_synthetic_datasets.py) against ckd_synthetic_b.csv (the real data,
unmodified -- see REPRODUCIBILITY_NOTES.md's canonical-artifacts table).

Reuses semsynth.metrics.per_variable_distances/summarize_distance_metrics --
the same distance metrics (KS/W1 for continuous, JSD for discrete) the
packaged PyBNesian backend reports in its own run metrics.json.

Also reports:
  - Dmis: L1 divergence between real and synthetic missingness-pattern (mp)
    distributions (Wang, Asif & Vaidya 2023, "Preserving Missing Data
    Distribution in Synthetic Data", Eq. 1) -- checks whether S1/S2
    reproduce the real mp0/block label frequencies, not just per-column
    value distributions.
  - mp_other-only fidelity: kept for backward compatibility, but with the
    simplified assign_pattern (no mp_other category), this subset will
    normally be empty -- see block_analysis.assign_pattern.

Outputs:
  fidelity_s1_vs_real.csv
  fidelity_s2_vs_real.csv
  fidelity_s2_mp_other_vs_real.csv
  printed summary + side-by-side per-variable table + Dmis + mp_other breakdown
"""

import pandas as pd

from dataset_registry import DATASET_REGISTRY
from semsynth.metrics import per_variable_distances, summarize_distance_metrics
from Missingness_Model import MissingnessModel
from block_analysis import assign_patterns

dataset_name = "ckd"
config = DATASET_REGISTRY[dataset_name]
categorical_cols = config["categorical_cols"]
min_support = config["min_support"]
min_any_confidence = config["min_any_confidence"]

real = pd.read_csv("ckd_synthetic_b.csv")
s1 = pd.read_csv("ckd_synthetic_s1.csv")
s2 = pd.read_csv("ckd_synthetic_s2.csv")

discrete_cols = categorical_cols + ["class"]
continuous_cols = [c for c in real.columns if c not in discrete_cols]

dist_s1 = per_variable_distances(real, s1, discrete_cols, continuous_cols)
dist_s2 = per_variable_distances(real, s2, discrete_cols, continuous_cols)

dist_s1.to_csv("fidelity_s1_vs_real.csv", index=False)
dist_s2.to_csv("fidelity_s2_vs_real.csv", index=False)

summary_s1 = summarize_distance_metrics(dist_s1)
summary_s2 = summarize_distance_metrics(dist_s2)

print("=== Summary (lower = closer to real) ===")
summary_df = pd.DataFrame({"S1": summary_s1, "S2": summary_s2})
print(summary_df.round(4))

print("\n=== Per-variable, side by side (sorted by worst S2 score) ===")
score_s1 = dist_s1.set_index("variable")["KS"].fillna(dist_s1.set_index("variable")["JSD"])
score_s2 = dist_s2.set_index("variable")["KS"].fillna(dist_s2.set_index("variable")["JSD"])
combined = pd.DataFrame({
    "type": dist_s1.set_index("variable")["type"],
    "S1_score": score_s1,
    "S2_score": score_s2,
}).sort_values("S2_score", ascending=False)
print(combined.round(4).to_string())

print("\nSaved fidelity_s1_vs_real.csv, fidelity_s2_vs_real.csv")


# ============================================================
# mp-distribution divergence (Dmis) -- real vs S1 vs S2 pattern-label rates
# ============================================================

def compute_dmis(real_labels, synth_labels):
    """L1 divergence between two mp-distributions (Eq. 1, Wang et al. 2023)."""
    real_rates = real_labels.value_counts(normalize=True)
    synth_rates = synth_labels.value_counts(normalize=True)
    all_labels = set(real_rates.index) | set(synth_rates.index)
    return sum(
        abs(real_rates.get(m, 0.0) - synth_rates.get(m, 0.0))
        for m in all_labels
    )

feature_cols = [c for c in real.columns if c not in ("class",)]
mining_model = MissingnessModel().fit(
    real[feature_cols], min_support=min_support, min_any_confidence=min_any_confidence
)

real_labels = assign_patterns(real[feature_cols], mining_model)
s1_labels = assign_patterns(s1[feature_cols], mining_model)
s2_labels = assign_patterns(s2[feature_cols], mining_model)

dmis_s1 = compute_dmis(real_labels, s1_labels)
dmis_s2 = compute_dmis(real_labels, s2_labels)

print("\n=== mp-distribution divergence (Dmis, lower = closer to real) ===")
print(f"S1: {dmis_s1:.4f}")
print(f"S2: {dmis_s2:.4f}")

print("\nPattern label rates -- real vs S1 vs S2:")
label_rates = pd.DataFrame({
    "real": real_labels.value_counts(normalize=True),
    "S1": s1_labels.value_counts(normalize=True),
    "S2": s2_labels.value_counts(normalize=True),
}).fillna(0.0).round(4)
print(label_rates.sort_values("real", ascending=False).to_string())


# ============================================================
# mp_other-only fidelity (see docstring -- normally empty now)
# ============================================================

real_mp_other = real.loc[(real_labels == "mp_other").values]
s2_mp_other = s2.loc[(s2_labels == "mp_other").values]

print(f"\n=== mp_other subset sizes: real={len(real_mp_other)}, S2={len(s2_mp_other)} ===")

if len(real_mp_other) > 0 and len(s2_mp_other) > 0:
    dist_s2_mp_other = per_variable_distances(
        real_mp_other, s2_mp_other, discrete_cols, continuous_cols
    )
    dist_s2_mp_other.to_csv("fidelity_s2_mp_other_vs_real.csv", index=False)

    print("\n=== S2 mp_other-only fidelity (lower = closer to real mp_other rows) ===")
    score_s2_mp_other = dist_s2_mp_other.set_index("variable")["KS"].fillna(
        dist_s2_mp_other.set_index("variable")["JSD"]
    )
    print(score_s2_mp_other.sort_values(ascending=False).round(4).to_string())

    print("\nSaved fidelity_s2_mp_other_vs_real.csv")
else:
    print("Skipping mp_other-only comparison -- one side has zero mp_other rows.")