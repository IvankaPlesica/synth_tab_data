import pandas as pd
import sys
sys.path.insert(0, '/Users/goran/semsynth/semsynth')

from MCAR_missingness_PKLM import pklm_test

# load dataset with patterns already assigned
df_patterns = pd.read_csv(
    '/Users/goran/semsynth/semsynth/ckd_with_patterns.csv')

print("Columns:", df_patterns.columns.tolist())
print("Pattern column values:")
# find the pattern column
for col in df_patterns.columns:
    if 'pattern' in col.lower() or 'mp' in col.lower():
        print(f"  {col}:", df_patterns[col].value_counts().to_dict())