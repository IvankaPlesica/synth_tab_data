"""Standalone experiment (hepatitis only): does the singling-out attack-rate
gap (subgroup vs non-subgroup) computed PER FOLD -- using only that fold's
own attacked_rows() result, restricted to that fold's own control (test)
rows -- roughly agree with the existing pooled gap (computed once over
so_attacked_mask across the whole dataset)?

Note on what's actually "per-fold" already vs. what changes here: the main
pipeline already runs SinglingOutEvaluator + attacked_rows() separately per
fold (each fold attacks its own X_train/X_test split). What's pooled today is
only the AGGREGATION step -- so_attacked_mask accumulates every fold's hits
into one dataset-wide boolean array, and subgroup/non-subgroup attack rates
are computed once at the end over the whole dataset. This script keeps each
fold's attacked_rows() result separate and computes the subgroup/non-subgroup
rate immediately on that fold's own (small) control set, instead of waiting
to pool first.

Read-only against the real pipeline: does NOT import
evaluate_ckd_missingness_strategies_full.py (flat script, no __main__ guard --
importing it would re-run the whole pipeline and overwrite
metrics_history.csv / subgroup_metadata.json / pipeline_metadata.json).
Everything else is imported from the real modules the main pipeline itself
uses: imputation, shadow_columns, synthesis, pattern_missingness,
Missingness_Model, dataset_registry, frozen_outlier_rule, subgroup_privacy_oof.

REQUIRES outlier_rule.joblib in this directory to already be the hepatitis
version (frozen_outlier_rule.py loads it once at import time) -- same
requirement as the main pipeline.

Caveat carried over from the main pipeline: anonymeter's internal RNG is
unseeded, so absolute attack numbers are not reproducible run-to-run even at
fixed --seed; only look at the general shape/scale of results, not exact
figures.

Writes nothing to any pipeline output file; only prints and saves its own
experiment_per_fold_privacy_results.json.
"""
import json

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from anonymeter.evaluators import SinglingOutEvaluator

from imputation import simple_impute
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
from Missingness_Model import MissingnessModel
from dataset_registry import DATASET_REGISTRY
from frozen_outlier_rule import apply_outlier_rule
from subgroup_privacy_oof import attacked_rows

DATASET_NAME = "hepatitis"
SEED = 42

SUBGROUP_DEFS = [
    ("outlier", apply_outlier_rule),
    ("age>=50", lambda d: (d["age"] >= 50).to_numpy()),
]


def fmt(v, spec=".3f"):
    return format(v, spec) if v is not None else "n/a"


def main():
    config = DATASET_REGISTRY[DATASET_NAME]
    df = config["loader"]()
    n_splits = config["n_splits"]
    positive_label = config["positive_label"]
    categorical_cols = config["categorical_cols"]
    min_support = config["min_support"]
    min_any_confidence = config["min_any_confidence"]

    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=SEED)

    # Pooled reference accumulator -- same pattern as the main pipeline: one
    # boolean slot per real row, filled in across folds.
    so_attacked_mask_pooled = {
        "S1": pd.Series(False, index=df.index),
        "S2": pd.Series(False, index=df.index),
    }

    per_fold = {
        "S1": {name: [] for name, _ in SUBGROUP_DEFS},
        "S2": {name: [] for name, _ in SUBGROUP_DEFS},
    }

    for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
        print(f"Fold {fold_num + 1}/{n_splits}...")
        X_train = X.iloc[train_index].copy()
        X_test = X.iloc[test_index].copy()
        y_train = (y.iloc[train_index] == positive_label).astype(int)

        X_train_filled = simple_impute(X_train)

        # S1
        shadow_cols = build_shadow_columns(X_train)
        synth_features_with_shadows, _ = synthesize(
            X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols, seed=SEED
        )
        s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)

        # S2
        mining_model = MissingnessModel().fit(
            X_train, min_support=min_support, min_any_confidence=min_any_confidence
        )
        s2_features, _ = run_s2_branch(
            X_train, X_train_filled, y_train, categorical_cols, mining_model, seed=SEED
        )

        fold_masks = {name: mask_fn(X_test) for name, mask_fn in SUBGROUP_DEFS}

        for branch, synth_features in [("S1", s1_features), ("S2", s2_features)]:
            n_attacks = min(500, len(X_train))
            so_eval = SinglingOutEvaluator(
                ori=X_train, syn=synth_features, control=X_test, n_attacks=n_attacks
            )
            so_eval.evaluate(mode="multivariate")
            hits = attacked_rows(X_test, so_eval.queries())

            # Fold-local attacked boolean, indexed to this fold's control set only.
            fold_attacked = pd.Series(False, index=X_test.index)
            if hits:
                fold_attacked.loc[list(hits)] = True
                so_attacked_mask_pooled[branch].loc[list(hits)] = True

            fold_attacked_arr = fold_attacked.to_numpy()
            for name, mask in fold_masks.items():
                n_sub, n_non = int(mask.sum()), int((~mask).sum())
                sub_rate = float(fold_attacked_arr[mask].mean()) if n_sub else None
                non_rate = float(fold_attacked_arr[~mask].mean()) if n_non else None
                gap = (sub_rate - non_rate) if (sub_rate is not None and non_rate is not None) else None
                per_fold[branch][name].append({
                    "fold": fold_num,
                    "n_subgroup": n_sub,
                    "n_non_subgroup": n_non,
                    "subgroup_attack_rate": sub_rate,
                    "non_subgroup_attack_rate": non_rate,
                    "gap": gap,
                })

    # Pooled reference, computed the same way the main pipeline does: mask the
    # fully-accumulated so_attacked_mask over the WHOLE dataset.
    pooled = {"S1": {}, "S2": {}}
    for branch in ["S1", "S2"]:
        attacked_arr = so_attacked_mask_pooled[branch].to_numpy()
        for name, mask_fn in SUBGROUP_DEFS:
            mask = mask_fn(df)
            n_sub, n_non = int(mask.sum()), int((~mask).sum())
            sub_rate = float(attacked_arr[mask].mean()) if n_sub else None
            non_rate = float(attacked_arr[~mask].mean()) if n_non else None
            gap = (sub_rate - non_rate) if (sub_rate is not None and non_rate is not None) else None
            pooled[branch][name] = {
                "n_subgroup": n_sub,
                "n_non_subgroup": n_non,
                "subgroup_attack_rate": sub_rate,
                "non_subgroup_attack_rate": non_rate,
                "gap": gap,
            }

    # ---- report ----
    print("\n" + "=" * 70)
    print(f"Per-fold vs pooled singling-out attack-rate gap ({DATASET_NAME})")
    print("NOTE: anonymeter's rng is unseeded -- absolute numbers vary run-to-run.")
    print("=" * 70)

    summary = {"dataset": DATASET_NAME, "n_splits": n_splits, "per_fold": per_fold, "pooled": pooled,
               "gap_summary": {"S1": {}, "S2": {}}}
    for branch in ["S1", "S2"]:
        print(f"\n=== {branch} ===")
        for name, _ in SUBGROUP_DEFS:
            print(f"\n--- subgroup: {name} ---")
            gaps = []
            for r in per_fold[branch][name]:
                print(f"  fold {r['fold']}: subgroup_rate={fmt(r['subgroup_attack_rate'])} (n={r['n_subgroup']}), "
                      f"non_subgroup_rate={fmt(r['non_subgroup_attack_rate'])} (n={r['n_non_subgroup']}), "
                      f"gap={fmt(r['gap'], '+.3f')}")
                if r["gap"] is not None:
                    gaps.append(r["gap"])
            gap_mean = float(np.mean(gaps)) if gaps else None
            gap_std = float(np.std(gaps)) if gaps else None
            print(f"  per-fold gap mean +/- std: {fmt(gap_mean, '+.3f')} +/- {fmt(gap_std)}")
            p = pooled[branch][name]
            print(f"  pooled (original method): subgroup_rate={fmt(p['subgroup_attack_rate'])}, "
                  f"non_subgroup_rate={fmt(p['non_subgroup_attack_rate'])}, gap={fmt(p['gap'], '+.3f')}")
            summary["gap_summary"][branch][name] = {
                "per_fold_gap_mean": gap_mean,
                "per_fold_gap_std": gap_std,
                "pooled_gap": p["gap"],
            }

    out_path = "experiment_per_fold_privacy_results.json"
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nSaved full results to {out_path}")


if __name__ == "__main__":
    main()
