"""Loads the frozen outlier rule saved by simple_subgroups.py's joblib.dump and
exposes apply_outlier_rule() for scoring new data with it. Extracted out of
oof_pooling.py (where this was first written) so subgroup_privacy_oof.py -- and
anything else that needs the same rule -- imports it instead of duplicating it.
Never refits anything here; encoder/scaler/kmeans/cutoffs are all loaded as-is.
"""

import numpy as np
import joblib
from sklearn.tree import export_text

saved = joblib.load("outlier_rule.joblib")
encoder = saved["encoder"]
cat_cols = saved["cat_cols"]
kmeans = saved["kmeans"]
scaler = saved["scaler"]
medians = saved["medians"]
modes = saved["modes"]
num_cols = saved["num_cols"]
cluster_cutoffs = saved["cluster_cutoffs"]
outlier_tree = saved["outlier_tree"]


def apply_outlier_rule(df):
    """Exact distance-based outlier rule (matches simple_subgroups.py's Step 1d) --
    frozen encoder/scaler/kmeans/cutoffs applied via transfer, no refitting. Only
    valid for real data (rows the frozen imputation/encoder/kmeans pipeline was fit
    on the same distribution as); never scores synthetic rows with it."""
    df = df.drop(columns=["class"], errors="ignore").copy()
    df[cat_cols] = df[cat_cols].astype("object")
    df[num_cols] = df[num_cols].fillna(medians)
    df[cat_cols] = df[cat_cols].fillna(modes)
    scaled = scaler.transform(encoder.transform(df))
    labels = kmeans.predict(scaled)
    distances = np.linalg.norm(scaled - kmeans.cluster_centers_[labels], axis=1)
    cutoffs = np.array([cluster_cutoffs[label] for label in labels])
    return distances > cutoffs


def explain_outlier_rule():
    """Human-readable decision-tree approximation (~97% fidelity) of the rule
    above, for reporting only -- apply_outlier_rule() never uses this tree to
    score anything, see simple_subgroups.py."""
    return export_text(outlier_tree, feature_names=encoder.feature_names_)
