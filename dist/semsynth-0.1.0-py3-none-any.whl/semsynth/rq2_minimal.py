"""Standalone RQ2 skeleton for CKD: Branch R vs S1 (shadow columns, 1:1) vs S2 (shadow patterns).

The only thing borrowed from the semsynth package is the actual PyBNesian model
call (learn_bn + a handful of dtype-coercion helpers). No pipeline.py, no TOML
config, no other backend is touched.

Missingness handling, simplified:
- Pre-synthesis "address missingness": plain median (numeric) / mode (categorical)
  fill on the real training data, before it goes into the synthesizer.
- S1 "shadow columns": each column's real missingness mask is transplanted
  1:1, row-index to row-index, onto the synthetic data -- independently per
  column, no randomness, no resampling.
- S2 "shadow patterns": missingness_pattern is fit on real training data,
  carried INTO the synthesizer as a real variable (same treatment as class),
  so the synthesizer generates its own synthetic pattern label per row. For
  block-member columns, that label deterministically blanks the whole block
  together (preserving co-occurrence); for independent columns, real overall
  rates are reinserted the same simple way as before.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer

from load_ckd import load_ckd
from egfr_staging import add_egfr_columns
from Missingness_Model import MissingnessModel
from block_analysis import assign_patterns

from semsynth.backends.pybnesian import learn_bn
from semsynth.utils import (
    infer_types,
    coerce_discrete_to_category,
    coerce_continuous_to_float,
    rename_categorical_categories_to_str,
)

# ============================================================
# 1. LOAD DATA
# ============================================================
df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
df["class"] = df["class"].str.strip()

exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

# ============================================================
# 2. SPLIT
# ============================================================
y_all = (df["class"] == "ckd").astype(int)
train_idx, test_idx = train_test_split(
    df.index, test_size=0.2, random_state=42, stratify=y_all
)

train_df = df.loc[train_idx].reset_index(drop=True)
test_df = df.loc[test_idx].reset_index(drop=True)

train_features = train_df[df_features.columns]
test_features = test_df[df_features.columns]
train_y = (train_df["class"] == "ckd").astype(int)
test_y = (test_df["class"] == "ckd").astype(int)

# ============================================================
# 3. SHARED SCORING FUNCTION
# ============================================================
def score_branch(X_train, y_train, X_test, y_test):
    cat_cols = X_train.select_dtypes(include=["object", "category"]).columns.tolist()
    X_train_enc = pd.get_dummies(X_train, columns=cat_cols, dummy_na=False)
    X_test_enc = pd.get_dummies(X_test, columns=cat_cols, dummy_na=False)
    X_test_enc = X_test_enc.reindex(columns=X_train_enc.columns, fill_value=0)

    imputer = IterativeImputer(max_iter=10, random_state=42)
    X_train_imp = imputer.fit_transform(X_train_enc)
    X_test_imp = imputer.transform(X_test_enc)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_imp)
    X_test_scaled = scaler.transform(X_test_imp)

    model = LogisticRegression(max_iter=5000, random_state=42)
    model.fit(X_train_scaled, y_train)
    proba = model.predict_proba(X_test_scaled)[:, 1]
    return round(roc_auc_score(y_test, proba), 4)

# ============================================================
# 4. BRANCH R -- baseline
# ============================================================
score_r = score_branch(train_features, train_y, test_features, test_y)
print(f"Score R (baseline): {score_r}")

# ============================================================
# 5a. FIT MISSINGNESS PATTERN + DERIVE BLOCK DEFINITIONS
#     (needed for S2; S1 no longer needs the independent rates)
# ============================================================
missingness_model = MissingnessModel().fit(
    train_features, min_support=0.1, min_any_confidence=0.7
)
train_df["missingness_pattern"] = assign_patterns(train_features, missingness_model)

def derive_block_definitions(real_train_features, real_patterns, threshold=0.9):
    block_definitions = {}
    for label in real_patterns.unique():
        rows_with_label = real_train_features[real_patterns == label]
        miss_rate = rows_with_label.isnull().mean()
        block_definitions[label] = miss_rate[miss_rate > threshold].index.tolist()
    return block_definitions

block_definitions = derive_block_definitions(
    train_features, train_df["missingness_pattern"], threshold=0.9
)

block_member_cols = set()
for cols in block_definitions.values():
    block_member_cols.update(cols)

independent_cols = [c for c in train_features.columns if c not in block_member_cols]
independent_rates = train_features[independent_cols].isnull().mean()

# ============================================================
# 5b. SYNTHESIZE -- PyBNesian
#     ("address missingness" step: plain median/mode fill, then learn_bn)
# ============================================================
bn_input_cols = [
    c for c in train_df.columns
    if c not in ("egfr_star", "ckd_stage", "ckd_stage_cat")
]
train_bn_input = train_df[bn_input_cols]

train_bn_filled = train_bn_input.fillna(train_bn_input.median(numeric_only=True))
for col in train_bn_filled.select_dtypes(include="object").columns:
    mode_vals = train_bn_filled[col].mode()
    if not mode_vals.empty:
        train_bn_filled[col] = train_bn_filled[col].fillna(mode_vals.iloc[0])

working = train_bn_filled.copy()
disc_cols, cont_cols = infer_types(working)
working = coerce_discrete_to_category(working, disc_cols)
working = rename_categorical_categories_to_str(working, disc_cols)
working = coerce_continuous_to_float(working, cont_cols)

bn_art = learn_bn(working, bn_type="clg", random_state=42, arc_blacklist=[])
synth = bn_art.model.sample(len(working), seed=42)
synth_df = synth.to_pandas().reindex(columns=working.columns)
for c in disc_cols:
    if c in synth_df.columns:
        synth_df[c] = synth_df[c].astype("category")

synth_label = (synth_df["class"].astype(str) == "ckd").astype(int)
synth_pattern_labels = synth_df["missingness_pattern"].astype(str)
synth_features = synth_df.drop(columns=["class", "missingness_pattern"])

synth_df.to_csv("rq2_synthetic_raw.csv", index=False)

# ============================================================
# 6. BRANCH S1 -- shadow COLUMNS, 1:1 transplant (no resampling)
# ============================================================
def reinsert_shadow_columns_1to1(synth_features, real_train_features):
    """
    Directly transplants each column's real missingness mask onto the
    synthetic data, row-index to row-index. No resampling, no randomness --
    if real row i is missing 'sod', synthetic row i is missing 'sod' too.
    Applied independently per column, so cross-column co-occurrence in the
    real data is NOT preserved here (that's what S2 is for).
    """
    out = synth_features.copy().reset_index(drop=True)
    real_reset = real_train_features.reset_index(drop=True)

    n = min(len(out), len(real_reset))
    for col in real_reset.columns:
        if col not in out.columns:
            continue
        mask = real_reset[col].isnull().iloc[:n]
        out.loc[mask[mask].index, col] = np.nan

    return out

s1_features = reinsert_shadow_columns_1to1(synth_features, train_features)
score_s1 = score_branch(s1_features, synth_label, test_features, test_y)
print(f"Score S1 (shadow columns, 1:1): {score_s1}")

# ============================================================
# 7. BRANCH S2 -- shadow PATTERNS: read the synthetic pattern name, blank
#    exactly the columns that pattern implies (block-member columns), plus
#    simple independent reinsertion for non-block columns.
# ============================================================
def reinsert_hybrid_patterns(
    synth_features, synth_pattern_labels, block_definitions,
    independent_cols, independent_rates, seed=42
):
    rng = np.random.default_rng(seed)
    out = synth_features.copy()

    # deterministic block-level reinsertion
    for i, label in enumerate(synth_pattern_labels):
        cols_to_blank = block_definitions.get(label, [])
        for col in cols_to_blank:
            if col in out.columns:
                out.iloc[i, out.columns.get_loc(col)] = np.nan

    # independent per-column reinsertion for non-block columns
    for col in independent_cols:
        if col not in out.columns:
            continue
        rate = independent_rates.get(col, 0)
        mask = rng.random(len(out)) < rate
        out.loc[mask, col] = np.nan

    return out

s2_features = reinsert_hybrid_patterns(
    synth_features, synth_pattern_labels, block_definitions,
    independent_cols, independent_rates, seed=42
)
score_s2 = score_branch(s2_features, synth_label, test_features, test_y)
print(f"Score S2 (shadow patterns): {score_s2}")

# ============================================================
# SAVE OUTPUTS
# ============================================================
s1_with_label = s1_features.copy()
s1_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s1_with_label.to_csv("rq2_synthetic_s1.csv", index=False)

s2_with_label = s2_features.copy()
s2_with_label["class"] = synth_label.map({1: "ckd", 0: "notckd"})
s2_with_label.to_csv("rq2_synthetic_s2.csv", index=False)

# ============================================================
# 8. RESULTS
# ============================================================
print("\n--- RQ2 skeleton results ---")
print(f"Score R : {score_r}")
print(f"Score S1: {score_s1}")
print(f"Score S2: {score_s2}")