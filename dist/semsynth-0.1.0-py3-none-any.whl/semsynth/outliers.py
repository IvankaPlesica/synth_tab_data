"""Outlier subgroup detection and characterization for tabular data."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

try:
    from makeprov.config import Config as _Config
except ImportError:  # pragma: no cover
    _Config = object  # type: ignore[assignment, misc]

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class OutlierConfig(_Config):
    """Parameters controlling outlier subgroup detection.

    Attributes:
        detector: Algorithm to use – ``"isolation_forest"`` or ``"lof"``.
        contamination: Expected fraction of outliers used to set the decision threshold.
        n_estimators: Number of trees for Isolation Forest.
        n_neighbors: Neighbourhood size for LOF.
        subgroup_min_samples: Minimum cluster size passed to DBSCAN.
        subgroup_eps: Epsilon radius passed to DBSCAN (in standardised space).
        top_n_features: Number of top distinguishing features to report per subgroup.
        rule_depth: Maximum depth of the characterizing decision tree.
        random_state: Seed for reproducible results.
    """

    detector: str = "lof"
    contamination: float = 0.05
    n_estimators: int = 100
    n_neighbors: int = 20
    subgroup_min_samples: int = 5
    subgroup_eps: float = 0.5
    top_n_features: int = 5
    rule_depth: int = 3
    random_state: int = 42


# ---------------------------------------------------------------------------
# Encoding
# ---------------------------------------------------------------------------

def _make_ohe(**kwargs: Any) -> Any:
    """Return a OneHotEncoder handling the sparse/sparse_output API change."""
    from sklearn.preprocessing import OneHotEncoder

    try:
        return OneHotEncoder(**kwargs, sparse_output=False)
    except TypeError:
        return OneHotEncoder(**kwargs, sparse=False)


def _merge_inferred(df: pd.DataFrame, inferred: Optional[Dict[str, str]]) -> Dict[str, str]:
    """Build a complete column-type map by merging caller-supplied hints with dtype inference."""
    result: Dict[str, str] = {}
    for col in df.columns:
        if inferred and col in inferred:
            result[col] = inferred[col]
        elif pd.api.types.is_numeric_dtype(df[col]):
            result[col] = "continuous"
        else:
            result[col] = "discrete"
    return result


def _encode_frame(df: pd.DataFrame, inferred: Dict[str, str]) -> np.ndarray:
    """Numerically encode a mixed-type DataFrame for distance-based computation.

    For each column with missing values a binary shadow column (``1`` = missing,
    ``0`` = present) is appended before encoding, then the original column is
    imputed with its median (numeric) or mode (categorical).

    Args:
        df: Input DataFrame.
        inferred: Mapping of column names to ``"continuous"`` or ``"discrete"``.

    Returns:
        2-D NumPy array with numeric columns standardised and categorical columns
        one-hot encoded. Shadow columns are included as standardised binary numerics.

    Raises:
        ValueError: When no columns are available after filtering.
    """

    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    missing_cols = [c for c in df.columns if df[c].isna().any()]
    if missing_cols:
        shadow = df[missing_cols].isna().astype(float)
        shadow.columns = pd.Index([f"__missing__{c}" for c in missing_cols])
        df = pd.concat([df, shadow], axis=1)
        LOGGER.debug("Added %d shadow column(s) for missingness: %s", len(missing_cols), missing_cols)

    shadow_cols = [c for c in df.columns if c.startswith("__missing__")]
    num_cols = [
        c for c in df.columns
        if inferred.get(c, "continuous") == "continuous" and c not in shadow_cols
    ]
    cat_cols = [
        c for c in df.columns
        if inferred.get(c, "continuous") != "continuous" and c not in shadow_cols
    ]

    transformers = []
    if num_cols:
        transformers.append((
            "num",
            Pipeline([
                ("imp", SimpleImputer(strategy="median")),
                ("scl", StandardScaler()),
            ]),
            num_cols,
        ))
    if cat_cols:
        transformers.append((
            "cat",
            Pipeline([
                ("imp", SimpleImputer(strategy="most_frequent")),
                ("ohe", _make_ohe(handle_unknown="ignore")),
            ]),
            cat_cols,
        ))
    if shadow_cols:
        from sklearn.preprocessing import FunctionTransformer
        transformers.append((
            "shadow",
            FunctionTransformer(validate=False),
            shadow_cols,
        ))

    if not transformers:
        raise ValueError("No columns available for encoding")

    return ColumnTransformer(transformers, remainder="drop").fit_transform(df)


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

def _fit_detector(X: np.ndarray, cfg: OutlierConfig) -> tuple[np.ndarray, np.ndarray]:
    """Fit an anomaly detector and return per-row labels and scores.

    Args:
        X: Encoded feature matrix.
        cfg: Detector configuration.

    Returns:
        Tuple of ``(labels, scores)`` where labels are ``1`` for inliers and
        ``-1`` for outliers; lower scores indicate more anomalous rows.
    """

    if cfg.detector == "lof":
        from sklearn.neighbors import LocalOutlierFactor

        clf = LocalOutlierFactor(
            n_neighbors=cfg.n_neighbors,
            contamination=cfg.contamination,
        )
        labels: np.ndarray = clf.fit_predict(X)
        scores: np.ndarray = clf.negative_outlier_factor_
    else:
        from sklearn.ensemble import IsolationForest

        clf = IsolationForest(
            n_estimators=cfg.n_estimators,
            contamination=cfg.contamination,
            random_state=cfg.random_state,
        )
        labels = clf.fit_predict(X)
        scores = clf.score_samples(X)

    return labels, scores


# ---------------------------------------------------------------------------
# Subgroup discovery
# ---------------------------------------------------------------------------

def _discover_subgroups(
    outlier_X: np.ndarray,
    outlier_scores: np.ndarray,
    cfg: OutlierConfig,
) -> np.ndarray:
    """Cluster outlier rows with DBSCAN in augmented feature + score space.

    Args:
        outlier_X: Encoded feature matrix for outlier rows only.
        outlier_scores: Anomaly scores for outlier rows.
        cfg: Subgroup discovery parameters.

    Returns:
        Integer cluster assignment per outlier row. Rows below the minimum
        cluster size are grouped into a catch-all cluster instead of noise.
    """

    from sklearn.cluster import DBSCAN

    if len(outlier_X) < cfg.subgroup_min_samples:
        return np.zeros(len(outlier_X), dtype=int)

    score_scaled = (outlier_scores - outlier_scores.mean()) / (outlier_scores.std() + 1e-9)
    aug = np.hstack([outlier_X, score_scaled.reshape(-1, 1)])
    raw = DBSCAN(eps=cfg.subgroup_eps, min_samples=cfg.subgroup_min_samples).fit_predict(aug)
    next_id = int(raw.max()) + 1
    raw = np.where(raw == -1, next_id, raw)
    return raw


# ---------------------------------------------------------------------------
# Subgroup characterization
# ---------------------------------------------------------------------------

def _characterize_subgroup(
    subgroup_df: pd.DataFrame,
    baseline_df: pd.DataFrame,
    inferred: Dict[str, str],
    top_n: int,
) -> tuple[Dict[str, Any], List[str]]:
    """Compute per-feature deviation statistics for a subgroup vs. inlier baseline.

    Args:
        subgroup_df: Rows belonging to the subgroup.
        baseline_df: Inlier rows used as the reference population.
        inferred: Column type mapping.
        top_n: Number of top features to surface.

    Returns:
        Tuple of a feature-keyed summary dict and the ranked top feature names.
    """

    feature_summary: Dict[str, Any] = {}
    deviations: Dict[str, float] = {}

    for col in subgroup_df.columns:
        sg = subgroup_df[col].dropna()
        bl = baseline_df[col].dropna()
        if sg.empty or bl.empty:
            continue

        if inferred.get(col, "continuous") == "continuous":
            try:
                sg_vals = pd.to_numeric(sg, errors="coerce").dropna()
                bl_vals = pd.to_numeric(bl, errors="coerce").dropna()
                if sg_vals.empty or bl_vals.empty:
                    continue
                sg_mean = float(sg_vals.mean())
                bl_mean = float(bl_vals.mean())
                z = abs(sg_mean - bl_mean) / (float(bl_vals.std()) + 1e-9)
                feature_summary[col] = {
                    "type": "numeric",
                    "subgroup_mean": round(sg_mean, 4),
                    "baseline_mean": round(bl_mean, 4),
                    "z_score": round(z, 4),
                }
                deviations[col] = z
            except Exception:
                continue
        else:
            try:
                sg_mode = sg.mode()
                if sg_mode.empty:
                    continue
                top_val = str(sg_mode.iloc[0])
                sg_rate = float((sg.astype(str) == top_val).mean())
                bl_rate = float((bl.astype(str) == top_val).mean())
                feature_summary[col] = {
                    "type": "categorical",
                    "subgroup_mode": top_val,
                    "subgroup_mode_rate": round(sg_rate, 4),
                    "baseline_mode_rate": round(bl_rate, 4),
                    "deviation": round(abs(sg_rate - bl_rate), 4),
                }
                deviations[col] = abs(sg_rate - bl_rate)
            except Exception:
                continue

    top_features = sorted(deviations, key=lambda k: deviations[k], reverse=True)[:top_n]
    return feature_summary, top_features


def _fit_subgroup_lr(
    subgroup_df: pd.DataFrame,
    inlier_df: pd.DataFrame,
    inferred: Dict[str, str],
    top_n: int,
    random_state: int,
    exclude_cols: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Train a logistic regression to predict subgroup membership vs. inliers.

    Args:
        subgroup_df: Rows belonging to the subgroup (positive class).
        inlier_df: All inlier rows (negative class).
        inferred: Column type mapping used for encoding.
        top_n: Number of top-weighted features to include in the summary.
        random_state: Seed for the classifier.
        exclude_cols: Column names to drop before encoding (e.g. outcome labels).

    Returns:
        Dict with ``top_features`` (list of ``{feature, coefficient}`` dicts
        ranked by |coefficient|) and ``train_accuracy``, or an empty dict when
        fitting is not possible.
    """

    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    if len(subgroup_df) < 2 or len(inlier_df) < 2:
        return {}

    combined = pd.concat(
        [inlier_df.assign(_lbl=0), subgroup_df.assign(_lbl=1)], ignore_index=True
    )
    y = combined["_lbl"].values
    X_df = combined.drop(columns="_lbl")
    if exclude_cols:
        X_df = X_df.drop(columns=[c for c in exclude_cols if c in X_df.columns])

    num_cols = [c for c in X_df.columns if inferred.get(c, "continuous") == "continuous"]
    cat_cols = [c for c in X_df.columns if inferred.get(c, "continuous") != "continuous"]

    transformers = []
    feature_names: List[str] = []
    if num_cols:
        transformers.append((
            "num",
            Pipeline([
                ("imp", SimpleImputer(strategy="median")),
                ("scl", StandardScaler()),
            ]),
            num_cols,
        ))
        feature_names.extend(num_cols)
    if cat_cols:
        transformers.append((
            "cat",
            Pipeline([
                ("imp", SimpleImputer(strategy="most_frequent")),
                ("ohe", _make_ohe(handle_unknown="ignore")),
            ]),
            cat_cols,
        ))

    if not transformers:
        return {}

    try:
        ct = ColumnTransformer(transformers, remainder="drop")
        X_enc = ct.fit_transform(X_df)
    except Exception as exc:
        LOGGER.warning("LR encoder failed: %s", exc)
        return {}

    # Build full feature name list including OHE expansions
    if cat_cols:
        try:
            ohe = ct.named_transformers_["cat"].named_steps["ohe"]
            for col, cats in zip(cat_cols, ohe.categories_):
                feature_names.extend(f"{col}={c}" for c in cats)
        except Exception:
            feature_names.extend([f"cat_{i}" for i in range(X_enc.shape[1] - len(num_cols))])

    try:
        clf = LogisticRegression(
            class_weight="balanced", max_iter=500, random_state=random_state
        )
        clf.fit(X_enc, y)
    except Exception as exc:
        LOGGER.warning("LR fitting failed: %s", exc)
        return {}

    coefs = clf.coef_[0]
    n_feat = min(len(feature_names), len(coefs))
    ranked = sorted(range(n_feat), key=lambda i: abs(coefs[i]), reverse=True)[:top_n]

    return {
        "top_features": [
            {"feature": feature_names[i], "coefficient": round(float(coefs[i]), 4)}
            for i in ranked
        ],
        "train_accuracy": round(float((clf.predict(X_enc) == y).mean()), 4),
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_outlier_subgroups(
    df: pd.DataFrame,
    inferred: Optional[Dict[str, str]] = None,
    cfg: Optional[OutlierConfig] = None,
    exclude_cols: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Detect and characterize outlier subgroups in a tabular dataset.

    Scores every row with an anomaly detector (LOF or Isolation Forest), flags
    the tail as outliers, clusters those outliers with DBSCAN, and for each
    cluster returns:

    - deviation statistics vs. the inlier population,
    - human-readable rules from a shallow decision tree, and
    - a logistic regression classifier summary predicting subgroup membership.

    Only scikit-learn is required.

    Args:
        df: Input DataFrame to analyse.
        inferred: Mapping of column names to ``"continuous"`` or ``"discrete"``.
            Inferred from dtypes when ``None``.
        cfg: Detection and subgroup discovery configuration.
        exclude_cols: Column names to exclude from rule and classifier features
            (e.g. the outcome/label column).  These columns are still used for
            anomaly detection and subgroup characterization.

    Returns:
        JSON-serialisable dict with keys:

        - ``n_total``, ``n_outliers``, ``outlier_rate`` — overall statistics.
        - ``detector`` — name of the algorithm used.
        - ``n_subgroups`` — number of discovered clusters.
        - ``subgroups`` — list of dicts, each with ``id``, ``size``,
          ``mean_score``, ``top_features``, ``feature_summary``, ``rules``,
          and ``classifier``.
        - ``skipped_reason`` — ``None`` on success, or a string explaining why
          detection was skipped.
    """

    from .outlier_rules import fit_subgroup_rules

    cfg = cfg or OutlierConfig()
    merged_inferred = _merge_inferred(df, inferred)
    df_clean = df.copy().reset_index(drop=True)
    n_total = len(df_clean)

    _empty: Dict[str, Any] = {
        "n_total": n_total,
        "n_outliers": 0,
        "outlier_rate": 0.0,
        "detector": cfg.detector,
        "n_subgroups": 0,
        "subgroups": [],
    }

    if n_total < 10:
        return {**_empty, "skipped_reason": "Dataset too small for outlier detection"}

    try:
        X = _encode_frame(df_clean, merged_inferred)
    except Exception as exc:
        LOGGER.warning("Outlier encoding failed: %s", exc)
        return {**_empty, "skipped_reason": f"Encoding failed: {exc}"}

    try:
        labels, scores = _fit_detector(X, cfg)
    except Exception as exc:
        LOGGER.warning("Outlier detection failed: %s", exc)
        return {**_empty, "skipped_reason": f"Detection failed: {exc}"}

    outlier_mask = labels == -1
    n_outliers = int(outlier_mask.sum())
    outlier_rate = round(n_outliers / n_total, 4) if n_total > 0 else 0.0

    if n_outliers == 0:
        return {**_empty, "n_outliers": 0, "outlier_rate": 0.0, "skipped_reason": None}

    outlier_X = X[outlier_mask]
    outlier_scores_arr = scores[outlier_mask]
    outlier_df = df_clean[outlier_mask].reset_index(drop=True)
    inlier_df = df_clean[~outlier_mask].reset_index(drop=True)

    try:
        cluster_labels = _discover_subgroups(outlier_X, outlier_scores_arr, cfg)
    except Exception as exc:
        LOGGER.warning("Subgroup discovery failed, treating all outliers as one group: %s", exc)
        cluster_labels = np.zeros(n_outliers, dtype=int)

    subgroups: List[Dict[str, Any]] = []
    for cid in sorted(set(cluster_labels.tolist())):
        mask = cluster_labels == cid
        sg_df = outlier_df[mask].reset_index(drop=True)
        sg_scores = outlier_scores_arr[mask]

        try:
            feature_summary, top_features = _characterize_subgroup(
                sg_df, inlier_df, merged_inferred, cfg.top_n_features
            )
        except Exception:
            LOGGER.exception("Subgroup characterization failed for cluster %s", cid)
            feature_summary, top_features = {}, []

        try:
            rules = fit_subgroup_rules(
                sg_df, inlier_df, merged_inferred, cfg.rule_depth, cfg.random_state,
                exclude_cols=exclude_cols,
            )
        except Exception:
            LOGGER.exception("Rule fitting failed for cluster %s", cid)
            rules = []

        try:
            classifier = _fit_subgroup_lr(
                sg_df, inlier_df, merged_inferred, cfg.top_n_features, cfg.random_state,
                exclude_cols=exclude_cols,
            )
        except Exception:
            LOGGER.exception("LR classifier failed for cluster %s", cid)
            classifier = {}

        subgroups.append({
            "id": int(cid),
            "size": int(mask.sum()),
            "mean_score": round(float(sg_scores.mean()), 4),
            "top_features": top_features,
            "feature_summary": feature_summary,
            "rules": rules,
            "classifier": classifier,
        })

    return {
        "n_total": n_total,
        "n_outliers": n_outliers,
        "outlier_rate": outlier_rate,
        "detector": cfg.detector,
        "n_subgroups": len(subgroups),
        "subgroups": subgroups,
        "skipped_reason": None,
    }
