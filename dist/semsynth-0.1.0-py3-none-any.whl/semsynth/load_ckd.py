import pandas as pd
import gzip
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PATH = os.path.join(SCRIPT_DIR, "..", "downloads-cache", "uciml", "336.csv.gz")

def load_ckd(path=DEFAULT_PATH):
    with gzip.open(path) as f:
        df = pd.read_csv(f)
    
    df = df.apply(lambda x: x.str.strip() if x.dtype == 'object' else x)
    
    df["dm"] = df["dm"].replace("\tno", "no")
    df["class"] = df["class"].replace("ckd\t", "ckd")
    
    return df