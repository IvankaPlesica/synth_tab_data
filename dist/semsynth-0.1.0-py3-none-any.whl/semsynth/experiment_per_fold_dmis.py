"""Standalone experiment (hepatitis only): does computing D_mis and the mp0
retention_ratio PER FOLD, instead of pooling all folds' synthetic tables
first, roughly agree with the existing pooled numbers?

Read-only against the real pipeline: does NOT import
evaluate_ckd_missingness_strategies_full.py, since that file is a flat
script with no __main__ guard -- importing it would re-run the entire R/S1/S2
loop and silently overwrite metrics_history.csv / subgroup_metadata.json /
pipeline_metadata.json as a side effect. Instead this script imports the same
lower-level modules that file itself imports (imputation, shadow_columns,
synthesis, pattern_missingness, block_analysis, Missingness_Model,
dataset_registry) and re-runs only the fold-loop steps needed to get
S1/S2 synthetic training tables per fold.

compute_dmis() below is copied verbatim from
evaluate_ckd_missingness_strategies_full.py (it's a local function nested in
that script, not importable) -- keep it in sync by hand if that definition
ever changes.

The "retention_ratio" tracked here is specifically for the mp0 subgroup
(rows with zero missing values). It's computed from assign_patterns()'s
"mp0" rate rather than re-deriving the EXTRA_SUBGROUPS mp0 mask separately --
both conditions are "isnull().sum(axis=1) == 0" under the hood, so the two
are mathematically identical, and reusing assign_patterns() avoids a second
pass over the same synthetic tables.

Writes nothing to any pipeline output file; only prints and saves its own
experiment_per_fold_dmis_results.json in the current directory.
"""
import json

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

from imputation import simple_impute
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from pattern_missingness import run_s2_branch
from block_analysis import assign_patterns
from Missingness_Model import MissingnessModel
from dataset_registry import DATASET_REGISTRY

DATASET_NAME = "hepatitis"
SEED = 42


def compute_dmis(real_labels, synth_labels):
    """L1 divergence between real and synthetic pattern-label rate
    distributions (Wang, Asif & Vaidya 2023, Eq. 1)."""
    real_rates = real_labels.value_counts(normalize=True)
    synth_rates = synth_labels.value_counts(normalize=True)
    all_labels = set(real_rates.index) | set(synth_rates.index)
    return sum(abs(real_rates.get(m, 0.0) - synth_rates.get(m, 0.0)) for m in all_labels)


def mp0_rate(labels):
    return float(labels.value_counts(normalize=True).get("mp0", 0.0))


def main():
    config = DATASET_REGISTRY[DATASET_NAME]
    df = config["loader"]()
    n_splits = config["n_splits"]
    positive_label = config["positive_label"]
    categorical_cols = config["categorical_cols"]
    min_support = config["min_support"]
    min_any_confidence = config["min_any_confidence"]

    X = df.drop(columns=["class"])
    y = df["class"]
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=SEED)

    # Same post-hoc structure model as the main pipeline: fit once on the
    # full real X, used to label real and synthetic rows consistently.
    structure_model = MissingnessModel().fit(
        X, min_support=min_support, min_any_confidence=min_any_confidence
    )
    real_labels_full = assign_patterns(X, structure_model)

    per_fold = {"S1": [], "S2": []}
    s1_features_all, s2_features_all = [], []

    for fold_num, (train_index, test_index) in enumerate(skf.split(X, y)):
        print(f"Fold {fold_num + 1}/{n_splits}...")
        X_train = X.iloc[train_index].copy()
        y_train = (y.iloc[train_index] == positive_label).astype(int)

        X_train_filled = simple_impute(X_train)

        shadow_cols = build_shadow_columns(X_train)
        synth_features_with_shadows, _ = synthesize(
            X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols, seed=SEED
        )
        s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)

        mining_model = MissingnessModel().fit(
            X_train, min_support=min_support, min_any_confidence=min_any_confidence
        )
        s2_features, _ = run_s2_branch(
            X_train, X_train_filled, y_train, categorical_cols, mining_model, seed=SEED
        )

        # Real labels restricted to this fold's TRAIN rows, so the per-fold
        # comparison is apples-to-apples with each fold's own synthetic
        # training table (both are "this fold's training split").
        real_labels_fold = real_labels_full.iloc[train_index]
        real_mp0_fold = mp0_rate(real_labels_fold)

        for branch, synth_features in [("S1", s1_features), ("S2", s2_features)]:
            synth_labels = assign_patterns(synth_features, structure_model)
            dmis = compute_dmis(real_labels_fold, synth_labels)
            synth_mp0 = mp0_rate(synth_labels)
            retention_ratio = (synth_mp0 / real_mp0_fold) if real_mp0_fold > 0 else None
            per_fold[branch].append({
                "fold": fold_num,
                "dmis": float(dmis),
                "mp0_rate_real": real_mp0_fold,
                "mp0_rate_synth": synth_mp0,
                "mp0_retention_ratio": retention_ratio,
            })

        s1_features_all.append(s1_features)
        s2_features_all.append(s2_features)

    # Pooled reference point, computed the same way the main pipeline does:
    # concatenate every fold's synthetic training table, then compute once
    # against the full-dataset real labels.
    s1_pooled = pd.concat(s1_features_all, ignore_index=True)
    s2_pooled = pd.concat(s2_features_all, ignore_index=True)
    real_mp0_full = mp0_rate(real_labels_full)

    pooled = {}
    for branch, synth_pooled in [("S1", s1_pooled), ("S2", s2_pooled)]:
        synth_labels_pooled = assign_patterns(synth_pooled, structure_model)
        dmis_pooled = compute_dmis(real_labels_full, synth_labels_pooled)
        synth_mp0_pooled = mp0_rate(synth_labels_pooled)
        retention_pooled = (synth_mp0_pooled / real_mp0_full) if real_mp0_full > 0 else None
        pooled[branch] = {
            "dmis": float(dmis_pooled),
            "mp0_rate_real": real_mp0_full,
            "mp0_rate_synth": synth_mp0_pooled,
            "mp0_retention_ratio": retention_pooled,
        }

    # ---- report ----
    print("\n" + "=" * 70)
    print(f"Per-fold vs pooled D_mis / mp0-retention comparison ({DATASET_NAME})")
    print("=" * 70)

    def fmt_ratio(r):
        return f"{r:.3f}" if r is not None else "n/a"

    summary = {"dataset": DATASET_NAME, "n_splits": n_splits, "per_fold": per_fold, "pooled": pooled}
    for branch in ["S1", "S2"]:
        dmis_vals = [r["dmis"] for r in per_fold[branch]]
        ret_vals = [r["mp0_retention_ratio"] for r in per_fold[branch] if r["mp0_retention_ratio"] is not None]

        print(f"\n--- {branch} ---")
        for r in per_fold[branch]:
            print(f"  fold {r['fold']}: dmis={r['dmis']:.4f}  mp0_retention={fmt_ratio(r['mp0_retention_ratio'])}"
                  f"  (mp0 real={r['mp0_rate_real']:.3f}, synth={r['mp0_rate_synth']:.3f})")

        dmis_mean, dmis_std = float(np.mean(dmis_vals)), float(np.std(dmis_vals))
        ret_mean = float(np.mean(ret_vals)) if ret_vals else None
        ret_std = float(np.std(ret_vals)) if ret_vals else None
        print(f"  per-fold mean +/- std: dmis={dmis_mean:.4f} +/- {dmis_std:.4f}, "
              f"mp0_retention={fmt_ratio(ret_mean)} +/- {fmt_ratio(ret_std)}")
        print(f"  pooled (original method): dmis={pooled[branch]['dmis']:.4f}, "
              f"mp0_retention={fmt_ratio(pooled[branch]['mp0_retention_ratio'])}")

        summary[branch] = {
            "per_fold_dmis_mean": dmis_mean,
            "per_fold_dmis_std": dmis_std,
            "per_fold_mp0_retention_mean": ret_mean,
            "per_fold_mp0_retention_std": ret_std,
            "pooled_dmis": pooled[branch]["dmis"],
            "pooled_mp0_retention": pooled[branch]["mp0_retention_ratio"],
        }

    out_path = "experiment_per_fold_dmis_results.json"
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nSaved full results to {out_path}")


if __name__ == "__main__":
    main()
