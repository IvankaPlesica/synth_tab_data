from rule_mining import missing_matrix
import pandas as pd

def assign_patterns(df, threshold=0.9):
    M = missing_matrix(df)
    patterns = {
        "mp1": ["sc", "bu", "bgr", "sod", "pot"],
        "mp2": ["wbcc", "rbcc", "pcv", "hemo"],
        "mp3": ["sg", "al", "su"],
    }

    # check each panel independently
    panel_matches = {}
    for label, cols in patterns.items():
        cols = [c for c in cols if c in M.columns]
        if not cols:
            continue
        missing_fraction = M[cols].sum(axis=1) / len(cols)
        panel_matches[label] = missing_fraction >= threshold

    # build combined label
    labels = []
    for i in df.index:
        matched = [label for label in patterns if panel_matches.get(label, pd.Series(False, index=df.index))[i]]
        if len(matched) == 0:
            labels.append("mp0")
        else:
            labels.append("+".join(matched))

    labels = pd.Series(labels, index=df.index)

    # rows with any missingness but no panel match go to mp_other
    incomplete = M.any(axis=1)
    no_panel = labels == "mp0"
    labels[incomplete & no_panel] = "mp_other"

    return labels