"""Out-of-fold subgroup privacy check for CKD S1, using anonymeter's
SinglingOutEvaluator. Reuses the same 5-fold StratifiedKFold pattern as
evaluate_ckd_missingness_strategies.py (same random_state=42, same
n_splits from dataset_registry.py), and the frozen outlier rule from
outlier_rule.joblib as oof_pooling.py does -- neither refit here.

API note (anonymeter 1.0.0, verified against the installed package's
source -- anonymeter/evaluators/singling_out_evaluator.py -- not
guessed): SinglingOutEvaluator does NOT expose which specific control
rows were singled out. Internally, evaluate() only computes
`self._n_control = len(_evaluate_queries(control, queries))`, a COUNT
(further rescaled by a size-correction factor when len(control) !=
len(ori)), never row identities -- and that count is computed from the
FULL candidate query list generated against `syn`, not filtered down to
the queries that actually succeeded against `ori`. The only public
per-item result is `.queries()`, the list of successful attack query
strings THAT DID single out a real training row (`self._queries`).

To get row-level results, this script re-runs those same ori-successful
queries against `control` here, using the same df.query(query,
engine="python") mechanism the library itself uses internally (see
safe_query_counts in the same module) -- a control row counts as
"attacked" if a query that successfully singled out a real training
row also uniquely matches that control row. This is a deliberately
different (more meaningful) signal than the library's own internal
_n_control bulk count: it measures whether a REAL successful attack
generalizes to a held-out row, not how often the attacker's query-
generation process would work on held-out data by chance.

n_attacks: anonymeter's README (checked directly) states only a general
precision-vs-compute tradeoff, no dataset-size-relative formula. Used
n_attacks = min(500, len(X_train)) per fold: the library's own default
(500), capped by the fold's actual training-set size, since asking for
more attacks than there are training rows to distinguish doesn't add
real power.
"""

import numpy as np
import pandas as pd
from anonymeter.evaluators import SinglingOutEvaluator
from sklearn.model_selection import StratifiedKFold

from dataset_registry import DATASET_REGISTRY
from imputation import simple_impute
from shadow_columns import build_shadow_columns, reinsert_from_shadow_columns
from synthesis import synthesize
from frozen_outlier_rule import apply_outlier_rule


def attacked_rows(control_df, successful_queries):
    """Re-run each ori-successful singling-out query against control_df, using the
    same matching rule the library uses (query singles out iff it matches exactly
    1 row). Returns the set of control_df index labels singled out by >=1 query."""
    attacked = set()
    for q in successful_queries:
        try:
            matched = control_df.query(q, engine="python")
        except Exception:
            continue
        if len(matched) == 1:
            attacked.add(matched.index[0])
    return attacked


if __name__ == "__main__":
    config = DATASET_REGISTRY["ckd"]
    categorical_cols = config["categorical_cols"]
    df = config["loader"]()
    X = df.drop(columns=["class"])
    y = (df["class"] == config["positive_label"]).astype(int)
    for c in categorical_cols:
        if c in X.columns:
            X[c] = X[c].astype("object")

    skf = StratifiedKFold(n_splits=config["n_splits"], shuffle=True, random_state=42)

    fold_risks = []
    attacked_mask = pd.Series(False, index=df.index)  # pooled out-of-fold: every row
    # is exactly one fold's control row, so this fills in across all 5 folds

    for fold_num, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train = y.iloc[train_idx]

        X_train_filled = simple_impute(X_train)
        shadow_cols = build_shadow_columns(X_train)
        synth_features_with_shadows, synth_label_s1 = synthesize(
            X_train_filled, y_train, categorical_cols, shadow_cols=shadow_cols
        )
        s1_features = reinsert_from_shadow_columns(synth_features_with_shadows, X_train.columns)

        n_attacks = min(500, len(X_train))
        evaluator = SinglingOutEvaluator(
            ori=X_train, syn=s1_features, control=X_test, n_attacks=n_attacks
        )
        evaluator.evaluate(mode="multivariate")
        risk = evaluator.risk()
        results = evaluator.results()
        fold_risks.append(risk.value)
        print(f"Fold {fold_num}: risk={risk.value:.4f} (ci={risk.ci}), n_attacks={n_attacks}, "
              f"n_success_vs_ori={results.n_success}, n_successful_queries={len(evaluator.queries())}")

        fold_outlier_mask = apply_outlier_rule(X_test)
        n_fold_outliers = int(fold_outlier_mask.sum())
        if n_fold_outliers < 5:
            print(f"  WARNING: only {n_fold_outliers} outlier rows in this fold's control set "
                  "-- fold-level subgroup rate would be unreliable (using pooled results instead).")

        hit_rows = attacked_rows(X_test, evaluator.queries())
        if hit_rows:
            attacked_mask.loc[list(hit_rows)] = True
        print(f"  -> {len(hit_rows)} / {len(X_test)} control rows singled out this fold "
              f"({n_fold_outliers} of which are outliers)")

    print(f"\nMean risk across folds: {np.mean(fold_risks):.4f} (std={np.std(fold_risks):.4f})")

    # flag outliers once, on the full real dataset (frozen rule, not refit)
    outlier_mask = apply_outlier_rule(df)
    n_outliers = int(outlier_mask.sum())
    print(f"\nTotal outliers across full dataset: {n_outliers} / {len(df)}")
    if n_outliers < 10:
        print(f"WARNING: only {n_outliers} outliers -- pooled attack-rate estimate for this "
              "group is small-n and may be unreliable.")

    attacked_arr = attacked_mask.to_numpy()
    n_out_attacked = int(attacked_arr[outlier_mask].sum())
    n_non_attacked = int(attacked_arr[~outlier_mask].sum())
    outlier_rate = attacked_arr[outlier_mask].mean() if outlier_mask.sum() else float("nan")
    non_outlier_rate = attacked_arr[~outlier_mask].mean() if (~outlier_mask).sum() else float("nan")

    print(f"\nPooled attack rate -- outlier subgroup:     {outlier_rate:.3f} "
          f"({n_out_attacked}/{int(outlier_mask.sum())})")
    print(f"Pooled attack rate -- non-outlier subgroup: {non_outlier_rate:.3f} "
          f"({n_non_attacked}/{int((~outlier_mask).sum())})")
    print(f"Gap (outlier - non-outlier): {outlier_rate - non_outlier_rate:+.3f}")
