import pandas as pd

pd.set_option("display.max_columns", None)
pd.set_option("display.width", None)


def block_rate_table(df, df_features, model, index_col, index_order, restrict_mask):
    """Print block missingness rates (any-column and alone) grouped by a
    categorical column, restricted to the rows in restrict_mask."""
    subset = df[restrict_mask]
    rows_any, rows_alone = [], []

    for b in model.blocks:
        label = "+".join(b["itemset"])
        block_missing = df_features.loc[subset.index, b["itemset"]].isna().all(axis=1)
        other_cols = [c for c in df_features.columns if c not in b["itemset"]]
        only_this = block_missing & ~df_features.loc[subset.index, other_cols].isna().any(axis=1)

        for level in index_order:
            level_mask = subset[index_col] == level
            n = level_mask.sum()
            if n == 0:
                continue
            rows_any.append({"block": label, "level": level,
                              "rate": round((block_missing & level_mask).sum() / n, 3)})
            rows_alone.append({"block": label, "level": level,
                                "rate": round((only_this & level_mask).sum() / n, 3)})

    if not rows_any:
        print("  (no relevant blocks found)")
        return

    levels_present = [l for l in index_order if l in {r["level"] for r in rows_any}]

    print(f"\nRate of block missing (any), by {index_col}:")
    print(pd.DataFrame(rows_any).pivot(index="block", columns="level", values="rate")[levels_present])

    print(f"\nRate of block missing (alone), by {index_col}:")
    print(pd.DataFrame(rows_alone).pivot(index="block", columns="level", values="rate")[levels_present])


def block_missing_flags(df_features, model):
    """Boolean dataframe: one column per block, True where that block is
    fully missing for the patient."""
    labels = ["+".join(b["itemset"]) for b in model.blocks]
    return pd.DataFrame({
        label: df_features[b["itemset"]].isna().all(axis=1)
        for label, b in zip(labels, model.blocks)
    })


def block_cooccurrence(missing_flags):
    """P(block B missing | block A missing) for every pair of blocks."""
    labels = missing_flags.columns
    cooc = pd.DataFrame(index=labels, columns=labels, dtype=float)
    for a in labels:
        n_a = missing_flags[a].sum()
        for b in labels:
            cooc.loc[a, b] = (
                round((missing_flags[a] & missing_flags[b]).sum() / n_a, 3)
                if n_a > 0 else float("nan")
            )
    return cooc


def blocks_missing_per_row(missing_flags):
    """Series: number of blocks missing per row."""
    return missing_flags.sum(axis=1)


def itemset_rate_table(df, df_features, itemset, index_col, index_order, restrict_mask):
    """Same as block_rate_table, but for an arbitrary itemset (e.g. a
    subset of a reported block) rather than the model's own blocks."""
    subset = df[restrict_mask]
    missing = df_features.loc[subset.index, itemset].isna().all(axis=1)

    rows = []
    for level in index_order:
        level_mask = subset[index_col] == level
        n = level_mask.sum()
        if n == 0:
            continue
        rows.append({"level": level, "rate": round((missing & level_mask).sum() / n, 3)})

    if not rows:
        print("  (no data for this itemset)")
        return

    label = "+".join(itemset)
    print(f"\nRate of {{{label}}} missing, by {index_col}:")
    print(pd.DataFrame(rows).set_index("level")["rate"])


def assign_pattern(row_isna, blocks):
    """Label a row: which block(s) triggered, 'mp0' if truly nothing
    is missing, or 'mp_other' if something's missing but no block matched."""
    active = ["+".join(b["itemset"]) for b in blocks if row_isna[b["itemset"]].all()]
    if not active:
        return "mp0" if not row_isna.any() else "mp_other"
    return " & ".join(active)


def assign_patterns(df_features, model):
    """Vectorized convenience wrapper: returns a Series of pattern labels
    for every row in df_features, given a fitted MissingnessModel."""
    return df_features.apply(
        lambda row: assign_pattern(row.isna(), model.blocks), axis=1
    )