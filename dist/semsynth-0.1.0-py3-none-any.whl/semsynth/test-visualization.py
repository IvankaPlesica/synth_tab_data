import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from load_ckd import load_ckd
from egfr_staging import add_egfr_columns
from Missingness_Model import MissingnessModel

df = load_ckd()
df = add_egfr_columns(df, export_path="ckd_with_egfr.csv")
exclude_cols = ["class", "egfr_star", "ckd_stage", "ckd_stage_cat"]
df_features = df.drop(columns=[c for c in exclude_cols if c in df.columns])

model = MissingnessModel().fit(df_features, min_support=0.1, min_any_confidence=0.1)

class_order = ["ckd", "notckd"]
class_labels = ["CKD", "Non-CKD"]
n_blocks = len(model.blocks)
width = 0.8 / n_blocks
x = np.arange(len(class_order))

fig, ax = plt.subplots(figsize=(6, 5))

for i, b in enumerate(model.blocks):
    block_missing = df_features[b["itemset"]].isna().all(axis=1)
    rates = [
        (block_missing & (df["class"] == cls)).sum() / (df["class"] == cls).sum()
        for cls in class_order
    ]
    label = "+".join(b["itemset"])
    offset = (i - (n_blocks - 1) / 2) * width
    ax.bar(x + offset, rates, width=width, label=label)

ax.set_xticks(x)
ax.set_xticklabels(class_labels)
ax.set_ylim(0, max(0.5, max(rates) * 1.15))
ax.set_ylabel("Rate of block missing")
ax.set_title("Block missingness rate by class")
ax.grid(axis="y", alpha=0.3)
ax.legend(fontsize=8)
plt.tight_layout()
plt.savefig("block_by_class.png", dpi=300)
plt.show()

# also print the raw rates for the results text
print("\nRate of block missing, by class:")
for b in model.blocks:
    block_missing = df_features[b["itemset"]].isna().all(axis=1)
    label = "+".join(b["itemset"])
    for cls, cls_label in zip(class_order, class_labels):
        rate = (block_missing & (df["class"] == cls)).sum() / (df["class"] == cls).sum()
        print(f"  {label} | {cls_label}: {rate:.3f}")