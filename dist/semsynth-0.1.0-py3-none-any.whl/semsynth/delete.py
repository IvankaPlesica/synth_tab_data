library(readr)
library(dplyr)

DATA_PATH <- "ckd_with_egfr.csv"  # adjust path if needed

df <- read_csv(DATA_PATH) %>%
  mutate(class = recode(trimws(class), "ckd" = "CKD", "notckd" = "Non-CKD"))

vars_positive <- list(
  rbc = "abnormal",
  pc  = "abnormal",
  pcc = "present",
  ba  = "present"
)

for (var in names(vars_positive)) {
  pos_label <- vars_positive[[var]]
  cat("\n===", var, "(", pos_label, "vs not ) ===\n")

  print(table(df$class, df[[var]], useNA = "ifany"))

  for (grp in c("CKD", "Non-CKD")) {
    sub <- df %>% filter(class == grp)
    n_total      <- nrow(sub)
    n_missing    <- sum(is.na(sub[[var]]))
    n_pos        <- sum(sub[[var]] == pos_label, na.rm = TRUE)
    n_non_missing <- n_total - n_missing
    n_neg        <- n_non_missing - n_pos
    pct_pos      <- round(100 * n_pos / n_non_missing, 1)
    pct_neg      <- round(100 * n_neg / n_non_missing, 1)
    cat(sprintf("  %s: N=%d, missing=%d, %s=%d (%.1f%%), not_%s=%d (%.1f%%)\n",
                grp, n_total, n_missing, pos_label, n_pos, pct_pos,
                pos_label, n_neg, pct_neg))
  }

  n_total       <- nrow(df)
  n_missing     <- sum(is.na(df[[var]]))
  n_pos         <- sum(df[[var]] == pos_label, na.rm = TRUE)
  n_non_missing <- n_total - n_missing
  n_neg         <- n_non_missing - n_pos
  cat(sprintf("  Overall: N=%d, missing=%d, %s=%d (%.1f%%), not_%s=%d (%.1f%%)\n",
              n_total, n_missing, pos_label, n_pos,
              round(100 * n_pos / n_non_missing, 1),
              pos_label, n_neg,
              round(100 * n_neg / n_non_missing, 1)))
}