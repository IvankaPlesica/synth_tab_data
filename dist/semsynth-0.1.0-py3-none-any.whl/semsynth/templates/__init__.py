"""Packaged report templates."""
