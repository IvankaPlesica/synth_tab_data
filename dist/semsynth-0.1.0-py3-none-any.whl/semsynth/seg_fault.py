import warnings
warnings.filterwarnings("ignore")

from load_ckd import load_ckd
from imputation import simple_impute, synthesize

df = load_ckd()
X = df.drop(columns=["class"])
y = (df["class"] == "ckd").astype(int)

categorical_cols = ["rbc", "pc", "pcc", "ba", "htn", "dm",
                    "cad", "appet", "pe", "ane"]
for c in categorical_cols:
    if c in X.columns:
        X[c] = X[c].astype("object")

X_filled = simple_impute(X)
print("simple_impute done")

synth_features, synth_label = synthesize(X_filled, y, categorical_cols)
print(f"synthesize done, shape={synth_features.shape}")