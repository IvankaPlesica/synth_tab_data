"""Decision-tree rule generation for outlier subgroup characterization."""

from __future__ import annotations

import logging
from typing import Any, Dict, List

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)


def _fmt_threshold(value: float) -> str:
    """Format a numeric split threshold with context-appropriate precision."""

    mag = abs(value)
    if mag == 0:
        return "0"
    if mag >= 100:
        return f"{value:.1f}"
    if mag >= 10:
        return f"{value:.2f}"
    if mag >= 1:
        return f"{value:.3f}"
    return f"{value:.4f}"


def _condition_str(feat: str, threshold: float, *, left: bool) -> str:
    """Render one tree split as a human-readable condition string.

    For one-hot indicator columns (name contains ``=`` and threshold ≈ 0.5)
    the output is ``col = value`` or ``col ≠ value``.  For numeric columns the
    output is ``col ≤ threshold`` or ``col > threshold``.
    """

    if "=" in feat and abs(threshold - 0.5) < 0.1:
        col, val = feat.split("=", 1)
        return f"{col} \u2260 {val}" if left else f"{col} = {val}"
    thr = _fmt_threshold(threshold)
    return f"{feat} \u2264 {thr}" if left else f"{feat} > {thr}"


def _tree_to_rules(clf: Any, feature_names: List[str]) -> List[Dict[str, Any]]:
    """Walk a fitted DecisionTreeClassifier and return one rule per subgroup leaf.

    Only leaves whose majority class is the subgroup class (label 1) are
    emitted.  Each rule is a dict with ``rule`` (a readable AND-joined string),
    ``conditions`` (the list of individual clauses), ``n_samples`` (rows
    reaching the leaf in training) and ``purity`` (fraction that are subgroup
    members).

    Args:
        clf: Fitted ``DecisionTreeClassifier``.
        feature_names: Feature name list aligned with the training matrix columns.

    Returns:
        List of rule dicts, one per subgroup-predicting leaf.
    """

    from sklearn.tree import _tree as _sklearn_tree

    tree_ = clf.tree_
    rules: List[Dict[str, Any]] = []

    def _recurse(node: int, path: List[str]) -> None:
        if tree_.feature[node] == _sklearn_tree.TREE_UNDEFINED:
            values = tree_.value[node][0]
            class_id = int(np.argmax(values))
            n_node = int(tree_.n_node_samples[node])
            total_w = float(values.sum())
            purity = round(float(values[1]) / total_w, 3) if total_w > 0 and len(values) > 1 else 0.0
            if class_id == 1:
                rules.append({
                    "rule": " AND ".join(path) if path else "always",
                    "conditions": path[:],
                    "n_samples": n_node,
                    "purity": purity,
                })
            return

        feat = feature_names[tree_.feature[node]]
        thr = float(tree_.threshold[node])
        _recurse(tree_.children_left[node],  path + [_condition_str(feat, thr, left=True)])
        _recurse(tree_.children_right[node], path + [_condition_str(feat, thr, left=False)])

    _recurse(0, [])
    return sorted(rules, key=lambda r: r["purity"], reverse=True)


def _encode_for_tree(
    df: pd.DataFrame, inferred: Dict[str, str]
) -> tuple[np.ndarray, List[str]]:
    """Encode DataFrame for a decision tree, preserving readable feature names.

    Numeric columns are median-imputed and passed through as-is (trees find
    their own thresholds).  Categorical columns are one-hot encoded with names
    of the form ``col=value`` so that split conditions can be rendered as
    ``col = value`` / ``col ≠ value``.

    Args:
        df: Input DataFrame (may contain NaNs).
        inferred: Column type mapping.

    Returns:
        Tuple of the 2-D feature matrix and the corresponding feature name list.
    """

    parts: List[np.ndarray] = []
    feature_names: List[str] = []

    for col in df.columns:
        series = df[col]
        if inferred.get(col, "continuous") == "continuous":
            vals = pd.to_numeric(series, errors="coerce")
            median_val = float(vals.median()) if not vals.dropna().empty else 0.0
            parts.append(vals.fillna(median_val).values.reshape(-1, 1).astype(float))
            feature_names.append(col)
        else:
            categories = sorted(series.dropna().astype(str).unique())
            for cat in categories:
                indicator = (series.astype(str) == cat).astype(float).values.reshape(-1, 1)
                parts.append(indicator)
                feature_names.append(f"{col}={cat}")

    if not parts:
        return np.empty((len(df), 0), dtype=float), []

    return np.hstack(parts), feature_names


def fit_subgroup_rules(
    subgroup_df: pd.DataFrame,
    inlier_df: pd.DataFrame,
    inferred: Dict[str, str],
    max_depth: int,
    random_state: int,
    exclude_cols: List[str] | None = None,
) -> List[Dict[str, Any]]:
    """Fit a shallow decision tree and return human-readable rules for a subgroup.

    The tree is trained with ``class_weight="balanced"`` to handle the natural
    imbalance between outliers and inliers.  Rules are extracted only for leaves
    that predict the subgroup class.

    Args:
        subgroup_df: Rows belonging to the subgroup (positive class).
        inlier_df: All inlier rows (negative class).
        inferred: Column type mapping used for encoding.
        max_depth: Maximum tree depth controlling rule complexity.
        random_state: Seed for the decision tree.
        exclude_cols: Column names to drop before encoding (e.g. outcome labels).

    Returns:
        List of rule dicts sorted by purity descending, or an empty list when
        the tree cannot be fitted.
    """

    from sklearn.tree import DecisionTreeClassifier

    if len(subgroup_df) < 2 or len(inlier_df) < 2:
        return []

    combined = pd.concat(
        [inlier_df.assign(_lbl=0), subgroup_df.assign(_lbl=1)], ignore_index=True
    )
    y = combined["_lbl"].values
    X_df = combined.drop(columns="_lbl")
    if exclude_cols:
        X_df = X_df.drop(columns=[c for c in exclude_cols if c in X_df.columns])

    try:
        X, feature_names = _encode_for_tree(X_df, inferred)
    except Exception as exc:
        LOGGER.warning("Tree encoding failed for subgroup rules: %s", exc)
        return []

    if X.shape[1] == 0:
        return []

    clf = DecisionTreeClassifier(
        max_depth=max_depth, class_weight="balanced", random_state=random_state
    )
    clf.fit(X, y)

    try:
        return _tree_to_rules(clf, feature_names)
    except Exception as exc:
        LOGGER.warning("Rule extraction failed: %s", exc)
        return []

